# Saeculum

*Latin: an age, a lifetime.* A personal book-logging and reading-library app for Android. It's built to feel like your own curated bookshelf rather than a spreadsheet.

<img src="docs/icon-512.png" width="96" alt="Saeculum icon: a cloth-bound book with a serif S">

Saeculum works fully offline, needs no account, and keeps everything on your phone. On first launch it imports your historical **Novels Read** list (2020–2026, 81 entries) as the starting library.

---

## 1. Status: what was actually verified

| Area | How | Result |
|---|---|---|
| Full Android build | Gradle 8.14.3, AGP 8.7.3, Kotlin 2.0.21, Android SDK 35 | **Builds**: `app-release.apk` (R8-optimised, signed) and `app-debug.apk` |
| Core business logic (`:core`) | JUnit, `./gradlew :core:test` | **49 / 49 pass** |
| App smoke test (`AppSmokeTest`) | Robolectric runs the real `MainActivity`, Room database, DataStore and Compose UI on the JVM | **Passes**: your 81-book history imports on first launch, then Library (1/3/6 columns), the detail sheet, Statistics, Currently Reading, Settings, the Add menu, manual entry and dark mode all render, with screenshots saved |
| On-device DB tests (`BookDaoTest`) | `./gradlew connectedAndroidTest` | Compiled; needs a phone or emulator to run |

The only compile error on the first real build was one misnamed icon. Not yet exercised on a physical phone: the camera barcode scanner, live Open Library / Google Books lookups, and the system file pickers for import, export and backup. See `docs/VERIFICATION.md`.

---

## Two editions

| Edition | Gradle task | Use it for |
|---|---|---|
| **personal** | `./gradlew :app:assemblePersonalRelease` | Your own phone. Imports your Novels Read list on first launch. |
| **share** | `./gradlew :app:assembleShareRelease` | Friends. Starts with an empty library; your reading list is **not inside the APK**, since it lives only in `app/src/personal/assets/` (verified by `ShareEditionTest`). |

Both editions share the same app ID and signing key, so each installs as an update over the other and keeps whatever library is already on that phone.

---

## 2. Building and installing

### Option A: GitHub Actions (no local setup)
1. Create a GitHub repository and push this folder.
2. The included workflow `.github/workflows/android.yml` runs automatically. It runs the core tests and builds `app-debug.apk` and `app-release.apk`.
3. Open the workflow run → **Artifacts** → download `saeculum-apk`.
4. Copy the APK to your phone, open it, and allow "install unknown apps" for your file manager when asked.

(Optional) add a repository secret `GOOGLE_BOOKS_API_KEY` for a higher Google Books quota.

### Option B: Android Studio
1. Install Android Studio (Ladybug 2024.2 or newer) and open this folder.
2. Let Gradle sync. It downloads Gradle 8.11.1, AGP 8.7.3, Kotlin 2.0.21 and the libraries.
3. Plug in a phone with USB debugging enabled and press **Run**, or use **Build ▸ Build APK(s)**.

### Option C: Command line
```bash
# Needs JDK 17+ and the Android SDK (ANDROID_HOME set, platform 35)
./gradlew :core:test                 # business-logic tests
./gradlew :app:testPersonalDebugUnitTest :app:testShareDebugUnitTest  # Robolectric app smoke test (screenshots → app/build/screenshots)
./gradlew :app:assemblePersonalDebug # → app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:assembleShareRelease  # → minified APK, signed with the debug key unless you configure one
adb install -r app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:connectedAndroidTest  # on-device database tests (needs a phone/emulator)
```

Release signing: copy `local.properties.example` to `local.properties` and set `SAECULUM_KEYSTORE`, `SAECULUM_KEYSTORE_PASSWORD`, `SAECULUM_KEY_ALIAS` and `SAECULUM_KEY_PASSWORD`. The delivered APK is signed with the Saeculum key supplied alongside it; use the same key for future builds so they install as updates. Without a key configured, release builds fall back to the debug key. Debug and release builds share one application ID, so they share one library. If the minified release ever misbehaves, use the debug APK.

---

## 3. Technology choice: Kotlin + Jetpack Compose (no Rust)

I compared:

- **Kotlin + Jetpack Compose (chosen).** Native Android UI with first-class accessibility. It has mature, well-supported libraries for everything required: Room/SQLite with migrations, DataStore, CameraX + ML Kit barcode scanning (works offline), the photo picker, and the Storage Access Framework for exports. It's also the simplest to build into an APK and maintain.
- **Rust business logic + Kotlin UI (JNI/UniFFI).** This would add the Android NDK, `cargo-ndk`, cross-compiled `.so` files for each CPU type, and a cross-language bridge. Saeculum's logic is storage, CSV handling and small calculations, with nothing CPU-heavy. Rust would bring no real speed or safety gain, and would cost build complexity and maintenance.
- **Rust-first (Tauri).** I inspected the supplied `Shelf_APP.apk`. It is a Tauri app: Rust (`libshelf_lib.so`) with a WebView front end. That route means a web UI inside a WebView, with weaker native feel and accessibility, and plugins needed for camera and storage access.

**Decision:** Kotlin + Compose. All the pure logic lives in a separate Kotlin `:core` module with no Android dependencies. That keeps it fast to test and makes a future port of the logic (for example to Rust or Kotlin Multiplatform) straightforward if there's ever a reason.

---

## 4. Architecture

```
:core  (pure Kotlin/JVM, unit-tested)
  model/        Book, BookDraft, ReadingStatus, BookFilter, BookSort, StatusTransitions,
                BookEdits (three-way merge), BookValidator, Captions
  csv/          RFC-4180 reader/writer (quotes, commas, newlines, BOM, malformed-row recovery)
  importer/     CsvMapping (flexible headers), ImportPlanner (preview, issues), DuplicateDetector
  migration/    ReadingListParser (your “Novels Read” text format)
  export/       CsvExporter, TxtExporter
  stats/        StatsCalculator
  backup/       BackupCodec (JSON), RestorePlanner
  metadata/     Open Library & Google Books parsers, MatchScorer, MetadataMerge
  json/         small dependency-free JSON reader/writer
  isbn/, text/  ISBN-10/13 validation and conversion, normalisation, partial dates

:app   (Android)
  data/         Room (BookEntity, BookDao, AppDatabase), BookRepository, SettingsRepository (DataStore),
                CoverStore, DataTransfer (CSV/TXT/ZIP backup/restore), SeedImporter, net/MetadataService
  ui/           Compose screens + one ViewModel per screen
                library · lists (Reading / To Read / Want to Buy) · detail sheet · editor ·
                add (search, scan) · importcsv (CSV wizard, cover/metadata enrichment) · stats · settings
  SaeculumApp   manual dependency container (AppContainer); no DI framework needed at this size
```

**Data flow:** Room emits `Flow<List<Book>>` → ViewModels combine it with settings (sort, filter, density) → `StateFlow` → Compose. Every write is a small, targeted transaction:

- A rating or notes change touches only that column.
- The full editor saves through a **three-way merge**: original form vs your edits vs the current database row. Editing the publisher can never overwrite notes or a rating you changed elsewhere (tested).
- Status changes go through `StatusTransitions`, which keeps completion data consistent.

**Error handling:** network calls return a typed `Lookup` (Found / NoMatch / Offline / Failed). Each one leads somewhere useful, and manual entry is always available. Bulk inserts are per-row, so one bad record never blocks the rest. Exports report success only after the file stream has closed.

---

## 5. Data model and storage

One `books` table (Room/SQLite). Fields: stable `id` and `uuid`, `title`, `authors` (ordered list), `isbn10` and `isbn13`, `coverUrl`, local `coverPath` and `coverIsCustom`, `publicationYear`, `publisher`, `status`, `rating` (1–5 or null), `notes`, `dateAdded`, `completedDate` (exact, optional), `completedYear` (optional, can be known without a date), `startedDate`, `currentPage`, `totalPages`, `progressPercent`, `genre`, `tags`, provenance (`source`, `sourceText` = original line), `needsReview` and `reviewReason`, `importKey`, `lastModified`, `deletedAt` (soft delete).

- Unknown data stays null. Nothing is invented.
- `importKey` has a unique index, so retrying an import or restore can't create duplicates.
- Schema version 1 is exported to `app/schemas/`. Destructive migration is **not** enabled: a future schema change must ship an explicit migration, so it can never silently wipe the library.
- Covers are downscaled to at most 1200 px and stored in app-private storage under a new file name on each change. They don't depend on remote URLs staying alive, and they're cached for offline use.
- Android Auto Backup includes the database, covers and settings.

---

## 6. Design system: patterns adopted and why

| Pattern | Source | Why it's in Saeculum |
|---|---|---|
| Cover-first grid; covers at 2:3 with soft shadow and a hairline edge | Bookmory, Letterboxd | Covers are the identity of a shelf; consistent ratios make it read as a bookcase |
| Stars beneath covers; faint outlines (or nothing) for unrated books | Bookmory | Personal ratings visible at a glance, never a fake rating |
| Small status badge on the cover corner; progress underline for books in progress | Bookmory | Status is scannable without extra text |
| 1 / 3 / 6 density selector next to the toolbar | Shelf ("per row") | Your request; 1 column shows rich metadata, 6 shows covers only |
| Rounded detail sheet (~85% height) over a dimmed library, blurred on Android 12+ | Book Tracker / Bookmory detail | Keeps your place in the library while focusing on one book |
| Yearly bar chart, goal ring, ranked lists | Goodreads, Bookmory annual stats | Readable charts only; I skipped pie charts because their slices are hard to compare |
| Six-tab bottom navigation | Shelf | Six destinations were required; short labels keep them legible at 360dp |
| Letterboxd-style dark mode | Letterboxd | Dark mode tuned on its own, not an inverted light theme |

**Palette** (your supplied scheme): crimson `#B32134` (primary), oxblood `#8B0101`, sienna `#A0522C`, parchment `#D8C6B2`, white.

- **Light:** warm paper background `#FAF6F0`, crimson actions, parchment outlines.
- **Dark:** warm near-black `#15100E`, softened crimson `#F0A0A8` for contrast, oxblood containers, parchment as the tertiary accent.
- **Presets:** Saeculum (default), Folio (library green & brass), Midnight Ink (navy & gilt) and Sepia. Each has its own light and dark palette. Optional wallpaper colours on Android 12+.

**Type:** the system serif (Noto Serif on most phones) for the wordmark, book titles, headings and quotations; the system sans-serif for controls and body text. **Shapes:** 6–28dp rounded corners. **Touch targets:** at least 48dp. **Accessibility:** every cover, star and status has a screen-reader description.

**Icon:** a cloth-bound book with a spine and two sienna rules, and an oxblood serif **S** (glyph outline from Noto Serif, SIL Open Font License), on crimson. Adaptive icon with a themed (monochrome) layer for Android 13+. Source: `docs/icon.svg`.

---

## 7. Feature map (prompt section → implementation)

- **Library (§5):** cover grid with 1/3/6 columns (remembered), Add pill at top-left, density selector, sort (11 orders), filter (status, completion year incl. “unknown”, genre/tags, needs-review), search, a toolbar that pins when you scroll, fallback covers (generated title cards, never broken-image icons).
- **Detail (§6):** cover, title, authors, publisher and year, ISBN (selectable), status chips, completion date or year, progress, interactive rating (tap the same star again, or *Clear*, to remove it), multiline notes (save button; unsaved notes are also saved when the sheet closes), edit, replace or remove the cover, delete with confirmation → **Recently Deleted** (restorable for 30 days, with Undo in the snackbar).
- **Adding (§7):**
  - Search: Open Library and Google Books in parallel. You pick the edition, then confirm or correct it in the editor.
  - Barcode: CameraX + on-device ML Kit. The camera permission is requested only on that screen. The ISBN is checksum-validated, and a typed-ISBN fallback is always there.
  - Manual entry: only title and author are required, and it works offline.
  - CSV import: see §9.
  - Duplicate check before saving: open the existing book or add anyway.
- **Status and completion (§8):** six statuses. Completing a book asks for an exact date, a year only, or “don't remember”. Moving out of Completed shows a confirmation explaining the effect on totals. The current year is never assigned automatically.
- **Lists (§9):** Reading (progress, Finished), To Read (Start reading, Finished), Want to Buy (Got it → To Read, Start reading). One record per book; changing status moves it between lists.
- **Statistics (§10):** completed total, this year, reading and to-read counts, library total, goal ring, completions by year (tap a year to see its covers, including “year unknown”), most productive year, change from the previous year, most-read authors (spelling variants such as “C.S Lewis” and “Cs Lewis” are grouped), five-star favourites, average rating and distribution, books in progress. A footnote explains how each figure is counted. Clear empty states.
- **Settings (§11):** light, dark or system mode; presets; wallpaper colours; default density, sort and start screen; ratings, titles and completion years under covers; the caption (hidden, short caption, literary quotation or your own); reading goal; data management.
- **Covers (§12):** cached locally, downscaled, custom covers kept independently of looked-up metadata, consistent placeholder.

**Quotations** are shipped in the app (no network) and limited to wording I could attribute precisely: Augustine (*Confessions* VIII, “Take up and read”), Bacon (“Of Studies”, ×2), Emily Dickinson (“There is no Frigate like a Book”), Ecclesiastes 12:12 (KJV), and C. S. Lewis (“On the Reading of Old Books”). Misattributed favourites such as “We read to know we are not alone” were deliberately left out.

---

## 8. Your reading-history migration (§15)

The original text is bundled unchanged at `app/src/main/assets/seed/novels_read_list.txt`, and you can view it in the app (Settings ▸ Initial reading-list import). On first launch:

| | |
|---|---|
| Entries imported | **81**: 2026: 6 · 2025: 30 · 2024: 8 · 2023: 2 · 2022: 9 · 2021: 15 · 2020: 11 |
| Status | Completed, in the year each entry is listed under (year only, no exact dates) |
| Invented data | None: no ratings, ISBNs, covers or publication years |
| Stated-total check | 2025 says 30 and 30 are listed ✓. **2024 says 9 but 8 are listed**: flagged, nothing changed |
| Uncertain completion years | 0 |
| Flagged for review (16) | No author in the line (e.g. *The Problem of Pain C.s Lewis*, *Kuzuryuu*, *Beastars*, *Mark-Revelation, Ezra, Nehemiah*); section ranges that look incomplete (*Sasori [035-0 ]*, *Lone Wolf And Cub [001-0 ]*); “F” (very short title); *The Abolition of Man* (author split at a hyphen) |
| Possible duplicates (kept, not merged) | *The Four Loves* (2021 & 2020), *The Fable* / *The Fable [038-045]*, *Sasori* / *Sasori [035-0]* |
| Progress markers | “-100%” is stored as 100% progress (plus a note), not left in the title |

Spellings are preserved exactly (e.g. *The Purpose drivien life*, *Lisa Cha*). Shared-surname credits like “Keith & Sheila Gregoire” stay as one credit rather than being split wrongly. Settings ▸ **Find missing covers & details** can then look up covers. A result is applied only when exactly one edition matches both title and author, and only empty fields are filled.

---

## 9. CSV import and export formats

**Import:** at minimum `Book title`, `Author first name`, `Author last name` (the example from the prompt works as-is).

- Optional columns: Additional authors, ISBN, Completion year, Completion date, Reading status, Rating, Publication year, Notes, Genre, Current page, Total pages (plus Publisher, Tags, Progress %, Date started, Date added).
- Column order doesn't matter, and headers are matched flexibly. Goodreads exports are recognised; Goodreads' “Average Rating” is ignored, and a 0 rating counts as unrated. You can re-map any column, or mark that the file has no header row.
- **Preview** before saving: counts, each parsed row, the optional fields found, warnings and errors, and duplicates against both the library and the file itself (Skip / Import anyway per row). You can edit a row's title or authors, exclude rows, and choose a default status for rows without one.
- A completion year or date implies Completed, and nothing else does.
- Ambiguous dates like `03/04/2019` keep only the year.
- **Result summary:** imported, duplicates skipped, excluded, rejected (each with **Fix** → editor), already imported (for retries), and an optional cover and metadata lookup with a “needs attention” list.

**Exports** (Settings ▸ Data management, saved through Android's file picker):

- **CSV:** every field, properly escaped, re-importable (tested round-trip, including commas, quotes and multiline notes).
- **TXT:** grouped by completion year, newest first, in the format you asked for (`Novels Read 2026:` / `• Title by Author` / `Total: N`), then *Completed — Year Unknown*, then each unfinished status.
- **Full backup (.zip):** `backup.json` with every field plus `covers/*.jpg` and your preferences.
- **Restore:** a preview counts new, already-present and likely-duplicate books, then you choose **Merge** (adds only new books) or **Replace** (double-confirmed). A damaged entry is skipped, not fatal.

---

## 10. Privacy and network

- No account, no analytics, no ads.
- Network use is limited to: Open Library (`openlibrary.org`, `covers.openlibrary.org`) and Google Books (`googleapis.com`) for search, ISBN lookup and cover downloads.
- Without a connection every feature except those lookups works, and manual entry is always available.

---

## 11. Known limitations and further work

- **Not yet run on a physical phone** (see §1): barcode scanning, live metadata lookups and the file pickers are untested on hardware.
- **Google Books** without an API key has a shared daily quota. If it's exceeded, search falls back to Open Library results. Add `GOOGLE_BOOKS_API_KEY` for heavier use.
- **Open Library** search returns works, so the “first published” year is labelled as such. Edition-specific details come from ISBN lookups or Google Books.
- **Re-reads:** each record holds one completion. A re-read is logged as another record (allowed by duplicate handling); there's no separate read-history timeline yet.
- **Typography** uses the device's serif rather than a bundled typeface, so it looks slightly different across manufacturers.
- **Layouts** adapt to screen width (grids, scrolling sheets), but tablets and landscape aren't specially laid out.
- **Instrumented tests** (`BookDaoTest`) need a phone or emulator; CI only compiles them.
- **Possible next steps:** collections/shelves, a reading-session timer, a per-book read history, a home-screen widget, and Material You themed icons per preset.
