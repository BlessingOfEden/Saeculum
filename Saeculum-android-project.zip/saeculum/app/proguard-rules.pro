# Saeculum uses no reflection of its own. Room, DataStore, CameraX, ML Kit and Coil ship
# consumer rules. Keep enum names stable because they are persisted (status, sort, theme).
-keepclassmembers enum app.saeculum.** {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
