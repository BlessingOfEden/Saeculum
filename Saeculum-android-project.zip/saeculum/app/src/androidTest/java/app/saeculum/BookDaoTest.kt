package app.saeculum

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import app.saeculum.core.model.Book
import app.saeculum.core.model.ReadingStatus
import app.saeculum.data.db.AppDatabase
import app.saeculum.data.db.toBook
import app.saeculum.data.db.toEntity
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.time.LocalDate

/** On-device database tests (run with ./gradlew connectedAndroidTest). */
@RunWith(AndroidJUnit4::class)
class BookDaoTest {
    private lateinit var db: AppDatabase

    @Before fun setUp() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), AppDatabase::class.java).build()
    }

    @After fun tearDown() = db.close()

    private fun book(title: String, key: String? = null) = Book(
        uuid = "uuid-$title", title = title, authors = listOf("A. Author", "Second Author"),
        status = ReadingStatus.COMPLETED, completedDate = LocalDate.of(2025, 3, 1), completedYear = 2025,
        rating = 4, notes = "multi\nline", tags = listOf("Classics"), dateAdded = 1L, lastModified = 1L, importKey = key,
    )

    @Test fun roundTripsEveryField() = runBlocking {
        val id = db.bookDao().insert(book("Dune").toEntity())
        val loaded = db.bookDao().get(id)!!.toBook()
        assertEquals(book("Dune").copy(id = id), loaded)
    }

    @Test fun importKeyMakesRetriesIdempotent() = runBlocking {
        val dao = db.bookDao()
        dao.insertIgnore(book("Odyssey", key = "csv:abc:2").toEntity())
        val second = dao.insertIgnore(book("Odyssey", key = "csv:abc:2").copy(uuid = "other").toEntity())
        assertEquals(-1L, second)
        assertEquals(1, dao.countLive())
    }

    @Test fun targetedUpdatesDontTouchOtherFields() = runBlocking {
        val dao = db.bookDao()
        val id = dao.insert(book("Utopia").toEntity())
        dao.setNotes(id, "new notes", 5L)
        val b = dao.get(id)!!.toBook()
        assertEquals(4, b.rating)
        assertEquals(2025, b.completedYear)
        dao.setRating(id, null, 6L)
        val c = dao.get(id)!!.toBook()
        assertEquals("new notes", c.notes)
        assertNull(c.rating)
    }

    @Test fun softDeleteHidesFromLibrary() = runBlocking {
        val dao = db.bookDao()
        val id = dao.insert(book("Frankenstein").toEntity())
        dao.setDeletedAt(id, 10L, 10L)
        assertEquals(0, dao.countLive())
        dao.setDeletedAt(id, null, 11L)
        assertEquals(1, dao.countLive())
    }
}
