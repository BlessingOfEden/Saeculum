package app.saeculum

import android.app.Application
import android.content.Context
import app.saeculum.data.BookRepository
import app.saeculum.data.CoverStore
import app.saeculum.data.DataTransfer
import app.saeculum.data.SeedImporter
import app.saeculum.data.SettingsRepository
import app.saeculum.data.db.AppDatabase
import app.saeculum.data.net.MetadataService
import app.saeculum.ui.components.DraftHandoff
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow

/** Manual dependency container: small app, no DI framework needed. */
class AppContainer(context: Context) {
    val appContext: Context = context.applicationContext
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val database: AppDatabase = AppDatabase.build(context)
    val settings = SettingsRepository(context)
    val covers = CoverStore(context)
    val books = BookRepository(database, covers, appScope)
    val metadata = MetadataService(context, BuildConfig.GOOGLE_BOOKS_API_KEY.ifBlank { null })
    val transfer = DataTransfer(context, books, settings, covers)
    val seed = SeedImporter(context, books, settings)
    val handoff = DraftHandoff()

    /** Session-only UI requests shared between screens. */
    val reviewOnlyFilter = MutableStateFlow(false)
    var pendingEnrichIds: List<Long>? = null
}

class SaeculumApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
