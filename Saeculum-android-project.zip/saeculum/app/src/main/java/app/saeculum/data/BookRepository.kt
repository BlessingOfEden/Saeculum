package app.saeculum.data

import androidx.room.withTransaction
import app.saeculum.core.importer.BookIdentity
import app.saeculum.core.importer.DuplicateDetector
import app.saeculum.core.importer.DuplicateMatch
import app.saeculum.core.metadata.MetadataMerge
import app.saeculum.core.metadata.MetadataResult
import app.saeculum.core.model.Book
import app.saeculum.core.model.BookDraft
import app.saeculum.core.model.BookEdits
import app.saeculum.core.model.Completion
import app.saeculum.core.model.ReadingStatus
import app.saeculum.core.model.StatusTransitions
import app.saeculum.data.db.AppDatabase
import app.saeculum.data.db.toBook
import app.saeculum.data.db.toEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate
import java.util.UUID

data class InsertOutcome(val inserted: List<Long>, val alreadyPresent: Int, val failed: List<Pair<Book, String>>)

/**
 * Single source of truth for books. All writes are small, targeted and transactional so that
 * personal data (notes, ratings, completion history) is never clobbered by unrelated edits.
 */
class BookRepository(
    private val db: AppDatabase,
    private val covers: CoverStore,
    private val appScope: CoroutineScope,
) {
    private val dao = db.bookDao()
    private val coverMutex = Mutex()

    val books: Flow<List<Book>> = dao.observeLive().map { list -> list.map { it.toBook() } }
    val trash: Flow<List<Book>> = dao.observeTrash().map { list -> list.map { it.toBook() } }

    fun observe(id: Long): Flow<Book?> = dao.observe(id).map { it?.toBook() }
    suspend fun get(id: Long): Book? = dao.get(id)?.toBook()
    suspend fun liveBooks(): List<Book> = dao.getLive().map { it.toBook() }
    suspend fun allBooks(): List<Book> = dao.getAll().map { it.toBook() }

    fun newUuid(): String = UUID.randomUUID().toString()
    private fun now() = System.currentTimeMillis()

    suspend fun findDuplicate(draft: BookDraft, excludeId: Long? = null): DuplicateMatch<Book>? {
        val pool = liveBooks().filter { it.id != excludeId }
        return DuplicateDetector.find(BookIdentity(draft.title, draft.authors, draft.isbn10, draft.isbn13), pool) { BookIdentity.of(it) }
    }

    /** Adds a single book from the editor. [localCoverPath] is a cover already copied into [CoverStore]. */
    suspend fun add(draft: BookDraft, uuid: String, localCoverPath: String?, source: String): Long {
        val book = draft.toBook(uuid = uuid, now = now(), defaultStatus = ReadingStatus.TO_READ, source = source)
            .copy(coverPath = localCoverPath, coverIsCustom = localCoverPath != null)
        val id = dao.insert(book.toEntity())
        if (localCoverPath == null && book.coverUrl != null) cacheCoverLater(id)
        return id
    }

    /** Saves the full editor using a three-way merge against what's in the database now. */
    suspend fun saveEdits(id: Long, original: Book, edited: Book) {
        var replacedCover: String? = null
        db.withTransaction {
            val current = dao.get(id)?.toBook() ?: throw IllegalStateException("This book no longer exists.")
            val merged = BookEdits.threeWayMerge(current, original, edited, now())
            if (current.coverPath != merged.coverPath) replacedCover = current.coverPath
            dao.update(merged.toEntity())
        }
        replacedCover?.let { covers.delete(it) }
        if (edited.coverPath == null && edited.coverUrl != null && edited.coverUrl != original.coverUrl) cacheCoverLater(id)
    }

    suspend fun setRating(id: Long, rating: Int?) = dao.setRating(id, rating?.takeIf { it in 1..5 }, now())

    suspend fun setNotes(id: Long, notes: String) = dao.setNotes(id, notes, now())

    suspend fun changeStatus(id: Long, status: ReadingStatus, completion: Completion?) {
        db.withTransaction {
            val b = dao.get(id)?.toBook() ?: return@withTransaction
            dao.update(StatusTransitions.apply(b, status, completion, LocalDate.now(), now()).toEntity())
        }
    }

    suspend fun setCompletion(id: Long, completion: Completion) {
        db.withTransaction {
            val b = dao.get(id)?.toBook() ?: return@withTransaction
            if (b.status != ReadingStatus.COMPLETED) return@withTransaction
            val updated = when (completion) {
                is Completion.OnDate -> b.copy(completedDate = completion.date, completedYear = completion.date.year)
                is Completion.InYear -> b.copy(completedDate = null, completedYear = completion.year)
                Completion.Unknown -> b.copy(completedDate = null, completedYear = null)
            }
            dao.update(updated.copy(lastModified = now()).toEntity())
        }
    }

    suspend fun updateProgress(id: Long, currentPage: Int?, totalPages: Int?, percent: Int?, started: LocalDate?) {
        db.withTransaction {
            val b = dao.get(id)?.toBook() ?: return@withTransaction
            dao.update(
                b.copy(
                    currentPage = currentPage,
                    totalPages = totalPages,
                    progressPercent = if (currentPage != null && totalPages != null) null else percent,
                    startedDate = started,
                    lastModified = now(),
                ).toEntity(),
            )
        }
    }

    suspend fun markReviewed(id: Long) = dao.clearReview(id, now())

    // ---------------------------------------------------------------- deletion (soft, restorable)

    suspend fun moveToTrash(id: Long) = dao.setDeletedAt(id, now(), now())
    suspend fun restoreFromTrash(id: Long) = dao.setDeletedAt(id, null, now())

    suspend fun deleteForever(id: Long) {
        val e = dao.get(id) ?: return
        dao.deletePermanently(id)
        covers.delete(e.coverPath)
    }

    /** Permanently removes items that have been in Recently Deleted for more than [days] days. */
    suspend fun purgeTrash(days: Int = 30): Int {
        val cutoff = now() - days * 24L * 60 * 60 * 1000
        val old = dao.trashOlderThan(cutoff)
        old.forEach { dao.deletePermanently(it.id); covers.delete(it.coverPath) }
        return old.size
    }

    // ---------------------------------------------------------------- bulk import / restore

    /**
     * Inserts each book independently: one bad record never blocks the others, and books whose
     * uuid/importKey already exist are skipped (so retrying an import can't create duplicates).
     */
    suspend fun insertAll(books: List<Book>): InsertOutcome {
        val ids = mutableListOf<Long>()
        var present = 0
        val failed = mutableListOf<Pair<Book, String>>()
        for (b in books) {
            try {
                val key = b.importKey
                if (key != null && dao.countImportKey(key) > 0) { present++; continue }
                val id = dao.insertIgnore(b.copy(id = 0).toEntity())
                if (id == -1L) present++ else ids += id
            } catch (e: Exception) {
                failed += b to (e.message ?: "Database error")
            }
        }
        if (ids.isNotEmpty()) cacheMissingCovers()
        return InsertOutcome(ids, present, failed)
    }

    /** Deletes everything and inserts [books] in one transaction (used by "Replace library"). */
    suspend fun replaceAll(books: List<Book>) {
        val oldCovers = dao.getAll().mapNotNull { it.coverPath }.toSet()
        val keep = books.mapNotNull { it.coverPath }.toSet()
        db.withTransaction {
            dao.deleteAll()
            books.forEach { dao.insert(it.copy(id = 0).toEntity()) }
        }
        (oldCovers - keep).forEach { covers.delete(it) }
    }

    // ---------------------------------------------------------------- metadata & covers

    /** Fills only empty bibliographic fields from [result]; returns the names of fields that changed. */
    suspend fun applyMetadata(id: Long, result: MetadataResult): List<String> {
        var changed: List<String> = emptyList()
        db.withTransaction {
            val b = dao.get(id)?.toBook() ?: return@withTransaction
            val outcome = MetadataMerge.fillMissing(b, result, now())
            changed = outcome.changedFields
            if (changed.isNotEmpty()) dao.update(outcome.book.toEntity())
        }
        if ("Cover" in changed) cacheCoverLater(id)
        return changed
    }

    suspend fun setCustomCover(id: Long, localPath: String) {
        var old: String? = null
        db.withTransaction {
            val b = dao.get(id)?.toBook() ?: return@withTransaction
            old = b.coverPath
            dao.update(b.copy(coverPath = localPath, coverIsCustom = true, lastModified = now()).toEntity())
        }
        old?.takeIf { it != localPath }?.let { covers.delete(it) }
    }

    /** Explicitly replaces the cover with a looked-up image (user confirmed). Custom covers are discarded. */
    suspend fun replaceCoverFromUrl(id: Long, url: String) {
        var old: String? = null
        db.withTransaction {
            val b = dao.get(id)?.toBook() ?: return@withTransaction
            old = b.coverPath
            dao.update(b.copy(coverUrl = url, coverPath = null, coverIsCustom = false, lastModified = now()).toEntity())
        }
        old?.let { covers.delete(it) }
        cacheCoverLater(id)
    }

    fun cacheCoverLater(id: Long) {
        appScope.launch { cacheCover(id) }
    }

    private suspend fun cacheCover(id: Long) = coverMutex.withLock {
        val e = dao.get(id) ?: return@withLock
        if (e.coverPath != null || e.coverUrl.isNullOrBlank()) return@withLock
        val path = covers.download(e.coverUrl, e.uuid) ?: return@withLock
        // Re-check: the user may have chosen a custom cover while we were downloading.
        val latest = dao.get(id)
        if (latest != null && latest.coverPath == null) dao.setCoverPath(id, path) else covers.delete(path)
    }

    /** Downloads covers for books that only have a remote URL, so they stay available offline. */
    fun cacheMissingCovers() {
        appScope.launch {
            dao.booksNeedingCoverCache().forEach { cacheCover(it.id) }
        }
    }
}
