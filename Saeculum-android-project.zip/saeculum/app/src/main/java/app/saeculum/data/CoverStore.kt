package app.saeculum.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import app.saeculum.data.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Stores cover images inside the app's private files directory so they never depend on an external
 * URL staying alive. Every image is downsampled to [MAX_EDGE] and re-encoded as JPEG to bound memory
 * and disk use. A new file name is used on each change so image caches never show a stale cover.
 */
class CoverStore(context: Context) {

    private val appContext = context.applicationContext
    val dir: File = File(appContext.filesDir, "covers").apply { mkdirs() }

    private fun newFile(uuid: String) = File(dir, "$uuid-${System.currentTimeMillis()}.jpg")

    /** Copies an image the user picked. Throws [IOException] with a readable message on failure. */
    suspend fun saveFromUri(uri: Uri, uuid: String): String = withContext(Dispatchers.IO) {
        val bytes = appContext.contentResolver.openInputStream(uri)?.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(32 * 1024)
            var total = 0
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                total += n
                if (total > MAX_INPUT_BYTES) throw IOException("That image is too large (over 25 MB).")
                out.write(buf, 0, n)
            }
            out.toByteArray()
        } ?: throw IOException("Couldn't open the selected image.")
        saveBytes(bytes, uuid) ?: throw IOException("That file isn't an image Saeculum can read.")
    }

    /** Downloads and stores a cover; returns the local path or null (best-effort, never throws). */
    suspend fun download(url: String, uuid: String): String? = withContext(Dispatchers.IO) {
        val bytes = Http.getImageBytes(url) ?: return@withContext null
        try {
            saveBytes(bytes, uuid)
        } catch (e: Exception) {
            null
        }
    }

    /** Decodes, orients, downsamples and writes [bytes]. Returns null if they aren't a decodable image. */
    suspend fun saveBytes(bytes: ByteArray, uuid: String): String? = withContext(Dispatchers.IO) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@withContext null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_EDGE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return@withContext null

        val rotation = try {
            when (ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
        val longest = maxOf(bmp.width, bmp.height)
        val scale = if (longest > MAX_EDGE) MAX_EDGE.toFloat() / longest else 1f
        if (rotation != 0f || scale != 1f) {
            val m = Matrix().apply {
                if (scale != 1f) postScale(scale, scale)
                if (rotation != 0f) postRotate(rotation)
            }
            val transformed = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (transformed != bmp) bmp.recycle()
            bmp = transformed
        }
        val file = newFile(uuid)
        try {
            FileOutputStream(file).use { out ->
                if (!bmp.compress(Bitmap.CompressFormat.JPEG, 88, out)) throw IOException("Couldn't save the cover image.")
            }
        } catch (e: IOException) {
            file.delete()
            throw e
        } finally {
            bmp.recycle()
        }
        file.absolutePath
    }

    fun readBytes(path: String?): ByteArray? = try {
        path?.let { File(it) }?.takeIf { it.isFile }?.readBytes()
    } catch (e: Exception) {
        null
    }

    /** Deletes a cover file, but only if it lives inside our covers directory. */
    fun delete(path: String?) {
        if (path.isNullOrBlank()) return
        val f = File(path)
        if (f.parentFile?.canonicalPath == dir.canonicalPath) f.delete()
    }

    fun exists(path: String?): Boolean = !path.isNullOrBlank() && File(path).isFile

    companion object {
        const val MAX_EDGE = 1200
        const val MAX_INPUT_BYTES = 25 * 1024 * 1024
    }
}
