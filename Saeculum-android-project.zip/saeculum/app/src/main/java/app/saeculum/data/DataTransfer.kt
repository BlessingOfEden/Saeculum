package app.saeculum.data

import android.content.Context
import android.net.Uri
import app.saeculum.core.backup.BackupCodec
import app.saeculum.core.backup.BackupData
import app.saeculum.core.backup.RestoreMode
import app.saeculum.core.backup.RestorePlan
import app.saeculum.core.backup.RestorePlanner
import app.saeculum.core.export.CsvExporter
import app.saeculum.core.export.TxtExporter
import app.saeculum.core.model.Book
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class BackupSummary(val books: Int, val covers: Int)

data class RestorePreview(val data: BackupData, val plan: RestorePlan, internal val archive: File?)

data class RestoreOutcome(val restored: Int, val coversRestored: Int, val failed: Int)

/**
 * Exports (CSV, TXT), full backups (ZIP with JSON + covers) and restore. Writes go through the
 * Storage Access Framework URI the user chose; success is reported only after the stream closed.
 */
class DataTransfer(
    private val context: Context,
    private val repo: BookRepository,
    private val settings: SettingsRepository,
    private val covers: CoverStore,
) {
    private val resolver get() = context.contentResolver

    /** "wt" truncates an existing file; a few providers only accept "w". */
    private fun open(uri: Uri): java.io.OutputStream {
        val stream = try {
            resolver.openOutputStream(uri, "wt")
        } catch (e: Exception) {
            resolver.openOutputStream(uri, "w")
        }
        return stream ?: throw IOException("Couldn't open the destination file.")
    }

    suspend fun exportCsv(uri: Uri): Int = withContext(Dispatchers.IO) {
        val books = repo.liveBooks()
        val text = CsvExporter.export(books)
        open(uri).use { it.write(text.toByteArray(Charsets.UTF_8)); it.flush() }
        books.size
    }

    suspend fun exportTxt(uri: Uri): Int = withContext(Dispatchers.IO) {
        val books = repo.liveBooks()
        open(uri).use { it.write(TxtExporter.export(books).toByteArray(Charsets.UTF_8)); it.flush() }
        books.size
    }

    /** Full backup: every book (including Recently Deleted), its local cover, and preferences. */
    suspend fun exportBackup(uri: Uri): BackupSummary = withContext(Dispatchers.IO) {
        val books = repo.allBooks()
        var coverCount = 0
        val entries = books.map { b ->
            val bytes = covers.readBytes(b.coverPath)
            val name = if (bytes != null) "covers/${b.uuid}.jpg" else null
            Triple(b, name, bytes)
        }
        val json = BackupCodec.encode(entries.map { it.first to it.second }, settings.exportable(), System.currentTimeMillis())
        open(uri).use { raw ->
            ZipOutputStream(raw).use { zip ->
                zip.putNextEntry(ZipEntry(BackupCodec.JSON_ENTRY))
                zip.write(json.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                entries.forEach { (_, name, bytes) ->
                    if (name != null && bytes != null) {
                        zip.putNextEntry(ZipEntry(name))
                        zip.write(bytes)
                        zip.closeEntry()
                        coverCount++
                    }
                }
                zip.finish()
            }
        }
        BackupSummary(books.size, coverCount)
    }

    /** Reads a backup (.zip from Saeculum, or a bare backup .json) and plans the restore. */
    suspend fun readBackup(uri: Uri): RestorePreview = withContext(Dispatchers.IO) {
        val tmp = File(context.cacheDir, "restore-${System.currentTimeMillis()}.bin")
        resolver.openInputStream(uri)?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            ?: throw IOException("Couldn't open the selected file.")
        val head = tmp.inputStream().use { s -> ByteArray(2).also { s.read(it) } }
        val isZip = head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte()
        val json = if (isZip) {
            ZipFile(tmp).use { zf ->
                val entry = zf.getEntry(BackupCodec.JSON_ENTRY) ?: throw BackupCodec.InvalidBackupException("This ZIP isn't a Saeculum backup.")
                zf.getInputStream(entry).bufferedReader(Charsets.UTF_8).use { it.readText() }
            }
        } else {
            tmp.readText(Charsets.UTF_8)
        }
        val data = BackupCodec.decode(json)
        val plan = RestorePlanner.plan(data, repo.allBooks())
        val archive: File? = if (isZip) tmp else null
        if (!isZip) tmp.delete()
        RestorePreview(data, plan, archive)
    }

    suspend fun restore(preview: RestorePreview, mode: RestoreMode): RestoreOutcome = withContext(Dispatchers.IO) {
        val toRestore = preview.plan.toRestore(mode)
        var coverCount = 0
        val prepared: List<Book> = try {
            val zf = preview.archive?.let { ZipFile(it) }
            try {
                toRestore.map { bb ->
                    var b = bb.book.copy(id = 0, coverPath = null)
                    val entry = bb.coverFile?.let { zf?.getEntry(it) }
                    if (zf != null && entry != null) {
                        val bytes = zf.getInputStream(entry).use { it.readBytes() }
                        covers.saveBytes(bytes, b.uuid)?.let { path -> b = b.copy(coverPath = path); coverCount++ }
                    }
                    b
                }
            } finally {
                zf?.close()
            }
        } finally {
            preview.archive?.delete()
        }
        val restored: Int
        val failed: Int
        if (mode == RestoreMode.REPLACE) {
            repo.replaceAll(prepared)
            settings.restore(preview.data.settings)
            restored = prepared.size
            failed = 0
        } else {
            val out = repo.insertAll(prepared)
            restored = out.inserted.size
            failed = out.failed.size
        }
        RestoreOutcome(restored, coverCount, failed)
    }

    fun discard(preview: RestorePreview) {
        preview.archive?.delete()
    }
}
