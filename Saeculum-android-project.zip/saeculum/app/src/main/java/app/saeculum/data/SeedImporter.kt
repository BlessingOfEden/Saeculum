package app.saeculum.data

import android.content.Context
import app.saeculum.core.migration.ReadingListParser

data class SeedReport(
    val parse: ReadingListParser.Result,
    val imported: Int,
    val alreadyPresent: Int,
    val failed: Int,
)

/**
 * One-time migration of the user's historical reading list (assets/seed/novels_read_list.txt,
 * kept byte-for-byte as supplied). Idempotent: every row has a stable import key, so a crash or
 * retry can never insert a book twice.
 */
class SeedImporter(
    private val context: Context,
    private val repo: BookRepository,
    private val settings: SettingsRepository,
) {
    companion object {
        const val ASSET = "seed/novels_read_list.txt"
        const val SOURCE = "Novels Read List"
    }

    fun sourceText(): String = context.assets.open(ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() }

    fun parse(): ReadingListParser.Result = ReadingListParser.parse(sourceText())

    /** Runs the migration if it hasn't completed before. Returns the report when it ran. */
    suspend fun runIfNeeded(): SeedReport? {
        // The "share" edition has no bundled reading list: friends start with an empty library.
        if (!app.saeculum.BuildConfig.INCLUDE_READING_HISTORY) return null
        if (settings.current().seedImported) return null
        val result = parse()
        val now = System.currentTimeMillis()
        val books = ReadingListParser.toBooks(result, SOURCE, now) { repo.newUuid() }
        val outcome = repo.insertAll(books)
        if (outcome.failed.isEmpty()) settings.markSeedImported(outcome.inserted.size + outcome.alreadyPresent, now)
        return SeedReport(result, outcome.inserted.size, outcome.alreadyPresent, outcome.failed.size)
    }

    /** Report for the Settings screen (re-parses the bundled original; the database is not modified). */
    suspend fun report(): SeedReport {
        val s = settings.current()
        return SeedReport(parse(), s.seedImportedCount, 0, 0)
    }
}
