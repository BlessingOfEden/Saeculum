package app.saeculum.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.saeculum.core.model.BookFilter
import app.saeculum.core.model.BookSort
import app.saeculum.core.model.CaptionMode
import app.saeculum.core.model.ReadingStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

enum class ThemePreset(val label: String, val description: String) {
    SAECULUM("Saeculum", "Oxblood & parchment"),
    FOLIO("Folio", "Library green & brass"),
    INK("Midnight Ink", "Navy & gilt"),
    SEPIA("Sepia", "Umber & cream"),
}

enum class DarkMode(val label: String) { SYSTEM("System"), LIGHT("Light"), DARK("Dark") }

enum class StartScreen(val label: String) {
    LIBRARY("Library"), READING("Currently Reading"), TO_READ("To Read"), WANT_TO_BUY("Want to Buy"), STATS("Statistics")
}

data class AppSettings(
    val theme: ThemePreset = ThemePreset.SAECULUM,
    val darkMode: DarkMode = DarkMode.SYSTEM,
    val dynamicColor: Boolean = false,
    val columns: Int = 3,
    val sort: BookSort = BookSort.COMPLETED_NEWEST,
    val filter: BookFilter = BookFilter(),
    val captionMode: CaptionMode = CaptionMode.QUOTATION,
    val captionId: String? = null,
    val customCaption: String = "",
    val startScreen: StartScreen = StartScreen.LIBRARY,
    val annualGoal: Int = 0,
    val showRatings: Boolean = true,
    val showTitles: Boolean = true,
    val showCompletionYear: Boolean = false,
    val seedImported: Boolean = false,
    val seedReportSeen: Boolean = false,
    val seedImportedCount: Int = 0,
    val seedImportedAt: Long = 0L,
)

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

/** Persistent preferences (Jetpack DataStore). Every setter is atomic and survives restarts. */
class SettingsRepository(private val context: Context) {

    private object K {
        val theme = stringPreferencesKey("theme")
        val darkMode = stringPreferencesKey("dark_mode")
        val dynamicColor = booleanPreferencesKey("dynamic_color")
        val columns = intPreferencesKey("grid_columns")
        val sort = stringPreferencesKey("sort")
        val filterStatuses = stringPreferencesKey("filter_statuses")
        val filterYears = stringPreferencesKey("filter_years")
        val filterGenres = stringPreferencesKey("filter_genres")
        val captionMode = stringPreferencesKey("caption_mode")
        val captionId = stringPreferencesKey("caption_id")
        val customCaption = stringPreferencesKey("custom_caption")
        val startScreen = stringPreferencesKey("start_screen")
        val annualGoal = intPreferencesKey("annual_goal")
        val showRatings = booleanPreferencesKey("show_ratings")
        val showTitles = booleanPreferencesKey("show_titles")
        val showCompletionYear = booleanPreferencesKey("show_completion_year")
        val seedImported = booleanPreferencesKey("seed_imported")
        val seedReportSeen = booleanPreferencesKey("seed_report_seen")
        val seedImportedCount = intPreferencesKey("seed_imported_count")
        val seedImportedAt = longPreferencesKey("seed_imported_at")
    }

    private inline fun <reified E : Enum<E>> enumOr(value: String?, default: E): E =
        value?.let { v -> enumValues<E>().firstOrNull { it.name == v } } ?: default

    private val SEP = "\u001F"

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            theme = enumOr(p[K.theme], ThemePreset.SAECULUM),
            darkMode = enumOr(p[K.darkMode], DarkMode.SYSTEM),
            dynamicColor = p[K.dynamicColor] ?: false,
            columns = (p[K.columns] ?: 3).let { if (it in setOf(1, 3, 6)) it else 3 },
            sort = BookSort.fromName(p[K.sort] ?: BookSort.COMPLETED_NEWEST.name),
            filter = BookFilter(
                statuses = p[K.filterStatuses].orEmpty().split(SEP).mapNotNull { s -> ReadingStatus.entries.firstOrNull { it.name == s } }.toSet(),
                completionYears = p[K.filterYears].orEmpty().split(SEP).mapNotNull { it.toIntOrNull() }.toSet(),
                genres = p[K.filterGenres].orEmpty().split(SEP).filter { it.isNotBlank() }.toSet(),
            ),
            captionMode = enumOr(p[K.captionMode], CaptionMode.QUOTATION),
            captionId = p[K.captionId],
            customCaption = p[K.customCaption] ?: "",
            startScreen = enumOr(p[K.startScreen], StartScreen.LIBRARY),
            annualGoal = p[K.annualGoal] ?: 0,
            showRatings = p[K.showRatings] ?: true,
            showTitles = p[K.showTitles] ?: true,
            showCompletionYear = p[K.showCompletionYear] ?: false,
            seedImported = p[K.seedImported] ?: false,
            seedReportSeen = p[K.seedReportSeen] ?: false,
            seedImportedCount = p[K.seedImportedCount] ?: 0,
            seedImportedAt = p[K.seedImportedAt] ?: 0L,
        )
    }

    suspend fun current(): AppSettings = settings.first()

    suspend fun setTheme(v: ThemePreset) = context.dataStore.edit { it[K.theme] = v.name }
    suspend fun setDarkMode(v: DarkMode) = context.dataStore.edit { it[K.darkMode] = v.name }
    suspend fun setDynamicColor(v: Boolean) = context.dataStore.edit { it[K.dynamicColor] = v }
    suspend fun setColumns(v: Int) = context.dataStore.edit { it[K.columns] = v }
    suspend fun setSort(v: BookSort) = context.dataStore.edit { it[K.sort] = v.name }
    suspend fun setFilter(f: BookFilter) = context.dataStore.edit {
        it[K.filterStatuses] = f.statuses.joinToString(SEP) { s -> s.name }
        it[K.filterYears] = f.completionYears.joinToString(SEP)
        it[K.filterGenres] = f.genres.joinToString(SEP)
    }
    suspend fun setCaption(mode: CaptionMode, id: String?) = context.dataStore.edit {
        it[K.captionMode] = mode.name
        if (id != null) it[K.captionId] = id else it.remove(K.captionId)
    }
    suspend fun setCustomCaption(text: String) = context.dataStore.edit {
        it[K.customCaption] = text.take(140)
        it[K.captionMode] = CaptionMode.CUSTOM.name
    }
    suspend fun setStartScreen(v: StartScreen) = context.dataStore.edit { it[K.startScreen] = v.name }
    suspend fun setAnnualGoal(v: Int) = context.dataStore.edit { it[K.annualGoal] = v.coerceIn(0, 1000) }
    suspend fun setShowRatings(v: Boolean) = context.dataStore.edit { it[K.showRatings] = v }
    suspend fun setShowTitles(v: Boolean) = context.dataStore.edit { it[K.showTitles] = v }
    suspend fun setShowCompletionYear(v: Boolean) = context.dataStore.edit { it[K.showCompletionYear] = v }
    suspend fun markSeedImported(count: Int, at: Long) = context.dataStore.edit {
        it[K.seedImported] = true
        it[K.seedImportedCount] = count
        it[K.seedImportedAt] = at
    }
    suspend fun markSeedReportSeen() = context.dataStore.edit { it[K.seedReportSeen] = true }

    /** Personal preferences included in a full backup (no internal flags). */
    suspend fun exportable(): Map<String, String> {
        val s = current()
        return mapOf(
            "theme" to s.theme.name, "darkMode" to s.darkMode.name, "dynamicColor" to s.dynamicColor.toString(),
            "columns" to s.columns.toString(), "sort" to s.sort.name, "captionMode" to s.captionMode.name,
            "captionId" to (s.captionId ?: ""), "customCaption" to s.customCaption, "startScreen" to s.startScreen.name,
            "annualGoal" to s.annualGoal.toString(), "showRatings" to s.showRatings.toString(),
            "showTitles" to s.showTitles.toString(), "showCompletionYear" to s.showCompletionYear.toString(),
        )
    }

    suspend fun restore(m: Map<String, String>) = context.dataStore.edit { p ->
        m["theme"]?.let { v -> if (ThemePreset.entries.any { it.name == v }) p[K.theme] = v }
        m["darkMode"]?.let { v -> if (DarkMode.entries.any { it.name == v }) p[K.darkMode] = v }
        m["dynamicColor"]?.toBooleanStrictOrNull()?.let { p[K.dynamicColor] = it }
        m["columns"]?.toIntOrNull()?.takeIf { it in setOf(1, 3, 6) }?.let { p[K.columns] = it }
        m["sort"]?.let { v -> if (BookSort.entries.any { it.name == v }) p[K.sort] = v }
        m["captionMode"]?.let { v -> if (CaptionMode.entries.any { it.name == v }) p[K.captionMode] = v }
        m["captionId"]?.takeIf { it.isNotBlank() }?.let { p[K.captionId] = it }
        m["customCaption"]?.let { p[K.customCaption] = it.take(140) }
        m["startScreen"]?.let { v -> if (StartScreen.entries.any { it.name == v }) p[K.startScreen] = v }
        m["annualGoal"]?.toIntOrNull()?.let { p[K.annualGoal] = it.coerceIn(0, 1000) }
        m["showRatings"]?.toBooleanStrictOrNull()?.let { p[K.showRatings] = it }
        m["showTitles"]?.toBooleanStrictOrNull()?.let { p[K.showTitles] = it }
        m["showCompletionYear"]?.toBooleanStrictOrNull()?.let { p[K.showCompletionYear] = it }
    }
}
