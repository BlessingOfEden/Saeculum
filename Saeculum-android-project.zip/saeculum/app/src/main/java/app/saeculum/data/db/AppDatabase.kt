package app.saeculum.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * Local library database. Schema JSON is exported to app/schemas so every future version can ship
 * an explicit [androidx.room.migration.Migration]; destructive migration is deliberately NOT enabled,
 * so an unhandled schema change fails loudly instead of wiping the library.
 */
@Database(entities = [BookEntity::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun bookDao(): BookDao

    companion object {
        const val NAME = "saeculum.db"

        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, NAME)
                // .addMigrations(MIGRATION_1_2, ...) as the schema evolves
                .build()
    }
}
