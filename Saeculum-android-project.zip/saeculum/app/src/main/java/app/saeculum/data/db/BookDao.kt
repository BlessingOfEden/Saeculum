package app.saeculum.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {

    @Query("SELECT * FROM books WHERE deletedAt IS NULL")
    fun observeLive(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE deletedAt IS NOT NULL ORDER BY deletedAt DESC")
    fun observeTrash(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE id = :id")
    fun observe(id: Long): Flow<BookEntity?>

    @Query("SELECT * FROM books WHERE id = :id")
    suspend fun get(id: Long): BookEntity?

    @Query("SELECT * FROM books WHERE uuid = :uuid")
    suspend fun getByUuid(uuid: String): BookEntity?

    @Query("SELECT * FROM books WHERE deletedAt IS NULL")
    suspend fun getLive(): List<BookEntity>

    @Query("SELECT * FROM books")
    suspend fun getAll(): List<BookEntity>

    @Query("SELECT COUNT(*) FROM books WHERE deletedAt IS NULL")
    suspend fun countLive(): Int

    @Query("SELECT COUNT(*) FROM books WHERE importKey = :key")
    suspend fun countImportKey(key: String): Int

    /** Throws on a uuid/importKey collision so callers notice. */
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: BookEntity): Long

    /** Returns -1 when a row with the same uuid or importKey already exists (safe retries). */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(entity: BookEntity): Long

    @Update
    suspend fun update(entity: BookEntity)

    @Query("UPDATE books SET rating = :rating, lastModified = :now WHERE id = :id")
    suspend fun setRating(id: Long, rating: Int?, now: Long)

    @Query("UPDATE books SET notes = :notes, lastModified = :now WHERE id = :id")
    suspend fun setNotes(id: Long, notes: String, now: Long)

    @Query("UPDATE books SET coverPath = :path WHERE id = :id")
    suspend fun setCoverPath(id: Long, path: String?)

    @Query("UPDATE books SET deletedAt = :at, lastModified = :now WHERE id = :id")
    suspend fun setDeletedAt(id: Long, at: Long?, now: Long)

    @Query("UPDATE books SET needsReview = 0, reviewReason = NULL, lastModified = :now WHERE id = :id")
    suspend fun clearReview(id: Long, now: Long)

    @Query("SELECT * FROM books WHERE deletedAt IS NOT NULL AND deletedAt < :before")
    suspend fun trashOlderThan(before: Long): List<BookEntity>

    @Query("DELETE FROM books WHERE id = :id")
    suspend fun deletePermanently(id: Long)

    @Query("DELETE FROM books")
    suspend fun deleteAll()

    @Query("SELECT * FROM books WHERE deletedAt IS NULL AND coverPath IS NULL AND coverUrl IS NOT NULL")
    suspend fun booksNeedingCoverCache(): List<BookEntity>
}
