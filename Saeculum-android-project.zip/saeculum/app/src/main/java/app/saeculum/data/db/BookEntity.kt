package app.saeculum.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import app.saeculum.core.model.Book
import app.saeculum.core.model.ReadingStatus
import app.saeculum.core.text.Dates

/**
 * Room row for a book. Columns mirror [Book]; dates are ISO-8601 text, lists are joined with
 * the ASCII unit separator (never typed by users). The stable identity is [uuid]; [id] is local.
 */
@Entity(
    tableName = "books",
    indices = [
        Index(value = ["uuid"], unique = true),
        Index(value = ["importKey"], unique = true),
        Index(value = ["status"]),
        Index(value = ["deletedAt"]),
    ],
)
data class BookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uuid: String,
    val title: String,
    val authors: String,
    val isbn10: String?,
    val isbn13: String?,
    val coverUrl: String?,
    val coverPath: String?,
    val coverIsCustom: Boolean,
    val publicationYear: Int?,
    val publisher: String?,
    val status: String,
    val rating: Int?,
    val notes: String,
    val dateAdded: Long,
    val completedDate: String?,
    val completedYear: Int?,
    val startedDate: String?,
    val currentPage: Int?,
    val totalPages: Int?,
    val progressPercent: Int?,
    val genre: String?,
    val tags: String,
    val source: String?,
    val sourceText: String?,
    val needsReview: Boolean,
    val reviewReason: String?,
    val importKey: String?,
    val lastModified: Long,
    val deletedAt: Long?,
)

private const val SEP = "\u001F"

private fun joinList(l: List<String>) = l.joinToString(SEP)
private fun splitList(s: String): List<String> = if (s.isEmpty()) emptyList() else s.split(SEP)

fun BookEntity.toBook(): Book = Book(
    id = id,
    uuid = uuid,
    title = title,
    authors = splitList(authors),
    isbn10 = isbn10,
    isbn13 = isbn13,
    coverUrl = coverUrl,
    coverPath = coverPath,
    coverIsCustom = coverIsCustom,
    publicationYear = publicationYear,
    publisher = publisher,
    status = ReadingStatus.parse(status) ?: ReadingStatus.TO_READ,
    rating = rating?.takeIf { it in 1..5 },
    notes = notes,
    dateAdded = dateAdded,
    completedDate = Dates.parseIsoOrNull(completedDate),
    completedYear = completedYear,
    startedDate = Dates.parseIsoOrNull(startedDate),
    currentPage = currentPage,
    totalPages = totalPages,
    progressPercent = progressPercent,
    genre = genre,
    tags = splitList(tags),
    source = source,
    sourceText = sourceText,
    needsReview = needsReview,
    reviewReason = reviewReason,
    importKey = importKey,
    lastModified = lastModified,
    deletedAt = deletedAt,
)

fun Book.toEntity(): BookEntity = BookEntity(
    id = id,
    uuid = uuid,
    title = title,
    authors = joinList(authors),
    isbn10 = isbn10,
    isbn13 = isbn13,
    coverUrl = coverUrl,
    coverPath = coverPath,
    coverIsCustom = coverIsCustom,
    publicationYear = publicationYear,
    publisher = publisher,
    status = status.name,
    rating = rating,
    notes = notes,
    dateAdded = dateAdded,
    completedDate = completedDate?.toString(),
    completedYear = if (status == ReadingStatus.COMPLETED) (completedDate?.year ?: completedYear) else null,
    startedDate = startedDate?.toString(),
    currentPage = currentPage,
    totalPages = totalPages,
    progressPercent = progressPercent,
    genre = genre,
    tags = joinList(tags),
    source = source,
    sourceText = sourceText,
    needsReview = needsReview,
    reviewReason = reviewReason,
    importKey = importKey,
    lastModified = lastModified,
    deletedAt = deletedAt,
)
