package app.saeculum.data.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import app.saeculum.core.isbn.Isbn
import app.saeculum.core.metadata.GoogleBooksParser
import app.saeculum.core.metadata.MetadataResult
import app.saeculum.core.metadata.MetadataUrls
import app.saeculum.core.metadata.OpenLibraryParser
import app.saeculum.core.model.Authors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/** Outcome of a network lookup. Callers must always offer manual entry on anything but [Found]. */
sealed interface Lookup {
    data class Found(val results: List<MetadataResult>) : Lookup
    data object NoMatch : Lookup
    data object Offline : Lookup
    data class Failed(val message: String) : Lookup
}

class HttpException(val code: Int, message: String) : IOException(message)

object Http {
    private const val USER_AGENT = "Saeculum/1.0 (Android personal reading log)"

    fun getText(url: String, timeoutMs: Int = 12_000): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", USER_AGENT)
            conn.setRequestProperty("Accept", "application/json")
            val code = conn.responseCode
            if (code !in 200..299) {
                val body = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw HttpException(code, GoogleBooksParser.errorMessage(body) ?: "HTTP $code")
            }
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    /** Downloads at most [maxBytes]; returns null for non-images or errors (best-effort). */
    fun getImageBytes(url: String, maxBytes: Int = 8 * 1024 * 1024): ByteArray? {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 12_000
            conn.readTimeout = 15_000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", USER_AGENT)
            if (conn.responseCode !in 200..299) return null
            val type = conn.contentType.orEmpty()
            if (type.isNotEmpty() && !type.startsWith("image/")) return null
            conn.inputStream.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buf = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > maxBytes) return null
                    out.write(buf, 0, n)
                }
                // Open Library sometimes serves a 1x1 placeholder; treat tiny files as "no cover".
                out.toByteArray().takeIf { it.size > 1024 }
            }
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}

/**
 * Public metadata lookups: Open Library (no key) and Google Books (optional key from BuildConfig).
 * Results are suggestions; nothing is saved without the user confirming.
 */
class MetadataService(private val context: Context, private val googleApiKey: String?) {

    fun isOnline(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun describe(e: Throwable): Lookup = when (e) {
        is UnknownHostException -> Lookup.Offline
        is SocketTimeoutException -> Lookup.Failed("The book service took too long to respond.")
        is HttpException -> Lookup.Failed(
            if (e.code == 429) "The book service is busy (rate limited). Try again later." else "The book service returned an error (${e.message}).",
        )
        is IOException -> Lookup.Failed("Couldn't reach the book service.")
        else -> Lookup.Failed("The book service sent data Saeculum couldn't read.")
    }

    private suspend fun <T> attempt(block: () -> T): Result<T> = withContext(Dispatchers.IO) {
        try {
            Result.success(block())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun combine(sources: List<Result<List<MetadataResult>>>): Lookup {
        val ok = sources.filter { it.isSuccess }.flatMap { it.getOrThrow() }
        if (ok.isNotEmpty()) return Lookup.Found(dedupe(ok))
        if (sources.any { it.isSuccess }) return Lookup.NoMatch
        return describe(sources.first().exceptionOrNull() ?: IOException())
    }

    /** Removes exact repeats (same ISBN or same source id) while keeping distinct editions. */
    private fun dedupe(list: List<MetadataResult>): List<MetadataResult> {
        val seen = HashSet<String>()
        return list.filter { r ->
            val key = r.isbn13 ?: r.isbn10 ?: "${r.source}:${r.sourceId}:${r.title}"
            seen.add(key)
        }
    }

    suspend fun search(title: String, author: String?): Lookup {
        if (title.isBlank() && author.isNullOrBlank()) return Lookup.NoMatch
        if (!isOnline()) return Lookup.Offline
        return coroutineScope {
            val ol = async {
                attempt {
                    val url = if (title.isNotBlank()) MetadataUrls.openLibrarySearch(title, author)
                    else MetadataUrls.openLibraryQuery(author.orEmpty())
                    OpenLibraryParser.parseSearch(Http.getText(url))
                }
            }
            val gb = async {
                attempt { GoogleBooksParser.parse(Http.getText(MetadataUrls.googleBooksSearch(title, author, googleApiKey))) }
            }
            combine(listOf(ol.await(), gb.await()))
        }
    }

    suspend fun byIsbn(rawIsbn: String): Lookup {
        val isbn = Isbn.toIsbn13(rawIsbn) ?: return Lookup.Failed("That isn't a valid ISBN.")
        if (!isOnline()) return Lookup.Offline
        return coroutineScope {
            val ol = async { attempt { listOfNotNull(OpenLibraryParser.parseIsbn(Http.getText(MetadataUrls.openLibraryIsbn(isbn)), isbn)) } }
            val gb = async { attempt { GoogleBooksParser.parse(Http.getText(MetadataUrls.googleBooksIsbn(isbn, googleApiKey))) } }
            // Keep only results that really carry this ISBN (or carry none) — a scan isn't proof of identity.
            when (val l = combine(listOf(ol.await(), gb.await()))) {
                is Lookup.Found -> {
                    val filtered = l.results.filter { it.isbn13 == null || it.isbn13 == isbn }
                    if (filtered.isEmpty()) Lookup.NoMatch else Lookup.Found(filtered.map { it.copy(isbn13 = isbn, isbn10 = it.isbn10 ?: Isbn.toIsbn10(isbn)) })
                }
                else -> l
            }
        }
    }

    /** Candidates for enriching an existing record: title plus the primary author's surname. */
    suspend fun candidatesFor(title: String, authors: List<String>): Lookup {
        val author = authors.firstOrNull()?.let { Authors.surname(it) }
        if (!isOnline()) return Lookup.Offline
        val ol = attempt { OpenLibraryParser.parseSearch(Http.getText(MetadataUrls.openLibrarySearch(title, author, limit = 10))) }
        if (ol.getOrNull()?.isNotEmpty() == true) return Lookup.Found(ol.getOrThrow())
        val gb = attempt { GoogleBooksParser.parse(Http.getText(MetadataUrls.googleBooksSearch(title, author, googleApiKey, limit = 10))) }
        return combine(listOf(ol, gb))
    }
}
