@file:OptIn(ExperimentalMaterial3Api::class)

package app.saeculum.ui.add

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn as AndroidXOptIn
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.FlashlightOff
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.NoPhotography
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.saeculum.core.isbn.Isbn
import app.saeculum.data.net.Lookup
import app.saeculum.ui.components.appViewModel
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.launch
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** ML Kit analyzer that only reports barcodes that validate as an ISBN. */
private class IsbnAnalyzer(private val scanner: BarcodeScanner, private val onIsbn: (String) -> Unit) : ImageAnalysis.Analyzer {
    private val done = AtomicBoolean(false)

    @AndroidXOptIn(ExperimentalGetImage::class)
    override fun analyze(image: ImageProxy) {
        val media = image.image
        if (media == null || done.get()) {
            image.close()
            return
        }
        val input = InputImage.fromMediaImage(media, image.imageInfo.rotationDegrees)
        scanner.process(input)
            .addOnSuccessListener { codes ->
                val isbn = codes.firstNotNullOfOrNull { Isbn.fromBarcode(it.rawValue) }
                if (isbn != null && done.compareAndSet(false, true)) onIsbn(isbn)
            }
            .addOnCompleteListener { image.close() }
    }
}

private fun hasCamera(ctx: Context) = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

@Composable
fun ScanScreen(onBack: () -> Unit, onOpenEditor: () -> Unit) {
    val vm = appViewModel { ScanViewModel(it) }
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasCamera(ctx)) }
    var denied by rememberSaveable { mutableStateOf(false) }
    var typed by rememberSaveable { mutableStateOf("") }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        denied = !ok
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Scan a barcode") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            when {
                vm.isbn != null -> LookupPanel(vm, onOpenEditor)
                granted -> {
                    Box(Modifier.fillMaxWidth().aspectRatio(3f / 4f).clip(RoundedCornerShape(20.dp)).background(Color.Black)) {
                        CameraPreview(onIsbn = vm::onIsbn)
                        Box(
                            Modifier.align(Alignment.Center).fillMaxWidth(0.8f).height(120.dp)
                                .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp)),
                        )
                    }
                    Text("Point the camera at the barcode on the back cover. ISBN barcodes usually start with 978 or 979.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> {
                    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Rounded.NoPhotography, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text(if (denied) "Camera access was declined" else "Camera access needed", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (denied) "Saeculum only uses the camera to read book barcodes; nothing is recorded. You can allow it in system settings, or type the ISBN below."
                                else "Saeculum uses the camera only while this screen is open, to read the ISBN barcode. Nothing is recorded or uploaded.",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            Row {
                                Button(onClick = { permission.launch(Manifest.permission.CAMERA) }) { Text("Allow camera") }
                                if (denied) {
                                    Spacer(Modifier.width(8.dp))
                                    OutlinedButton(onClick = {
                                        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)))
                                    }) { Text("Open settings") }
                                }
                            }
                        }
                    }
                }
            }

            if (vm.isbn == null) {
                Text("Or type the ISBN", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
                val valid = Isbn.isValid(typed)
                OutlinedTextField(
                    value = typed,
                    onValueChange = { typed = it.take(17) },
                    label = { Text("ISBN-13 or ISBN-10") },
                    singleLine = true,
                    isError = typed.isNotBlank() && !valid,
                    supportingText = { if (typed.isNotBlank() && !valid) Text("Check the digits — this isn't a valid ISBN.") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { if (valid) Isbn.toIsbn13(typed)?.let(vm::onIsbn) }),
                    modifier = Modifier.fillMaxWidth(),
                )
                Button(enabled = valid, onClick = { Isbn.toIsbn13(typed)?.let(vm::onIsbn) }) { Text("Look up ISBN") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun CameraPreview(onIsbn: (String) -> Unit) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val latest by rememberUpdatedState(onIsbn)
    var camera by remember { mutableStateOf<Camera?>(null) }
    var torch by remember { mutableStateOf(false) }
    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }

    DisposableEffect(lifecycleOwner) {
        val executor: ExecutorService = Executors.newSingleThreadExecutor()
        val scanner = BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A, Barcode.FORMAT_CODE_128)
                .build(),
        )
        val providerFuture = ProcessCameraProvider.getInstance(ctx)
        var provider: ProcessCameraProvider? = null
        providerFuture.addListener({
            try {
                val p = providerFuture.get()
                provider = p
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also { it.setAnalyzer(executor, IsbnAnalyzer(scanner) { isbn -> previewView.post { latest(isbn) } }) }
                p.unbindAll()
                camera = p.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                // No usable back camera: the typed-ISBN path below still works.
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            provider?.unbindAll()
            scanner.close()
            executor.shutdown()
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
        if (camera?.cameraInfo?.hasFlashUnit() == true) {
            IconButton(
                onClick = { torch = !torch; camera?.cameraControl?.enableTorch(torch) },
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
            ) {
                Icon(if (torch) Icons.Rounded.FlashlightOff else Icons.Rounded.FlashlightOn, contentDescription = if (torch) "Turn off torch" else "Turn on torch", tint = Color.White)
            }
        }
    }
}

@Composable
private fun LookupPanel(vm: ScanViewModel, onOpenEditor: () -> Unit) {
    val isbn = vm.isbn ?: return
    Text("ISBN ${Isbn.display(isbn)}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
    if (vm.loading) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.padding(end = 12.dp))
            Text("Looking up this ISBN…")
        }
        return
    }
    when (val l = vm.lookup) {
        is Lookup.Found -> {
            Text(
                "A barcode alone doesn't prove which book this is — check that this matches the book in your hand.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            l.results.forEach { r -> ResultRow(r) { vm.choose(r); onOpenEditor() } }
        }
        Lookup.NoMatch -> Text("No reliable match was found for this ISBN in Open Library or Google Books.", style = MaterialTheme.typography.bodyMedium)
        Lookup.Offline -> Text("You're offline, so the ISBN can't be looked up right now. You can still add the book with this ISBN.", style = MaterialTheme.typography.bodyMedium)
        is Lookup.Failed -> Text(l.message, style = MaterialTheme.typography.bodyMedium)
        null -> Unit
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
        Button(onClick = { vm.manual(); onOpenEditor() }) { Text(if (vm.lookup is Lookup.Found) "Not it — enter manually" else "Enter manually") }
        TextButton(onClick = vm::reset) { Text("Scan again") }
    }
}
