package app.saeculum.ui.add

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.saeculum.AppContainer
import app.saeculum.core.isbn.Isbn
import app.saeculum.core.metadata.MetadataResult
import app.saeculum.core.model.BookDraft
import app.saeculum.data.net.Lookup
import kotlinx.coroutines.launch

class ScanViewModel(private val c: AppContainer) : ViewModel() {
    var isbn by mutableStateOf<String?>(null)
        private set
    var lookup by mutableStateOf<Lookup?>(null)
        private set
    var loading by mutableStateOf(false)
        private set

    fun onIsbn(value: String) {
        if (isbn != null) return
        isbn = value
        loading = true
        viewModelScope.launch {
            lookup = c.metadata.byIsbn(value)
            loading = false
        }
    }

    fun reset() {
        isbn = null
        lookup = null
        loading = false
    }

    fun choose(r: MetadataResult) = c.handoff.put(r.toDraft(), "barcode")

    /** Lookup failed or was wrong: keep the scanned ISBN and let the user type the rest. */
    fun manual() {
        val code = isbn
        val pair = Isbn.normalizePair(code)
        c.handoff.put(BookDraft(isbn10 = pair?.first, isbn13 = pair?.second ?: code), "barcode")
    }
}
