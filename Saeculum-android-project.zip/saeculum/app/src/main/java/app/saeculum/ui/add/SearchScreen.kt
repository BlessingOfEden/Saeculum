@file:OptIn(ExperimentalMaterial3Api::class)

package app.saeculum.ui.add

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.saeculum.core.isbn.Isbn
import app.saeculum.core.metadata.MetadataResult
import app.saeculum.core.model.Book
import app.saeculum.data.net.Lookup
import app.saeculum.ui.components.BookCover
import app.saeculum.ui.components.CoverSource
import app.saeculum.ui.components.EmptyState
import app.saeculum.ui.components.appViewModel
import app.saeculum.ui.theme.LiteraryText

@Composable
fun SearchScreen(
    enrichBookId: Long?,
    onBack: () -> Unit,
    onOpenEditor: () -> Unit,
    onApplied: (String) -> Unit,
) {
    val vm = appViewModel(key = "search-${enrichBookId ?: "new"}") { SearchViewModel(it, enrichBookId) }
    var confirm by remember { mutableStateOf<MetadataResult?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (enrichBookId != null) "Find cover & details" else "Search for a book") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().imePadding()) {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = vm.title, onValueChange = { vm.title = it }, label = { Text("Title") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Next),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = vm.author, onValueChange = { vm.author = it }, label = { Text("Author") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.search() }),
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = vm::search, enabled = !vm.loading && (vm.title.isNotBlank() || vm.author.isNotBlank())) { Text("Search") }
                    Spacer(Modifier.width(12.dp))
                    if (enrichBookId == null) TextButton(onClick = { vm.manualEntry(); onOpenEditor() }) { Text("Enter manually instead") }
                }
            }
            HorizontalDivider(Modifier.padding(top = 12.dp))
            Box(Modifier.fillMaxSize()) {
                when (val r = vm.result) {
                    null -> if (!vm.loading) Text(
                        "Results come from Open Library and Google Books. You'll confirm the details before anything is saved.",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp),
                    )
                    is Lookup.Found -> LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
                        item {
                            Text(
                                "${r.results.size} result${if (r.results.size == 1) "" else "s"} — choose the matching edition",
                                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                            )
                        }
                        items(r.results) { res ->
                            ResultRow(res) {
                                if (enrichBookId != null) {
                                    confirm = res
                                } else {
                                    vm.chooseForNewBook(res)
                                    onOpenEditor()
                                }
                            }
                        }
                        if (enrichBookId == null) {
                            item {
                                TextButton(onClick = { vm.manualEntry(); onOpenEditor() }, modifier = Modifier.padding(16.dp)) { Text("None of these — enter manually") }
                            }
                        }
                    }
                    Lookup.NoMatch -> EmptyState(
                        Icons.Rounded.SearchOff, "No reliable match found",
                        "Open Library and Google Books didn't return a book for this search. Check the spelling, or add it yourself — an ISBN and cover are optional.",
                        action = { if (enrichBookId == null) Button(onClick = { vm.manualEntry(); onOpenEditor() }) { Text("Enter manually") } },
                    )
                    Lookup.Offline -> EmptyState(
                        Icons.Rounded.CloudOff, "You're offline",
                        "Book search needs an internet connection. You can still add the book manually now and look up its cover later.",
                        action = { if (enrichBookId == null) Button(onClick = { vm.manualEntry(); onOpenEditor() }) { Text("Enter manually") } },
                    )
                    is Lookup.Failed -> EmptyState(
                        Icons.Rounded.ErrorOutline, "Search didn't work", r.message,
                        action = {
                            Row {
                                OutlinedButton(onClick = vm::search) { Text("Try again") }
                                if (enrichBookId == null) {
                                    Spacer(Modifier.width(8.dp))
                                    Button(onClick = { vm.manualEntry(); onOpenEditor() }) { Text("Enter manually") }
                                }
                            }
                        },
                    )
                }
                if (vm.loading) CircularProgressIndicator(Modifier.align(Alignment.TopCenter).padding(top = 32.dp))
            }
        }
    }

    confirm?.let { res ->
        val book = vm.target
        val hasCover = book != null && (book.coverPath != null || book.coverUrl != null)
        var replaceCover by remember(res) { mutableStateOf(!hasCover) }
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Use this edition?") },
            text = {
                Column {
                    Text("Empty fields (cover, ISBN, publisher, year, pages) will be filled from “${res.displayTitle}”. Your title, rating, notes, status and dates are not changed.")
                    if (hasCover && res.coverUrl != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp).clickable(role = Role.Checkbox) { replaceCover = !replaceCover }) {
                            Checkbox(checked = replaceCover, onCheckedChange = null)
                            Text("  Replace the current cover")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    vm.applyToExisting(res, replaceCover && hasCover) { onApplied(vm.applied ?: "Updated.") }
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } },
        )
    }
}

@Composable
fun ResultRow(r: MetadataResult, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Box(Modifier.width(58.dp)) {
            BookCover(CoverSource(r.title, r.authors.firstOrNull().orEmpty(), null, r.coverUrl, r.sourceId ?: r.title), Modifier.fillMaxWidth(), elevation = 1.dp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(r.displayTitle, style = LiteraryText.bookTitle, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (r.authors.isNotEmpty()) Text(r.authors.joinToString(", "), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            val pub = listOfNotNull(
                r.publicationYear?.let { if (r.yearIsFirstPublished) "First published $it" else "Published $it" },
                r.publisher,
                r.pageCount?.let { "$it pp." },
            ).joinToString(" · ")
            if (pub.isNotEmpty()) Text(pub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
            (r.isbn13 ?: r.isbn10)?.let { Text("ISBN ${Isbn.display(it)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline) }
            Text(r.source, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(top = 2.dp))
        }
    }
    Spacer(Modifier.height(2.dp))
}
