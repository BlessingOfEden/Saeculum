package app.saeculum.ui.add

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.saeculum.AppContainer
import app.saeculum.core.metadata.MetadataResult
import app.saeculum.core.model.Book
import app.saeculum.core.model.BookDraft
import app.saeculum.data.net.Lookup
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class SearchViewModel(private val c: AppContainer, val enrichBookId: Long?) : ViewModel() {
    var title by mutableStateOf("")
    var author by mutableStateOf("")
    var loading by mutableStateOf(false)
        private set
    var result by mutableStateOf<Lookup?>(null)
        private set
    var target by mutableStateOf<Book?>(null)
        private set
    var applied by mutableStateOf<String?>(null)
    private var job: Job? = null

    init {
        if (enrichBookId != null) {
            viewModelScope.launch {
                val b = c.books.get(enrichBookId)
                target = b
                if (b != null) {
                    title = b.title
                    author = b.authors.firstOrNull().orEmpty()
                    search()
                }
            }
        }
    }

    fun search() {
        if (title.isBlank() && author.isBlank()) return
        job?.cancel()
        job = viewModelScope.launch {
            loading = true
            result = c.metadata.search(title.trim(), author.trim().ifEmpty { null })
            loading = false
        }
    }

    /** Hands the chosen result to the editor so the user can confirm or correct it before saving. */
    fun chooseForNewBook(r: MetadataResult) = c.handoff.put(r.toDraft(), "search")

    fun manualEntry() = c.handoff.put(
        BookDraft(title = title.trim(), authors = listOfNotNull(author.trim().ifEmpty { null })),
        "manual",
    )

    fun applyToExisting(r: MetadataResult, replaceCover: Boolean, onDone: () -> Unit) {
        val id = enrichBookId ?: return
        viewModelScope.launch {
            val changed = c.books.applyMetadata(id, r).toMutableList()
            if (replaceCover && r.coverUrl != null && "Cover" !in changed) {
                c.books.replaceCoverFromUrl(id, r.coverUrl!!)
                changed += "Cover"
            }
            applied = if (changed.isEmpty()) "Nothing new — the book already has these details." else "Updated: ${changed.joinToString(", ")}."
            onDone()
        }
    }
}
