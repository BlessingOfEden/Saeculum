package app.saeculum.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.saeculum.AppContainer
import app.saeculum.core.model.BookDraft

val LocalAppContainer = staticCompositionLocalOf<AppContainer> { error("AppContainer not provided") }

/** Creates a ViewModel with access to the app container. */
@Composable
inline fun <reified VM : ViewModel> appViewModel(key: String? = null, crossinline create: (AppContainer) -> VM): VM {
    val container = LocalAppContainer.current
    return viewModel(key = key, factory = viewModelFactory { initializer { create(container) } })
}

/**
 * Hands an unsaved draft (from search, scan or a CSV row to fix) to the editor screen without
 * serialising it into a navigation route.
 */
class DraftHandoff {
    private var draft: BookDraft? = null
    private var source: String? = null

    /** Status to use for a new book started from a reading-list screen (e.g. Want to Buy). */
    var preferredStatus: app.saeculum.core.model.ReadingStatus? = null

    fun put(d: BookDraft, src: String) {
        draft = d
        source = src
    }

    fun take(): Pair<BookDraft, String>? {
        val d = draft ?: return null
        val s = source ?: "manual"
        draft = null
        source = null
        return d to s
    }
}
