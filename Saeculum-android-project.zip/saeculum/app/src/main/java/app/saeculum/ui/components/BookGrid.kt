@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package app.saeculum.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.saeculum.core.model.Book
import app.saeculum.core.model.ReadingStatus
import app.saeculum.ui.theme.LiteraryText

/** Display options shared by the library and the reading-list screens. */
data class GridOptions(
    val columns: Int,
    val showRatings: Boolean = true,
    val showTitles: Boolean = true,
    val showCompletionYear: Boolean = false,
)

/**
 * The cover grid. Header content (title, toolbar, chips) is passed as full-width items so the whole
 * screen scrolls as one surface. 1 column = rich rows; 3 = cover + stars + title; 6 = compact covers.
 */
@Composable
fun BookGrid(
    books: List<Book>,
    options: GridOptions,
    onOpen: (Book) -> Unit,
    modifier: Modifier = Modifier,
    state: LazyGridState = rememberLazyGridState(),
    contentPadding: PaddingValues = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
    rowAction: (@Composable (Book) -> Unit)? = null,
    header: LazyGridScope.() -> Unit = {},
    footer: LazyGridScope.() -> Unit = {},
) {
    val cols = options.columns.coerceIn(1, 6)
    val hGap = when (cols) { 1 -> 0.dp; 3 -> 14.dp; else -> 6.dp }
    val vGap = when (cols) { 1 -> 10.dp; 3 -> 18.dp; else -> 10.dp }
    LazyVerticalGrid(
        columns = GridCells.Fixed(cols),
        state = state,
        modifier = modifier,
        contentPadding = contentPadding,
        horizontalArrangement = Arrangement.spacedBy(hGap),
        verticalArrangement = Arrangement.spacedBy(vGap),
    ) {
        header()
        items(books, key = { it.id }, contentType = { cols }) { book ->
            when (cols) {
                1 -> BookRow(book, options, onOpen, rowAction)
                3 -> BookTile(book, options, onOpen, compact = false)
                else -> BookTile(book, options, onOpen, compact = true)
            }
        }
        footer()
    }
}

/** Full-width item helper for grid headers. */
fun LazyGridScope.fullWidth(key: Any? = null, content: @Composable () -> Unit) {
    item(key = key, span = { GridItemSpan(maxLineSpan) }, contentType = "full") { content() }
}

@Composable
private fun BookTile(book: Book, options: GridOptions, onOpen: (Book) -> Unit, compact: Boolean) {
    Column(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClickLabel = "Open details", role = Role.Button) { onOpen(book) },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box {
            BookCover(book.coverSource(), Modifier.fillMaxWidth(), corner = if (compact) 4.dp else 6.dp, elevation = if (compact) 1.5.dp else 3.dp)
            StatusBadge(
                book.status,
                if (compact) 16.dp else 26.dp,
                Modifier.align(Alignment.BottomStart).padding(if (compact) 2.dp else 5.dp),
            )
        }
        if (book.status == ReadingStatus.READING) {
            book.progressFraction?.let { f ->
                LinearProgressIndicator(
                    progress = { f },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(if (compact) 2.dp else 3.dp).clip(RoundedCornerShape(2.dp)),
                )
            }
        }
        if (options.showRatings) {
            BoxWithConstraints(Modifier.fillMaxWidth().padding(top = if (compact) 3.dp else 6.dp)) {
                val star = (maxWidth / 5).coerceAtMost(if (compact) 11.dp else 16.dp)
                if (star >= 7.dp) {
                    StarsDisplay(book.rating, star, Modifier.align(Alignment.Center), hideWhenUnrated = compact)
                }
            }
        }
        if (!compact && options.showTitles) {
            Text(
                book.title,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            )
        }
        if (options.showCompletionYear && book.effectiveCompletionYear != null) {
            Text(
                book.effectiveCompletionYear.toString(),
                style = MaterialTheme.typography.labelSmall,
                fontSize = if (compact) 9.sp else 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun BookRow(book: Book, options: GridOptions, onOpen: (Book) -> Unit, rowAction: (@Composable (Book) -> Unit)?) {
    Surface(
        onClick = { onOpen(book) },
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.width(84.dp)) {
                BookCover(book.coverSource(), Modifier.fillMaxWidth(), corner = 5.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(book.title, style = LiteraryText.bookTitle.copy(fontSize = 17.sp, lineHeight = 22.sp), maxLines = 3, overflow = TextOverflow.Ellipsis)
                if (book.authors.isNotEmpty()) {
                    Text(
                        book.authorLine,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusLabel(book)
                }
                if (options.showRatings) {
                    StarsDisplay(book.rating, 16.dp, Modifier.padding(top = 6.dp))
                }
                if (book.status == ReadingStatus.READING || book.status == ReadingStatus.PAUSED) {
                    book.progressFraction?.let { f ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                            LinearProgressIndicator(progress = { f }, modifier = Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)))
                            Spacer(Modifier.width(8.dp))
                            Text(progressText(book), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (rowAction != null) {
                    Spacer(Modifier.height(6.dp))
                    rowAction(book)
                }
            }
        }
    }
}

@Composable
fun StatusLabel(book: Book) {
    val text = when (book.status) {
        ReadingStatus.COMPLETED -> book.completedDate?.let { "Completed ${formatDate(it)}" }
            ?: book.completedYear?.let { "Completed $it" } ?: "Completed · year unknown"
        else -> book.status.label
    }
    Text(text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
}

fun progressText(book: Book): String {
    val cp = book.currentPage
    val tp = book.totalPages
    return when {
        cp != null && tp != null -> "p. $cp / $tp"
        book.progressPercentDisplay != null -> "${book.progressPercentDisplay}%"
        else -> ""
    }
}

private val dateFormatter: java.time.format.DateTimeFormatter =
    java.time.format.DateTimeFormatter.ofLocalizedDate(java.time.format.FormatStyle.MEDIUM)

fun formatDate(d: java.time.LocalDate): String = d.format(dateFormatter)
