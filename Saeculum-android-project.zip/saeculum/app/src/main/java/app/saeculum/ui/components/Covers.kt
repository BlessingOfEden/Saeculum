package app.saeculum.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.saeculum.core.model.Book
import app.saeculum.ui.theme.Saeculum
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.io.File

const val COVER_RATIO = 2f / 3f

/** Anything that can be drawn as a cover: a stored book or an unsaved draft/search result. */
data class CoverSource(val title: String, val author: String, val localPath: String?, val url: String?, val seed: String = title)

fun Book.coverSource() = CoverSource(title, authorLine, coverPath, coverUrl, uuid)

/**
 * A book cover at a fixed 2:3 ratio. The generated fallback is always drawn underneath, so a missing,
 * slow or failed image never shows a broken-image icon. Covers far from 2:3 are letterboxed rather
 * than heavily cropped.
 */
@Composable
fun BookCover(
    source: CoverSource,
    modifier: Modifier = Modifier,
    corner: Dp = 6.dp,
    elevation: Dp = 3.dp,
    showFallbackText: Boolean = true,
) {
    val shape = RoundedCornerShape(corner)
    val colors = Saeculum.colors
    val model: Any? = source.localPath?.let { File(it) }?.takeIf { it.exists() } ?: source.url
    var fit by remember(model) { mutableStateOf(false) }
    Box(
        modifier
            .aspectRatio(COVER_RATIO)
            .shadow(elevation, shape, ambientColor = colors.coverShadow, spotColor = colors.coverShadow)
            .clip(shape)
            .border(0.75.dp, colors.coverEdge, shape)
            .semantics { contentDescription = "Cover of ${source.title}" },
    ) {
        FallbackCover(source, showFallbackText)
        if (model != null) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current).data(model).crossfade(180).build(),
                contentDescription = null,
                contentScale = if (fit) ContentScale.Fit else ContentScale.Crop,
                onSuccess = { state ->
                    val s: Size = state.painter.intrinsicSize
                    if (s.width > 0f && s.height > 0f) {
                        val ratio = s.width / s.height
                        fit = ratio < 0.5f || ratio > 0.85f
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (fit) Modifier.background(colors.onFallbackCover) else Modifier),
            )
        }
    }
}

@Composable
private fun FallbackCover(source: CoverSource, showText: Boolean) {
    val colors = Saeculum.colors
    val bg = colors.fallbackCovers[Math.floorMod(source.seed.hashCode(), colors.fallbackCovers.size)]
    BoxWithConstraints(Modifier.fillMaxSize().background(bg)) {
        val w = maxWidth
        val inset = if (w < 60.dp) 3.dp else 6.dp
        Box(
            Modifier
                .fillMaxSize()
                .padding(inset)
                .border(0.75.dp, colors.onFallbackCover.copy(alpha = 0.35f), RoundedCornerShape(2.dp)),
        )
        if (showText) {
            if (w < 60.dp) {
                Text(
                    source.title.trim().take(1).uppercase(),
                    color = colors.onFallbackCover,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = (w.value * 0.42f).sp,
                    modifier = Modifier.align(Alignment.Center),
                )
            } else {
                val titleSize = when {
                    w < 100.dp -> 10.sp
                    w < 160.dp -> 13.sp
                    else -> 18.sp
                }
                Column(
                    Modifier.fillMaxSize().padding(horizontal = inset + 6.dp, vertical = inset + 10.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        source.title,
                        color = colors.onFallbackCover,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = titleSize,
                        lineHeight = titleSize * 1.15f,
                        textAlign = TextAlign.Center,
                        maxLines = 5,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Box(Modifier.height(1.dp).fillMaxWidth(0.3f).background(colors.onFallbackCover.copy(alpha = 0.5f)))
                    Text(
                        source.author.ifBlank { " " },
                        color = colors.onFallbackCover.copy(alpha = 0.85f),
                        fontSize = (titleSize.value * 0.75f).sp,
                        textAlign = TextAlign.Center,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

/** Neutral placeholder colour used behind thumbnails in lists. */
val CoverPlaceholder = Color(0x14000000)
