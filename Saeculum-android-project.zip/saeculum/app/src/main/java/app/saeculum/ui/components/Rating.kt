package app.saeculum.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.saeculum.ui.theme.Saeculum

/** Read-only stars. Unrated books show faint outlines (or nothing when [hideWhenUnrated]). */
@Composable
fun StarsDisplay(rating: Int?, size: Dp, modifier: Modifier = Modifier, hideWhenUnrated: Boolean = false) {
    if (rating == null && hideWhenUnrated) return
    val c = Saeculum.colors
    Row(
        modifier.semantics(mergeDescendants = true) {
            contentDescription = if (rating == null) "Unrated" else "Rated $rating of 5 stars"
        },
        horizontalArrangement = Arrangement.spacedBy(0.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (i in 1..5) {
            val filled = rating != null && i <= rating
            Icon(
                imageVector = if (filled) Icons.Rounded.Star else Icons.Rounded.StarOutline,
                contentDescription = null,
                tint = if (filled) c.star else c.starEmpty,
                modifier = Modifier.size(size),
            )
        }
    }
}

/**
 * Interactive 1–5 star control. Tapping the current rating again clears it. Each star is a
 * 48dp touch target with its own accessibility label.
 */
@Composable
fun RatingControl(rating: Int?, onRate: (Int?) -> Unit, modifier: Modifier = Modifier, starSize: Dp = 34.dp) {
    val c = Saeculum.colors
    Row(
        modifier.semantics { stateDescription = if (rating == null) "Unrated" else "$rating of 5 stars" },
        horizontalArrangement = Arrangement.spacedBy(0.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (i in 1..5) {
            val filled = rating != null && i <= rating
            IconButton(
                onClick = { onRate(if (rating == i) null else i) },
                modifier = Modifier.semantics {
                    role = Role.Button
                    selected = rating == i
                    contentDescription = if (rating == i) "Clear rating" else "Rate $i star${if (i > 1) "s" else ""}"
                },
            ) {
                Icon(
                    imageVector = if (filled) Icons.Rounded.Star else Icons.Rounded.StarOutline,
                    contentDescription = null,
                    tint = if (filled) c.star else c.starEmpty.copy(alpha = 0.6f),
                    modifier = Modifier.size(starSize),
                )
            }
        }
    }
}
