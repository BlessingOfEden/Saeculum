package app.saeculum.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PauseCircle
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.saeculum.core.model.ReadingStatus

fun ReadingStatus.icon(): ImageVector = when (this) {
    ReadingStatus.WANT_TO_BUY -> Icons.Rounded.ShoppingBag
    ReadingStatus.TO_READ -> Icons.Rounded.Bookmark
    ReadingStatus.READING -> Icons.Rounded.AutoStories
    ReadingStatus.COMPLETED -> Icons.Rounded.CheckCircle
    ReadingStatus.PAUSED -> Icons.Rounded.PauseCircle
    ReadingStatus.ABANDONED -> Icons.Rounded.Block
}

/** Small round badge in a cover corner for every status except Completed (the default state of a shelf). */
@Composable
fun StatusBadge(status: ReadingStatus, size: Dp, modifier: Modifier = Modifier) {
    if (status == ReadingStatus.COMPLETED) return
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.92f),
        contentColor = MaterialTheme.colorScheme.primary,
        shadowElevation = 2.dp,
        modifier = modifier.size(size),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(status.icon(), contentDescription = status.label, modifier = Modifier.padding(size * 0.18f))
        }
    }
}
