@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package app.saeculum.ui.detail

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.HideImage
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.ImageSearch
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.AssistChip
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.saeculum.core.isbn.Isbn
import app.saeculum.core.model.Book
import app.saeculum.core.model.Completion
import app.saeculum.core.model.ReadingStatus
import app.saeculum.core.model.StatusTransitions
import app.saeculum.ui.components.BookCover
import app.saeculum.ui.components.ConfirmDialog
import app.saeculum.ui.components.RatingControl
import app.saeculum.ui.components.coverSource
import app.saeculum.ui.components.formatDate
import app.saeculum.ui.components.icon
import app.saeculum.ui.components.appViewModel
import app.saeculum.ui.components.progressText
import app.saeculum.ui.theme.LiteraryText
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId

/**
 * The detail surface: a rounded bottom sheet at ~85% height over a dimmed (and, on Android 12+,
 * blurred) library. Ratings and notes save directly; status changes ask for confirmation where
 * completion history would be lost.
 */
@Composable
fun BookDetailSheet(
    bookId: Long,
    onDismiss: () -> Unit,
    onEdit: (Long) -> Unit,
    onFindDetails: (Long) -> Unit,
    onMessage: (String) -> Unit,
    onTrashed: (id: Long, title: String) -> Unit,
) {
    val vm = appViewModel(key = "detail-$bookId") { DetailViewModel(it, bookId) }
    val book by vm.book.collectAsStateWithLifecycle()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    LaunchedEffect(vm) { vm.messages.collect { onMessage(it) } }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        val b = book
        Box(Modifier.fillMaxWidth().fillMaxHeight(0.86f)) {
            if (b == null) {
                Text("Loading…", modifier = Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.outline)
            } else {
                DetailContent(
                    b, vm,
                    onEdit = { onEdit(b.id) },
                    onFindDetails = { onFindDetails(b.id) },
                    onDeleted = {
                        onDismiss()
                        onTrashed(b.id, b.title)
                    },
                )
            }
        }
    }
}

@Composable
private fun DetailContent(b: Book, vm: DetailViewModel, onEdit: () -> Unit, onFindDetails: () -> Unit, onDeleted: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var leaveCompletedFor by remember { mutableStateOf<ReadingStatus?>(null) }
    var completionFor by remember { mutableStateOf<ReadingStatus?>(null) }
    var editCompletion by remember { mutableStateOf(false) }
    var editProgress by remember { mutableStateOf(false) }
    val pickCover = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let { vm.setCover(it) } }

    fun requestStatus(s: ReadingStatus) {
        when {
            s == b.status -> Unit
            StatusTransitions.requiresConfirmation(b, s) -> leaveCompletedFor = s
            StatusTransitions.needsCompletionInput(b, s) -> completionFor = s
            else -> vm.changeStatus(s, null)
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .imePadding()
            .navigationBarsPadding()
            .padding(horizontal = 22.dp)
            .padding(bottom = 24.dp),
    ) {
        // Header: cover + bibliographic info
        Row(verticalAlignment = Alignment.Top) {
            Box(Modifier.width(118.dp)) { BookCover(b.coverSource(), Modifier.fillMaxWidth(), corner = 6.dp, elevation = 6.dp) }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.Top) {
                    Text(b.title, style = LiteraryText.bookTitleLarge.copy(fontSize = MaterialTheme.typography.headlineSmall.fontSize), modifier = Modifier.weight(1f))
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, contentDescription = "More actions") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Edit details") }, leadingIcon = { Icon(Icons.Rounded.Edit, null) }, onClick = { menu = false; onEdit() })
                            DropdownMenuItem(text = { Text("Find cover & details") }, leadingIcon = { Icon(Icons.Rounded.ImageSearch, null) }, onClick = { menu = false; onFindDetails() })
                            DropdownMenuItem(
                                text = { Text("Choose cover from device") }, leadingIcon = { Icon(Icons.Rounded.Image, null) },
                                onClick = { menu = false; pickCover.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            )
                            if (b.coverPath != null || b.coverUrl != null) {
                                DropdownMenuItem(text = { Text("Remove cover") }, leadingIcon = { Icon(Icons.Rounded.HideImage, null) }, onClick = { menu = false; vm.removeCover() })
                            }
                            DropdownMenuItem(
                                text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                                leadingIcon = { Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error) },
                                onClick = { menu = false; confirmDelete = true },
                            )
                        }
                    }
                }
                if (b.authors.isNotEmpty()) {
                    Text(b.authorLine, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                } else {
                    Text("Author unknown", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(top = 4.dp))
                }
                val pub = listOfNotNull(b.publisher, b.publicationYear?.let { "Published $it" }).joinToString(" · ")
                if (pub.isNotEmpty()) Text(pub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 6.dp))
                b.primaryIsbn?.let { isbn ->
                    SelectionContainer {
                        Text("ISBN ${Isbn.display(isbn)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }

        if (b.needsReview) {
            Surface(color = MaterialTheme.colorScheme.tertiaryContainer, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Flag, contentDescription = null, tint = MaterialTheme.colorScheme.onTertiaryContainer, modifier = Modifier.size(18.dp))
                        Text("  Please check this imported record", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onTertiaryContainer)
                    }
                    b.reviewReason?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onTertiaryContainer, modifier = Modifier.padding(top = 4.dp)) }
                    b.sourceText?.let { Text("Original: “$it”", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onTertiaryContainer, modifier = Modifier.padding(top = 4.dp)) }
                    Row(Modifier.padding(top = 6.dp)) {
                        TextButton(onClick = onEdit) { Text("Edit") }
                        TextButton(onClick = vm::markReviewed) { Text("Looks right") }
                    }
                }
            }
        }

        // Status
        Text("Status", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 20.dp, bottom = 6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ReadingStatus.entries.forEach { s ->
                FilterChip(
                    selected = b.status == s,
                    onClick = { requestStatus(s) },
                    label = { Text(s.shortLabel) },
                    leadingIcon = { Icon(s.icon(), contentDescription = null, modifier = Modifier.size(18.dp)) },
                )
            }
        }
        if (b.isCompleted) {
            val text = when {
                b.completedDate != null -> "Finished ${formatDate(b.completedDate!!)}"
                b.completedYear != null -> "Finished in ${b.completedYear}"
                else -> "Finished — date not recorded"
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                Text(text, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = { editCompletion = true }) { Text("Change") }
            }
        }

        // Progress (optional)
        val showProgress = b.status == ReadingStatus.READING || b.status == ReadingStatus.PAUSED || b.progressFraction != null || b.startedDate != null
        if (showProgress) {
            Text("Progress", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 16.dp, bottom = 6.dp))
            b.progressFraction?.let { f ->
                LinearProgressIndicator(progress = { f }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)))
                Text(
                    listOf(progressText(b), b.progressPercentDisplay?.takeIf { b.currentPage != null }?.let { "$it%" }).filterNotNull().filter { it.isNotEmpty() }.joinToString(" · "),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
            b.startedDate?.let { Text("Started ${formatDate(it)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            OutlinedButton(onClick = { editProgress = true }, modifier = Modifier.padding(top = 6.dp)) {
                Text(if (b.progressFraction == null) "Track progress" else "Update progress")
            }
        }

        // Rating
        Text("Your rating", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            RatingControl(b.rating, onRate = vm::rate, starSize = 32.dp)
            if (b.rating != null) TextButton(onClick = { vm.rate(null) }) { Text("Clear") } else Text("  Unrated", color = MaterialTheme.colorScheme.outline)
        }

        NotesEditor(b, onSave = vm::saveNotes)

        // Details
        val chips = buildList {
            b.totalPages?.let { add("$it pages") }
            b.genre?.let { add(it) }
            addAll(b.tags.map { "#$it" })
            add("Added ${formatDate(Instant.ofEpochMilli(b.dateAdded).atZone(ZoneId.systemDefault()).toLocalDate())}")
            b.source?.let { add("Imported: ${if (it == "csv") "CSV file" else it}") }
        }
        if (chips.isNotEmpty()) {
            Text("Details", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                chips.forEach { AssistChip(onClick = {}, label = { Text(it, maxLines = 1, overflow = TextOverflow.Ellipsis) }) }
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 22.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilledTonalButton(onClick = onEdit, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(18.dp)); Text("  Edit")
            }
            OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.error)
                Text("  Delete", color = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = "Delete this book?",
            message = "“${b.title}” will move to Recently Deleted in Settings, where you can restore it for 30 days. After that it is removed permanently.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = { vm.moveToTrash(); onDeleted() },
            onDismiss = { confirmDelete = false },
        )
    }
    leaveCompletedFor?.let { target ->
        val year = b.effectiveCompletionYear
        ConfirmDialog(
            title = "Move out of Completed?",
            message = "“${b.title}” is recorded as completed" + (year?.let { " in $it" } ?: "") +
                ". Changing it to ${target.label} removes its completion date, so it will no longer count in your completed totals" +
                (year?.let { " for $it" } ?: "") + ".",
            confirmLabel = "Change status",
            onConfirm = {
                if (StatusTransitions.needsCompletionInput(b, target)) completionFor = target else vm.changeStatus(target, null)
            },
            onDismiss = { leaveCompletedFor = null },
        )
    }
    completionFor?.let { target ->
        CompletionDialog(
            title = "When did you finish it?",
            initial = null,
            onConfirm = { vm.changeStatus(target, it) },
            onDismiss = { completionFor = null },
        )
    }
    if (editCompletion) {
        CompletionDialog("Completion date", b.currentCompletion(), onConfirm = vm::setCompletion, onDismiss = { editCompletion = false })
    }
    if (editProgress) {
        ProgressDialog(b, onSave = vm::updateProgress, onDismiss = { editProgress = false })
    }
}

/** Multiline notes. Saved with the button, and also when the sheet closes with unsaved changes. */
@Composable
private fun NotesEditor(b: Book, onSave: (String) -> Unit) {
    var text by rememberSaveable(b.id) { mutableStateOf(b.notes) }
    var savedText by rememberSaveable(b.id) { mutableStateOf(b.notes) }
    // Adopt external changes (e.g. from the editor) when the user has no unsaved edits.
    LaunchedEffect(b.notes) {
        if (text == savedText) text = b.notes
        savedText = b.notes
    }
    val dirty = text != savedText
    val latestText by rememberUpdatedState(text)
    val latestSaved by rememberUpdatedState(savedText)
    DisposableEffect(b.id) {
        onDispose { if (latestText != latestSaved) onSave(latestText) }
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 18.dp)) {
        Text("Notes", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
        if (dirty) {
            TextButton(onClick = { text = savedText }) { Text("Discard") }
            FilledTonalButton(onClick = { onSave(text); savedText = text }) { Text("Save notes") }
        }
    }
    OutlinedTextField(
        value = text,
        onValueChange = { text = it },
        placeholder = { Text("Thoughts, quotes, where you found it, preferred edition…") },
        minLines = 4,
        maxLines = 14,
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
        shape = MaterialTheme.shapes.medium,
    )
}
