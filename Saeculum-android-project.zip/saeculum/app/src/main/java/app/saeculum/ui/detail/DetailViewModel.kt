package app.saeculum.ui.detail

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.saeculum.AppContainer
import app.saeculum.core.model.Book
import app.saeculum.core.model.Completion
import app.saeculum.core.model.ReadingStatus
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class DetailViewModel(private val c: AppContainer, val id: Long) : ViewModel() {
    val book: StateFlow<Book?> = c.books.observe(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages: SharedFlow<String> = _messages

    private fun launchSafe(block: suspend () -> Unit) = viewModelScope.launch {
        try {
            block()
        } catch (e: Exception) {
            _messages.tryEmit(e.message ?: "Something went wrong.")
        }
    }

    fun rate(r: Int?) = launchSafe { c.books.setRating(id, r) }
    fun saveNotes(text: String) = launchSafe { c.books.setNotes(id, text) }
    fun changeStatus(s: ReadingStatus, completion: Completion?) = launchSafe { c.books.changeStatus(id, s, completion) }
    fun setCompletion(completion: Completion) = launchSafe { c.books.setCompletion(id, completion) }
    fun updateProgress(cp: Int?, tp: Int?, pc: Int?, started: LocalDate?) = launchSafe { c.books.updateProgress(id, cp, tp, pc, started) }
    fun markReviewed() = launchSafe { c.books.markReviewed(id) }
    fun moveToTrash() = launchSafe { c.books.moveToTrash(id) }

    fun setCover(uri: Uri) = launchSafe {
        val b = c.books.get(id) ?: return@launchSafe
        val path = c.covers.saveFromUri(uri, b.uuid)
        c.books.setCustomCover(id, path)
        _messages.tryEmit("Cover updated.")
    }

    fun removeCover() = launchSafe {
        val b = c.books.get(id) ?: return@launchSafe
        val edited = b.copy(coverPath = null, coverUrl = null, coverIsCustom = false)
        c.books.saveEdits(id, b, edited)
    }
}
