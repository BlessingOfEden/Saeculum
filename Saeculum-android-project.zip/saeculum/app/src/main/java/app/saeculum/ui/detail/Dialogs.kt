@file:OptIn(ExperimentalMaterial3Api::class)

package app.saeculum.ui.detail

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.saeculum.core.model.Book
import app.saeculum.core.model.Completion
import app.saeculum.core.text.Dates
import app.saeculum.ui.components.formatDate
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

private fun LocalDate.toUtcMillis(): Long = atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
private fun Long.utcToLocalDate(): LocalDate = Instant.ofEpochMilli(this).atZone(ZoneOffset.UTC).toLocalDate()

/** Material date picker limited to today or earlier (reading dates can't be in the future). */
@Composable
fun PastDatePickerDialog(initial: LocalDate?, onPick: (LocalDate) -> Unit, onDismiss: () -> Unit) {
    val todayMillis = LocalDate.now().toUtcMillis()
    val state = rememberDatePickerState(
        initialSelectedDateMillis = (initial ?: LocalDate.now()).toUtcMillis(),
        selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long): Boolean = utcTimeMillis <= todayMillis
            override fun isSelectableYear(year: Int): Boolean = year in Dates.MIN_YEAR..LocalDate.now().year
        },
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { state.selectedDateMillis?.let { onPick(it.utcToLocalDate()) }; onDismiss() }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    ) {
        DatePicker(state = state)
    }
}

private enum class CompletionKind { DATE, YEAR, UNKNOWN }

/**
 * Records when a book was finished. The user chooses an exact date, a year only (no invented month
 * or day), or "don't remember".
 */
@Composable
fun CompletionDialog(
    title: String,
    initial: Completion?,
    onConfirm: (Completion) -> Unit,
    onDismiss: () -> Unit,
) {
    var kind by remember {
        mutableStateOf(
            when (initial) {
                is Completion.InYear -> CompletionKind.YEAR
                Completion.Unknown -> CompletionKind.UNKNOWN
                else -> CompletionKind.DATE
            },
        )
    }
    var date by remember { mutableStateOf((initial as? Completion.OnDate)?.date ?: LocalDate.now()) }
    var yearText by remember { mutableStateOf(((initial as? Completion.InYear)?.year ?: LocalDate.now().year).toString()) }
    var pickDate by remember { mutableStateOf(false) }
    val year = yearText.toIntOrNull()
    val yearValid = year != null && year in Dates.MIN_YEAR..LocalDate.now().year

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                ChoiceRow("On a specific date", kind == CompletionKind.DATE) { kind = CompletionKind.DATE }
                if (kind == CompletionKind.DATE) {
                    OutlinedButton(onClick = { pickDate = true }, modifier = Modifier.padding(start = 48.dp)) {
                        Icon(Icons.Rounded.CalendarMonth, contentDescription = null)
                        Text("  " + formatDate(date))
                    }
                }
                ChoiceRow("In a year (exact date unknown)", kind == CompletionKind.YEAR) { kind = CompletionKind.YEAR }
                if (kind == CompletionKind.YEAR) {
                    OutlinedTextField(
                        value = yearText,
                        onValueChange = { yearText = it.filter { c -> c.isDigit() }.take(4) },
                        label = { Text("Year") },
                        singleLine = true,
                        isError = !yearValid,
                        supportingText = { if (!yearValid) Text("Enter a year up to ${LocalDate.now().year}") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.padding(start = 48.dp).fillMaxWidth(),
                    )
                }
                ChoiceRow("I don't remember", kind == CompletionKind.UNKNOWN) { kind = CompletionKind.UNKNOWN }
                Text(
                    "Completion dates are separate from publication dates and the date you added the book.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = kind != CompletionKind.YEAR || yearValid,
                onClick = {
                    onConfirm(
                        when (kind) {
                            CompletionKind.DATE -> Completion.OnDate(date)
                            CompletionKind.YEAR -> Completion.InYear(year!!)
                            CompletionKind.UNKNOWN -> Completion.Unknown
                        },
                    )
                    onDismiss()
                },
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
    if (pickDate) PastDatePickerDialog(date, onPick = { date = it }, onDismiss = { pickDate = false })
}

@Composable
private fun ChoiceRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().selectable(selected = selected, onClick = onClick, role = Role.RadioButton).padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Text(label, modifier = Modifier.padding(start = 12.dp))
    }
}

fun Book.currentCompletion(): Completion? = when {
    completedDate != null -> Completion.OnDate(completedDate!!)
    completedYear != null -> Completion.InYear(completedYear!!)
    isCompleted -> Completion.Unknown
    else -> null
}

/** Optional progress: by pages (current/total) or by percentage, plus an optional start date. */
@Composable
fun ProgressDialog(book: Book, onSave: (currentPage: Int?, totalPages: Int?, percent: Int?, started: LocalDate?) -> Unit, onDismiss: () -> Unit) {
    var byPages by remember { mutableStateOf(book.totalPages != null || book.progressPercent == null) }
    var current by remember { mutableStateOf(book.currentPage?.toString() ?: "") }
    var total by remember { mutableStateOf(book.totalPages?.toString() ?: "") }
    var percent by remember { mutableStateOf(book.progressPercent?.toString() ?: "") }
    var started by remember { mutableStateOf(book.startedDate) }
    var pickStart by remember { mutableStateOf(false) }

    val cp = current.toIntOrNull()
    val tp = total.toIntOrNull()
    val pc = percent.toIntOrNull()
    val error = when {
        byPages && tp != null && tp <= 0 -> "Total pages must be more than 0."
        byPages && cp != null && tp != null && cp > tp -> "Current page is past the last page."
        !byPages && pc != null && pc !in 0..100 -> "Percentage must be 0–100."
        else -> null
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reading progress") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(selected = byPages, onClick = { byPages = true }, shape = SegmentedButtonDefaults.itemShape(0, 2)) { Text("Pages") }
                    SegmentedButton(selected = !byPages, onClick = { byPages = false }, shape = SegmentedButtonDefaults.itemShape(1, 2)) { Text("Percent") }
                }
                if (byPages) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        NumberField("Current page", current, { current = it }, Modifier.weight(1f))
                        NumberField("Total pages", total, { total = it }, Modifier.weight(1f))
                    }
                } else {
                    NumberField("Percent read", percent, { percent = it.take(3) }, Modifier.fillMaxWidth())
                }
                OutlinedButton(onClick = { pickStart = true }) {
                    Icon(Icons.Rounded.CalendarMonth, contentDescription = null)
                    Text("  " + (started?.let { "Started ${formatDate(it)}" } ?: "Add start date (optional)"))
                }
                if (started != null) TextButton(onClick = { started = null }) { Text("Remove start date") }
                if (error != null) Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text("Progress is optional — leave fields empty to not track it.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton(enabled = error == null, onClick = {
                if (byPages) onSave(cp, tp, null, started) else onSave(null, book.totalPages, pc, started)
                onDismiss()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
    if (pickStart) PastDatePickerDialog(started, onPick = { started = it }, onDismiss = { pickStart = false })
}

@Composable
fun NumberField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter { c -> c.isDigit() }.take(6)) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier,
    )
}
