@file:OptIn(ExperimentalMaterial3Api::class)

package app.saeculum.ui.editor

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.saeculum.core.model.BookValidator
import app.saeculum.core.model.Completion
import app.saeculum.core.model.ReadingStatus
import app.saeculum.ui.components.BookCover
import app.saeculum.ui.components.ConfirmDialog
import app.saeculum.ui.components.CoverSource
import app.saeculum.ui.components.DropdownSelector
import app.saeculum.ui.components.RatingControl
import app.saeculum.ui.components.SectionHeader
import app.saeculum.ui.components.appViewModel
import app.saeculum.ui.components.formatDate
import app.saeculum.ui.detail.CompletionDialog
import app.saeculum.ui.detail.NumberField
import app.saeculum.ui.detail.PastDatePickerDialog

@Composable
fun EditorScreen(
    bookId: Long?,
    onClose: () -> Unit,
    onSaved: (id: Long, isNew: Boolean) -> Unit,
    onOpenExisting: (Long) -> Unit,
) {
    val vm = appViewModel(key = "editor-${bookId ?: "new"}") { EditorViewModel(it, bookId) }
    val f = vm.form
    val snackbar = remember { SnackbarHostState() }
    var confirmDiscard by remember { mutableStateOf(false) }
    var confirmDropCompletion by remember { mutableStateOf(false) }
    var completionDialog by remember { mutableStateOf(false) }
    var startedPicker by remember { mutableStateOf(false) }
    val pickCover = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let { vm.pickCover(it) } }

    LaunchedEffect(vm.event) {
        when (val e = vm.event) {
            is EditorEvent.Saved -> { vm.consumeEvent(); onSaved(e.id, e.isNew) }
            null -> Unit
        }
    }
    LaunchedEffect(vm.message) {
        vm.message?.let { snackbar.showSnackbar(it); vm.message = null }
    }
    val attemptClose: () -> Unit = {
        if (vm.isDirty) {
            confirmDiscard = true
        } else {
            onClose()
        }
    }
    BackHandler(enabled = vm.isDirty) { confirmDiscard = true }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (vm.isNew) "Add book" else "Edit book") },
                navigationIcon = { IconButton(onClick = attemptClose) { Icon(Icons.Rounded.Close, contentDescription = "Close") } },
                actions = {
                    if (vm.saving) CircularProgressIndicator(Modifier.size(22.dp).padding(end = 4.dp), strokeWidth = 2.dp)
                    TextButton(enabled = !vm.saving && !vm.loading, onClick = {
                        if (vm.wouldDropCompletion()) confirmDropCompletion = true else vm.save()
                    }) { Text("Save") }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        if (vm.loading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // Cover
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                Box(Modifier.width(96.dp)) {
                    BookCover(CoverSource(f.title.ifBlank { "Untitled" }, f.authors.firstOrNull().orEmpty(), f.coverPath, f.coverUrl), Modifier.fillMaxWidth())
                }
                Spacer(Modifier.width(16.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { pickCover.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                        Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp)); Text("  Choose image")
                    }
                    if (f.coverPath != null || f.coverUrl != null) {
                        TextButton(onClick = vm::removeCover) { Text("Remove cover") }
                    }
                    Text(
                        if (f.coverPath == null && f.coverUrl == null) "No cover — a generated one is shown." else if (f.coverIsCustom) "Your image" else "Cover from book search",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            OutlinedTextField(
                value = f.title,
                onValueChange = { vm.update(f.copy(title = it)) },
                label = { Text("Title *") },
                isError = vm.errors.containsKey(BookValidator.TITLE),
                supportingText = { vm.errors[BookValidator.TITLE]?.let { Text(it) } },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth(),
            )
            f.authors.forEachIndexed { i, a ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = a,
                        onValueChange = { v -> vm.update(f.copy(authors = f.authors.toMutableList().also { it[i] = v })) },
                        label = { Text(if (i == 0) "Author *" else "Author ${i + 1}") },
                        isError = i == 0 && vm.errors.containsKey(BookValidator.AUTHOR),
                        supportingText = { if (i == 0) vm.errors[BookValidator.AUTHOR]?.let { Text(it) } },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Next),
                        modifier = Modifier.weight(1f),
                    )
                    if (f.authors.size > 1) {
                        IconButton(onClick = { vm.update(f.copy(authors = f.authors.filterIndexed { j, _ -> j != i })) }) {
                            Icon(Icons.Rounded.RemoveCircleOutline, contentDescription = "Remove author")
                        }
                    }
                }
            }
            TextButton(onClick = { vm.update(f.copy(authors = f.authors + "")) }) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp)); Text(" Add another author")
            }

            SectionHeader("Reading")
            DropdownSelector(
                label = "Status",
                options = ReadingStatus.entries,
                selected = f.status,
                optionLabel = { it.label },
                onSelect = { s ->
                    vm.update(f.copy(status = s, completion = if (s == ReadingStatus.COMPLETED) (f.completion ?: Completion.Unknown) else f.completion))
                },
                modifier = Modifier.fillMaxWidth(),
            )
            if (f.status == ReadingStatus.COMPLETED) {
                val c = f.completion ?: Completion.Unknown
                val label = when (c) {
                    is Completion.OnDate -> "Finished ${formatDate(c.date)}"
                    is Completion.InYear -> "Finished in ${c.year}"
                    Completion.Unknown -> "Completion date not recorded"
                }
                OutlinedButton(onClick = { completionDialog = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp)); Text("  $label")
                }
            }
            Text("Your rating", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(verticalAlignment = Alignment.CenterVertically) {
                RatingControl(f.rating, onRate = { vm.update(f.copy(rating = it)) }, starSize = 30.dp)
                if (f.rating != null) TextButton(onClick = { vm.update(f.copy(rating = null)) }) { Text("Clear") }
            }

            SectionHeader("Progress (optional)")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NumberField("Current page", f.currentPage, { vm.update(f.copy(currentPage = it)) }, Modifier.weight(1f))
                NumberField("Total pages", f.totalPages, { vm.update(f.copy(totalPages = it)) }, Modifier.weight(1f))
            }
            NumberField("…or percent read", f.percent, { vm.update(f.copy(percent = it.take(3))) }, Modifier.fillMaxWidth())
            (vm.errors[BookValidator.PAGES] ?: vm.errors[BookValidator.PERCENT])?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { startedPicker = true }) {
                    Text(f.startedDate?.let { "Started ${formatDate(it)}" } ?: "Add start date")
                }
                if (f.startedDate != null) TextButton(onClick = { vm.update(f.copy(startedDate = null)) }) { Text("Clear") }
            }

            SectionHeader("Book details")
            OutlinedTextField(
                value = f.isbn,
                onValueChange = { vm.update(f.copy(isbn = it.take(20))) },
                label = { Text("ISBN-13 or ISBN-10") },
                isError = vm.errors.containsKey(BookValidator.ISBN),
                supportingText = { Text(vm.errors[BookValidator.ISBN] ?: "Optional") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = f.publisher,
                onValueChange = { vm.update(f.copy(publisher = it)) },
                label = { Text("Publisher") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = f.publicationYear,
                onValueChange = { vm.update(f.copy(publicationYear = it.filter { c -> c.isDigit() }.take(4))) },
                label = { Text("Publication year") },
                isError = vm.errors.containsKey(BookValidator.YEAR),
                supportingText = { vm.errors[BookValidator.YEAR]?.let { Text(it) } },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = f.genre,
                onValueChange = { vm.update(f.copy(genre = it)) },
                label = { Text("Genre") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = f.tags,
                onValueChange = { vm.update(f.copy(tags = it)) },
                label = { Text("Tags") },
                supportingText = { Text("Separate with commas, e.g. Classics, Theology") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            SectionHeader("Notes")
            OutlinedTextField(
                value = f.notes,
                onValueChange = { vm.update(f.copy(notes = it)) },
                placeholder = { Text("Thoughts, quotes, preferred edition, where you encountered it…") },
                minLines = 5,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { if (vm.wouldDropCompletion()) confirmDropCompletion = true else vm.save() }, enabled = !vm.saving, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                Text(if (vm.isNew) "Add to library" else "Save changes")
            }
        }
    }

    if (completionDialog) {
        CompletionDialog("When did you finish it?", f.completion, onConfirm = { vm.update(f.copy(completion = it)) }, onDismiss = { completionDialog = false })
    }
    if (startedPicker) {
        PastDatePickerDialog(f.startedDate, onPick = { vm.update(f.copy(startedDate = it)) }, onDismiss = { startedPicker = false })
    }
    if (confirmDiscard) {
        ConfirmDialog(
            title = "Discard changes?",
            message = "Your edits to this book haven't been saved.",
            confirmLabel = "Discard",
            destructive = true,
            onConfirm = onClose,
            onDismiss = { confirmDiscard = false },
            dismissLabel = "Keep editing",
        )
    }
    if (confirmDropCompletion) {
        ConfirmDialog(
            title = "Remove completion record?",
            message = "Changing the status from Completed removes this book's completion date, so it will no longer count in your completed totals.",
            confirmLabel = "Save anyway",
            onConfirm = { vm.save() },
            onDismiss = { confirmDropCompletion = false },
        )
    }
    vm.duplicate?.let { d ->
        val existing = d.target
        AlertDialog(
            onDismissRequest = vm::dismissDuplicate,
            title = { Text("Already in your library?") },
            text = {
                Text(
                    "“${existing.title}”" + (existing.authorLine.takeIf { it.isNotEmpty() }?.let { " by $it" } ?: "") +
                        " looks like the same book (${d.reason.description.lowercase()}). You can open it, or add this as a separate copy or edition.",
                )
            },
            confirmButton = { TextButton(onClick = { vm.dismissDuplicate(); vm.save(allowDuplicate = true) }) { Text("Add anyway") } },
            dismissButton = {
                Row {
                    TextButton(onClick = vm::dismissDuplicate) { Text("Cancel") }
                    TextButton(onClick = { vm.dismissDuplicate(); onOpenExisting(existing.id) }) { Text("Open existing") }
                }
            },
        )
    }
}
