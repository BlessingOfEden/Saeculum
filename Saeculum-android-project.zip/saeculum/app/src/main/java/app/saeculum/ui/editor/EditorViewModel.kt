package app.saeculum.ui.editor

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.saeculum.AppContainer
import app.saeculum.core.importer.DuplicateMatch
import app.saeculum.core.isbn.Isbn
import app.saeculum.core.model.Book
import app.saeculum.core.model.BookDraft
import app.saeculum.core.model.BookEdits
import app.saeculum.core.model.BookValidator
import app.saeculum.core.model.Completion
import app.saeculum.core.model.ReadingStatus
import app.saeculum.core.text.Dates
import kotlinx.coroutines.launch
import java.time.LocalDate

/** Editable form state. Numbers are kept as text so partially typed values never get lost. */
data class EditorForm(
    val title: String = "",
    val authors: List<String> = listOf(""),
    val isbn: String = "",
    val publisher: String = "",
    val publicationYear: String = "",
    val status: ReadingStatus = ReadingStatus.TO_READ,
    val completion: Completion? = null,
    val startedDate: LocalDate? = null,
    val currentPage: String = "",
    val totalPages: String = "",
    val percent: String = "",
    val rating: Int? = null,
    val notes: String = "",
    val genre: String = "",
    val tags: String = "",
    val coverPath: String? = null,
    val coverUrl: String? = null,
    val coverIsCustom: Boolean = false,
)

sealed interface EditorEvent {
    data class Saved(val id: Long, val isNew: Boolean) : EditorEvent
}

class EditorViewModel(private val c: AppContainer, private val bookId: Long?) : ViewModel() {

    var form by mutableStateOf(EditorForm())
        private set
    var errors by mutableStateOf<Map<String, String>>(emptyMap())
        private set
    var loading by mutableStateOf(bookId != null)
        private set
    var saving by mutableStateOf(false)
        private set
    var duplicate by mutableStateOf<DuplicateMatch<Book>?>(null)
        private set
    var message by mutableStateOf<String?>(null)
    var event by mutableStateOf<EditorEvent?>(null)
        private set
    var source: String = "manual"
        private set

    val isNew: Boolean get() = bookId == null
    private var original: Book? = null
    private var initialForm = EditorForm()
    private val uuid: String = c.books.newUuid()
    private var saved = false

    val isDirty: Boolean get() = form != initialForm

    init {
        if (bookId != null) {
            viewModelScope.launch {
                val b = c.books.get(bookId)
                original = b
                if (b != null) form = formFrom(b)
                initialForm = form
                loading = false
            }
        } else {
            val handed = c.handoff.take()
            val preferred = c.handoff.preferredStatus
            c.handoff.preferredStatus = null
            if (handed != null) {
                source = handed.second
                form = formFrom(handed.first)
                if (handed.first.status == null && preferred != null) form = form.copy(status = preferred)
            } else if (preferred != null) {
                form = form.copy(status = preferred)
            }
            initialForm = form
        }
    }

    private fun formFrom(d: BookDraft) = EditorForm(
        title = d.title,
        authors = d.authors.ifEmpty { listOf("") },
        isbn = d.isbn13 ?: d.isbn10 ?: "",
        publisher = d.publisher.orEmpty(),
        publicationYear = d.publicationYear?.toString().orEmpty(),
        status = d.status ?: ReadingStatus.TO_READ,
        completion = when {
            d.completedDate != null -> Completion.OnDate(d.completedDate!!)
            d.completedYear != null -> Completion.InYear(d.completedYear!!)
            d.status == ReadingStatus.COMPLETED -> Completion.Unknown
            else -> null
        },
        startedDate = d.startedDate,
        currentPage = d.currentPage?.toString().orEmpty(),
        totalPages = d.totalPages?.toString().orEmpty(),
        percent = d.progressPercent?.toString().orEmpty(),
        rating = d.rating,
        notes = d.notes,
        genre = d.genre.orEmpty(),
        tags = d.tags.joinToString(", "),
        coverUrl = d.coverUrl,
    )

    private fun formFrom(b: Book) = formFrom(BookDraft.from(b)).copy(
        coverPath = b.coverPath,
        coverUrl = b.coverUrl,
        coverIsCustom = b.coverIsCustom,
    )

    fun update(f: EditorForm) {
        form = f
        if (errors.isNotEmpty()) errors = validate(toDraft(f)).errors
    }

    private fun toDraft(f: EditorForm): BookDraft {
        val isbnClean = Isbn.clean(f.isbn)
        val pair = Isbn.normalizePair(isbnClean)
        val completed = f.status == ReadingStatus.COMPLETED
        return BookDraft(
            title = f.title.trim(),
            authors = f.authors.map { it.trim() }.filter { it.isNotEmpty() },
            isbn10 = pair?.first ?: if (isbnClean.length == 10) isbnClean else null,
            isbn13 = pair?.second ?: if (isbnClean.isNotEmpty() && isbnClean.length != 10) isbnClean else null,
            coverUrl = f.coverUrl,
            publicationYear = f.publicationYear.trim().toIntOrNull(),
            publisher = f.publisher.trim().ifEmpty { null },
            status = f.status,
            rating = f.rating,
            notes = f.notes,
            completedDate = if (completed) (f.completion as? Completion.OnDate)?.date else null,
            completedYear = if (completed) (f.completion as? Completion.InYear)?.year else null,
            startedDate = f.startedDate,
            currentPage = f.currentPage.toIntOrNull(),
            totalPages = f.totalPages.toIntOrNull(),
            progressPercent = f.percent.toIntOrNull(),
            genre = f.genre.trim().ifEmpty { null },
            tags = f.tags.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() },
        )
    }

    private fun validate(d: BookDraft): BookValidator.Problems {
        val p = BookValidator.validate(d)
        val extra = mutableMapOf<String, String>()
        if (form.publicationYear.isNotBlank() && d.publicationYear == null) extra[BookValidator.YEAR] = "Enter a 4-digit year."
        if (d.publicationYear != null && d.publicationYear!! !in 0..Dates.maxYear()) extra[BookValidator.YEAR] = "Publication year looks wrong."
        return p.copy(errors = p.errors + extra)
    }

    /** True when the save would discard an existing completion record (the UI confirms first). */
    fun wouldDropCompletion(): Boolean {
        val o = original ?: return false
        return o.isCompleted && form.status != ReadingStatus.COMPLETED && (o.completedDate != null || o.completedYear != null)
    }

    fun pickCover(uri: Uri) = viewModelScope.launch {
        try {
            val path = c.covers.saveFromUri(uri, original?.uuid ?: uuid)
            val previous = form.coverPath
            // Delete a cover picked earlier in this same session (never the saved one).
            if (previous != null && previous != original?.coverPath) c.covers.delete(previous)
            form = form.copy(coverPath = path, coverIsCustom = true)
        } catch (e: Exception) {
            message = e.message ?: "Couldn't use that image."
        }
    }

    fun removeCover() {
        val previous = form.coverPath
        if (previous != null && previous != original?.coverPath) c.covers.delete(previous)
        form = form.copy(coverPath = null, coverUrl = null, coverIsCustom = false)
    }

    fun save(allowDuplicate: Boolean = false) {
        if (saving) return
        val draft = toDraft(form)
        val problems = validate(draft)
        errors = problems.errors
        if (!problems.ok) {
            message = "Please fix the highlighted fields."
            return
        }
        saving = true
        viewModelScope.launch {
            try {
                if (bookId == null) {
                    if (!allowDuplicate) {
                        val dup = c.books.findDuplicate(draft)
                        if (dup != null) {
                            duplicate = dup
                            return@launch
                        }
                    }
                    val id = c.books.add(draft, uuid, form.coverPath, source)
                    saved = true
                    event = EditorEvent.Saved(id, isNew = true)
                } else {
                    val o = original ?: throw IllegalStateException("This book no longer exists.")
                    val edited = BookEdits.applyDraft(o, draft).copy(
                        coverPath = form.coverPath,
                        coverUrl = form.coverUrl,
                        coverIsCustom = form.coverIsCustom,
                    )
                    c.books.saveEdits(bookId, o, edited)
                    saved = true
                    event = EditorEvent.Saved(bookId, isNew = false)
                }
            } catch (e: Exception) {
                message = e.message ?: "Couldn't save the book."
            } finally {
                saving = false
            }
        }
    }

    fun dismissDuplicate() { duplicate = null }

    fun consumeEvent() { event = null }

    override fun onCleared() {
        // Remove a cover file that was picked but never saved.
        val p = form.coverPath
        if (!saved && p != null && p != original?.coverPath) c.covers.delete(p)
    }
}
