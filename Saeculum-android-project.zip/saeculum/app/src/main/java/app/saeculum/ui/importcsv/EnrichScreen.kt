@file:OptIn(ExperimentalMaterial3Api::class)

package app.saeculum.ui.importcsv

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.automirrored.rounded.HelpOutline
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.saeculum.data.net.Lookup
import app.saeculum.ui.add.ResultRow
import app.saeculum.ui.components.BookCover
import app.saeculum.ui.components.Panel
import app.saeculum.ui.components.appViewModel
import app.saeculum.ui.components.coverSource
import app.saeculum.ui.theme.LiteraryText

@Composable
fun EnrichScreen(onBack: () -> Unit) {
    val vm = appViewModel { EnrichViewModel(it) }
    var choosing by remember { mutableStateOf<Int?>(null) }
    val total = vm.items.size
    val done = vm.items.count { it.state != EnrichState.PENDING }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Covers & details") },
                navigationIcon = { IconButton(onClick = { vm.stop(); onBack() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back") } },
            )
        },
    ) { padding ->
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Panel {
                    if (total == 0) {
                        Text("Every book already has a cover and ISBN.", style = MaterialTheme.typography.bodyLarge)
                    } else {
                        Text("$total book${if (total == 1) "" else "s"} to look up", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Saeculum searches Open Library (then Google Books) by title and author. A result is applied only when exactly one edition matches both; otherwise you choose. Only empty fields are filled — your status, ratings, notes and dates never change.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (vm.started) {
                            LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat() / total }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                            Text(
                                "Details found: ${vm.count(EnrichState.MATCHED)} · Choose edition: ${vm.count(EnrichState.MULTIPLE)} · Not found: ${vm.count(EnrichState.NOT_FOUND)}" +
                                    (vm.count(EnrichState.OFFLINE) + vm.count(EnrichState.FAILED)).let { if (it > 0) " · Couldn't check: $it" else "" },
                                style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 4.dp),
                            )
                        }
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            when {
                                vm.running -> OutlinedButton(onClick = vm::stop) { Text("Stop") }
                                !vm.started -> Button(onClick = vm::start) { Text("Start lookup") }
                                vm.count(EnrichState.OFFLINE) + vm.count(EnrichState.FAILED) > 0 -> Button(onClick = vm::retryUnresolved) { Text("Retry unresolved") }
                                done < total -> Button(onClick = vm::start) { Text("Continue") }
                                else -> Button(onClick = onBack) { Text("Done") }
                            }
                        }
                    }
                }
            }
            items(vm.items.size) { i ->
                val entry = vm.items[i]
                EnrichRow(entry, onChoose = { choosing = i }, onSkip = { vm.skip(i) })
            }
        }
    }

    choosing?.let { i ->
        val item = vm.items.getOrNull(i)
        if (item == null) { choosing = null; return@let }
        AlertDialog(
            onDismissRequest = { choosing = null },
            title = { Text("Which edition is “${item.book.title}”?") },
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(item.options) { r -> ResultRow(r) { vm.choose(i, r); choosing = null } }
                }
            },
            confirmButton = { TextButton(onClick = { vm.skip(i); choosing = null }) { Text("None of these") } },
            dismissButton = { TextButton(onClick = { choosing = null }) { Text("Later") } },
        )
    }
}

@Composable
private fun EnrichRow(item: EnrichItem, onChoose: () -> Unit, onSkip: () -> Unit) {
    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            BookCover(item.book.coverSource(), Modifier.width(40.dp), corner = 3.dp, elevation = 1.dp, showFallbackText = false)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(item.book.title, style = LiteraryText.bookTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.book.authorLine.ifBlank { "Author unknown" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                val status = when (item.state) {
                    EnrichState.PENDING -> "Waiting"
                    EnrichState.MATCHED -> "Added: " + item.changed.joinToString(", ")
                    EnrichState.NOTHING_NEW -> "Matched — nothing missing"
                    EnrichState.MULTIPLE -> "${item.options.size} possible editions — choose one"
                    EnrichState.NOT_FOUND -> "No reliable match — needs manual attention"
                    EnrichState.OFFLINE -> "Offline — not checked"
                    EnrichState.FAILED -> item.message ?: "Lookup failed"
                    EnrichState.SKIPPED -> item.message ?: "Skipped"
                }
                Text(status, style = MaterialTheme.typography.labelMedium, color = if (item.state == EnrichState.MATCHED) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary)
            }
            when (item.state) {
                EnrichState.MULTIPLE -> Column {
                    TextButton(onClick = onChoose) { Text("Choose") }
                    TextButton(onClick = onSkip) { Text("Skip") }
                }
                EnrichState.MATCHED, EnrichState.NOTHING_NEW -> Icon(Icons.Rounded.CheckCircle, contentDescription = "Done", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                EnrichState.OFFLINE -> Icon(Icons.Rounded.CloudOff, contentDescription = "Offline", modifier = Modifier.size(22.dp))
                EnrichState.PENDING -> Icon(Icons.Rounded.Schedule, contentDescription = "Waiting", modifier = Modifier.size(22.dp))
                EnrichState.SKIPPED -> Icon(Icons.Rounded.RemoveCircleOutline, contentDescription = "Skipped", modifier = Modifier.size(22.dp))
                else -> Icon(Icons.AutoMirrored.Rounded.HelpOutline, contentDescription = "Needs attention", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(22.dp))
            }
        }
    }
}
