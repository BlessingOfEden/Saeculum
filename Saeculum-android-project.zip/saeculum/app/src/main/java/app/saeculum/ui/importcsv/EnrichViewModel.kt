package app.saeculum.ui.importcsv

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.saeculum.AppContainer
import app.saeculum.core.metadata.MatchOutcome
import app.saeculum.core.metadata.MatchScorer
import app.saeculum.core.metadata.MetadataResult
import app.saeculum.core.model.Book
import app.saeculum.data.net.Lookup
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class EnrichState { PENDING, MATCHED, NOTHING_NEW, MULTIPLE, NOT_FOUND, OFFLINE, FAILED, SKIPPED }

data class EnrichItem(
    val book: Book,
    val state: EnrichState = EnrichState.PENDING,
    val changed: List<String> = emptyList(),
    val options: List<MetadataResult> = emptyList(),
    val message: String? = null,
)

/**
 * Best-effort metadata/cover lookup for a set of books. A result is applied automatically only when
 * exactly one candidate matches both title and author; otherwise the user chooses or skips.
 * Only empty fields are filled — personal data is never touched.
 */
class EnrichViewModel(private val c: AppContainer, private val ids: List<Long>?) : ViewModel() {
    constructor(c: AppContainer) : this(c, c.pendingEnrichIds.also { c.pendingEnrichIds = null })

    var items by mutableStateOf<List<EnrichItem>>(emptyList())
        private set
    var running by mutableStateOf(false)
        private set
    var started by mutableStateOf(false)
        private set
    private var job: Job? = null

    init {
        viewModelScope.launch {
            val all = c.books.liveBooks()
            val target = if (ids != null) all.filter { it.id in ids.toSet() } else all.filter { needsLookup(it) }
            items = target.map { EnrichItem(it) }
        }
    }

    private fun needsLookup(b: Book) =
        (b.coverPath == null && b.coverUrl == null && !b.coverIsCustom) || (b.isbn13 == null && b.isbn10 == null)

    fun start() {
        if (running) return
        started = true
        running = true
        job = viewModelScope.launch {
            for (i in items.indices) {
                if (!isActive) break
                if (items[i].state != EnrichState.PENDING) continue
                val b = items[i].book
                if (b.authors.isEmpty()) {
                    update(i) { it.copy(state = EnrichState.SKIPPED, message = "No author recorded — search for it from the book's page instead.") }
                    continue
                }
                when (val l = c.metadata.candidatesFor(b.title, b.authors)) {
                    is Lookup.Found -> {
                        val d = MatchScorer.decide(b.title, b.authors, l.results)
                        when (d.outcome) {
                            MatchOutcome.MATCHED -> {
                                val changed = c.books.applyMetadata(b.id, d.best!!)
                                update(i) { it.copy(state = if (changed.isEmpty()) EnrichState.NOTHING_NEW else EnrichState.MATCHED, changed = changed) }
                            }
                            MatchOutcome.MULTIPLE -> update(i) { it.copy(state = EnrichState.MULTIPLE, options = d.plausible.take(8)) }
                            MatchOutcome.NOT_FOUND -> update(i) { it.copy(state = EnrichState.NOT_FOUND) }
                        }
                    }
                    Lookup.NoMatch -> update(i) { it.copy(state = EnrichState.NOT_FOUND) }
                    Lookup.Offline -> {
                        // Mark the rest offline and stop; nothing is lost and it can be retried later.
                        items = items.map { if (it.state == EnrichState.PENDING) it.copy(state = EnrichState.OFFLINE) else it }
                        break
                    }
                    is Lookup.Failed -> update(i) { it.copy(state = EnrichState.FAILED, message = l.message) }
                }
                delay(350) // be polite to the free public APIs
            }
            running = false
        }
    }

    fun stop() {
        job?.cancel()
        running = false
    }

    fun retryUnresolved() {
        items = items.map {
            if (it.state == EnrichState.OFFLINE || it.state == EnrichState.FAILED) it.copy(state = EnrichState.PENDING, message = null) else it
        }
        start()
    }

    fun choose(index: Int, r: MetadataResult) {
        viewModelScope.launch {
            val changed = c.books.applyMetadata(items[index].book.id, r)
            update(index) { it.copy(state = if (changed.isEmpty()) EnrichState.NOTHING_NEW else EnrichState.MATCHED, changed = changed, options = emptyList()) }
        }
    }

    fun skip(index: Int) = update(index) { it.copy(state = EnrichState.SKIPPED, options = emptyList()) }

    private fun update(i: Int, f: (EnrichItem) -> EnrichItem) {
        items = items.toMutableList().also { it[i] = f(it[i]) }
    }

    fun count(s: EnrichState) = items.count { it.state == s }
}
