@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package app.saeculum.ui.importcsv

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.saeculum.core.importer.CsvField
import app.saeculum.core.importer.DuplicateAction
import app.saeculum.core.importer.ImportCandidate
import app.saeculum.core.importer.ImportPlanner
import app.saeculum.core.importer.IssueLevel
import app.saeculum.core.importer.RowDecision
import app.saeculum.core.model.ReadingStatus
import app.saeculum.ui.components.DropdownSelector
import app.saeculum.ui.components.Panel
import app.saeculum.ui.components.SectionHeader
import app.saeculum.ui.components.appViewModel
import app.saeculum.ui.theme.LiteraryText

private fun displayName(ctx: Context, uri: Uri): String? = try {
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    }
} catch (e: Exception) {
    null
}

@Composable
fun ImportScreen(
    onBack: () -> Unit,
    onOpenEditor: () -> Unit,
    onEnrich: (List<Long>) -> Unit,
    onOpenLibrary: () -> Unit,
) {
    val vm = appViewModel { ImportViewModel(it) }
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.load(uri, displayName(ctx, uri))
    }
    val pick = { picker.launch(arrayOf("text/*", "application/csv", "application/vnd.ms-excel", "application/octet-stream")) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Import books from CSV") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back") } },
            )
        },
        bottomBar = {
            when (vm.step) {
                ImportStep.MAP -> BottomAction("Preview import", enabled = vm.mappingProblems.isEmpty(), onClick = vm::buildPreview)
                ImportStep.PREVIEW -> BottomAction(
                    "Import Books (${vm.selectedCount})",
                    enabled = vm.selectedCount > 0,
                    secondary = "Back to columns" to vm::backToMapping,
                    onClick = vm::runImport,
                )
                else -> Unit
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (vm.step) {
                ImportStep.PICK -> PickStep(vm.error, pick)
                ImportStep.MAP -> MapStep(vm)
                ImportStep.PREVIEW -> PreviewStep(vm)
                ImportStep.IMPORTING -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Text("Importing…", modifier = Modifier.padding(top = 12.dp))
                }
                ImportStep.DONE -> DoneStep(vm, onOpenEditor, onEnrich, onOpenLibrary, onAnother = { vm.restart(); pick() })
            }
        }
    }
}

@Composable
private fun BottomAction(label: String, enabled: Boolean, onClick: () -> Unit, secondary: Pair<String, () -> Unit>? = null) {
    Surface(shadowElevation = 6.dp, color = MaterialTheme.colorScheme.surfaceContainer) {
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (secondary != null) TextButton(onClick = secondary.second) { Text(secondary.first) }
            Spacer(Modifier.weight(1f))
            Button(onClick = onClick, enabled = enabled, modifier = Modifier.height(48.dp)) { Text(label) }
        }
    }
}

@Composable
private fun PickStep(error: String?, onPick: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Add many books at once from a spreadsheet saved as CSV. You'll see a preview before anything is saved.", style = MaterialTheme.typography.bodyLarge)
        Panel {
            Text("Simplest format", style = MaterialTheme.typography.titleSmall)
            Text(
                "\"Book title\",\"Author first name\",\"Author last name\"\n\"The Hobbit\",\"J. R. R.\",\"Tolkien\"\n\"East of Eden\",\"John\",\"Steinbeck\"",
                fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 17.sp,
            )
            Text(
                "Optional columns: Additional authors, ISBN, Completion year, Completion date, Reading status, Rating, Publication year, Notes, Genre, Current page, Total pages. Column order doesn't matter, and you can match differently named columns on the next step.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(
            "Nothing is guessed: books are only marked completed when the file says so (a status or completion year), and missing details stay empty.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Button(onClick = onPick, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Icon(Icons.Rounded.UploadFile, contentDescription = null); Text("  Choose CSV file")
        }
        if (error != null) Text(error, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun MapStep(vm: ImportViewModel) {
    val dataRows = if (vm.hasHeader) vm.rows.drop(1) else vm.rows
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("${dataRows.size} row${if (dataRows.size == 1) "" else "s"} found" + (vm.fileName?.let { " in $it" } ?: ""), style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                Text("First row contains column names", modifier = Modifier.weight(1f))
                Switch(checked = vm.hasHeader, onCheckedChange = vm::setHeader)
            }
            Text("Match each column to a book field. Columns set to Ignore aren't imported.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            vm.mappingProblems.forEach { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp)) }
        }
        items(vm.columnCount) { col ->
            val header = if (vm.hasHeader) vm.rows.first().fields.getOrNull(col).orEmpty() else ""
            val samples = dataRows.take(3).mapNotNull { it.fields.getOrNull(col)?.takeIf { v -> v.isNotBlank() } }
            Panel {
                Text("Column ${col + 1}" + if (header.isNotBlank()) " · “$header”" else "", style = MaterialTheme.typography.titleSmall)
                Text(
                    if (samples.isEmpty()) "(empty in the first rows)" else samples.joinToString("  ·  ") { it.replace('\n', ' ').take(40) },
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                DropdownSelector(
                    label = "Import as",
                    options = CsvField.entries,
                    selected = vm.mapping.getOrElse(col) { CsvField.IGNORE },
                    optionLabel = { it.label },
                    onSelect = { vm.setField(col, it) },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun PreviewStep(vm: ImportViewModel) {
    val plan = vm.plan ?: return
    var editing by remember { mutableStateOf<ImportCandidate?>(null) }
    LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Panel {
                Text("Import preview", style = MaterialTheme.typography.titleMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Stat("Detected", plan.detectedCount)
                    Stat("Will import", vm.selectedCount)
                    Stat("Possible duplicates", plan.duplicateCount)
                    Stat("With warnings", plan.warningCount)
                    Stat("Can't import", plan.errorCount)
                }
            }
        }
        if (plan.needsDefaultStatus) {
            item {
                Panel {
                    Text("Rows without a reading status", style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Choose the status to give them. Rows with a completion year or date are already treated as Completed.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    DropdownSelector(
                        label = "Default status", options = ReadingStatus.entries, selected = vm.defaultStatus,
                        optionLabel = { it.label }, onSelect = { vm.defaultStatus = it }, modifier = Modifier.fillMaxWidth(),
                    )
                    if (vm.defaultStatus == ReadingStatus.COMPLETED) {
                        Text("These books will have no completion year (shown as “year unknown”) — none is assigned automatically.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }
        items(plan.candidates, key = { it.index }) { cand ->
            val d = vm.decisions[cand.index] ?: ImportPlanner.defaultDecision(cand)
            CandidateCard(cand, d, plan.candidates, onDecide = { vm.decide(cand.index, it) }, onEdit = { editing = cand })
        }
    }
    editing?.let { cand ->
        var title by remember(cand.index) { mutableStateOf(cand.draft.title) }
        var authors by remember(cand.index) { mutableStateOf(cand.draft.authors.joinToString("; ")) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Line ${cand.lineNumber}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Original: " + cand.raw.joinToString(" | ").take(200), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    OutlinedTextField(title, { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        authors, { authors = it }, label = { Text("Author full name(s)") },
                        supportingText = { Text("Separate several authors with ;  Single names (e.g. Homer) are fine.") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = { TextButton(onClick = { vm.editRow(cand.index, title, authors.split(';')); editing = null }) { Text("Apply") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Stat(label: String, value: Int) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text("$value", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun CandidateCard(cand: ImportCandidate, d: RowDecision, all: List<ImportCandidate>, onDecide: (RowDecision) -> Unit, onEdit: () -> Unit) {
    val container = when {
        cand.hasError -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f)
        !d.include -> MaterialTheme.colorScheme.surfaceContainerLowest
        else -> MaterialTheme.colorScheme.surfaceContainerLow
    }
    Surface(shape = MaterialTheme.shapes.medium, color = container, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(start = 6.dp, end = 12.dp, top = 8.dp, bottom = 10.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Checkbox(checked = d.include && !cand.hasError, enabled = !cand.hasError, onCheckedChange = { onDecide(d.copy(include = it)) })
                Column(Modifier.weight(1f).padding(top = 10.dp)) {
                    Text("Line ${cand.lineNumber}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text(cand.draft.title.ifBlank { "(no title)" }, style = LiteraryText.bookTitle, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(cand.draft.authors.joinToString(", ").ifBlank { "(no author)" }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    val status = cand.draft.status
                    if (status != null) {
                        val year = cand.draft.completedDate?.toString() ?: cand.draft.completedYear?.toString()
                        Text(
                            status.label + (year?.let { " · $it" } ?: "") + if (cand.statusInferred) " (from completion year)" else "",
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary,
                        )
                    }
                    val opt = cand.detectedOptionalFields
                    if (opt.isNotEmpty()) Text("Also: " + opt.joinToString(", "), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                }
                IconButton(onClick = onEdit) { Icon(Icons.Rounded.Edit, contentDescription = "Edit title and author") }
            }
            cand.issues.forEach { issue ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 12.dp, top = 2.dp)) {
                    Icon(
                        if (issue.level == IssueLevel.ERROR) Icons.Rounded.ErrorOutline else Icons.Rounded.WarningAmber,
                        contentDescription = null, modifier = Modifier.size(16.dp),
                        tint = if (issue.level == IssueLevel.ERROR) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                    )
                    Text("  " + issue.message, style = MaterialTheme.typography.bodySmall)
                }
            }
            if (cand.isDuplicate && !cand.hasError) {
                HorizontalDivider(Modifier.padding(vertical = 8.dp, horizontal = 12.dp))
                val text = cand.duplicateOfExisting?.let { m ->
                    "Possible duplicate of “${m.target.title}” in your library (${m.reason.description.lowercase()})."
                } ?: cand.duplicateOfRow?.let { r ->
                    val line = all.firstOrNull { it.index == r }?.lineNumber
                    "Possible duplicate of line $line in this file."
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 12.dp)) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.secondary)
                    Text("  " + (text ?: ""), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                }
                SingleChoiceSegmentedButtonRow(Modifier.padding(start = 12.dp, top = 6.dp).fillMaxWidth()) {
                    SegmentedButton(
                        selected = d.duplicateAction == DuplicateAction.SKIP, onClick = { onDecide(d.copy(duplicateAction = DuplicateAction.SKIP)) },
                        shape = SegmentedButtonDefaults.itemShape(0, 2),
                    ) { Text("Skip") }
                    SegmentedButton(
                        selected = d.duplicateAction == DuplicateAction.IMPORT_ANYWAY, onClick = { onDecide(d.copy(duplicateAction = DuplicateAction.IMPORT_ANYWAY)) },
                        shape = SegmentedButtonDefaults.itemShape(1, 2),
                    ) { Text("Import anyway") }
                }
            }
        }
    }
}

@Composable
private fun DoneStep(vm: ImportViewModel, onOpenEditor: () -> Unit, onEnrich: (List<Long>) -> Unit, onOpenLibrary: () -> Unit, onAnother: () -> Unit) {
    val s = vm.summary ?: return
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                Text("  Import finished", style = MaterialTheme.typography.headlineSmall)
            }
        }
        item {
            Panel {
                SummaryLine("Books imported", s.imported)
                SummaryLine("Possible duplicates skipped", s.duplicatesSkipped)
                SummaryLine("Rows excluded by you", s.excluded)
                SummaryLine("Rows rejected (missing title or author)", s.rejected.size)
                if (s.alreadyImported > 0) SummaryLine("Already imported earlier (not added again)", s.alreadyImported)
                if (s.failed.isNotEmpty()) SummaryLine("Couldn't be saved", s.failed.size)
                SummaryLine("Need attention (warnings or rejected)", s.needingAttention)
                Text(
                    "Covers and other details weren't looked up yet. Metadata lookup is optional and never changes your status, ratings, notes or dates.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (s.importedIds.isNotEmpty()) {
                    Button(onClick = { onEnrich(s.importedIds) }, modifier = Modifier.fillMaxWidth()) { Text("Find covers & details for ${s.importedIds.size} book${if (s.importedIds.size == 1) "" else "s"}") }
                }
                OutlinedButton(onClick = onOpenLibrary, modifier = Modifier.fillMaxWidth()) { Text("Go to library") }
                TextButton(onClick = onAnother, modifier = Modifier.fillMaxWidth()) { Text("Import another file") }
            }
        }
        if (s.rejected.isNotEmpty()) {
            item { SectionHeader("Rows to fix") }
            items(s.rejected, key = { "r${it.index}" }) { cand ->
                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Line ${cand.lineNumber}: " + cand.raw.joinToString(", ").take(80), style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(cand.issues.filter { it.level == IssueLevel.ERROR }.joinToString(" ") { it.message }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                        TextButton(onClick = { vm.fixInEditor(cand); onOpenEditor() }) { Text("Fix") }
                    }
                }
            }
        }
        if (s.failed.isNotEmpty()) {
            item { SectionHeader("Couldn't be saved") }
            items(s.failed) { (title, reason) -> Text("$title — $reason", style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun SummaryLine(label: String, value: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text("$value", style = MaterialTheme.typography.titleMedium, color = if (value > 0) MaterialTheme.colorScheme.primary else Color.Unspecified)
    }
}
