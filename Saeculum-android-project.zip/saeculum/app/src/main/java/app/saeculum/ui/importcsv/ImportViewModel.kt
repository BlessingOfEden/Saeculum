package app.saeculum.ui.importcsv

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.saeculum.AppContainer
import app.saeculum.core.csv.Csv
import app.saeculum.core.csv.CsvRow
import app.saeculum.core.importer.CsvField
import app.saeculum.core.importer.CsvMapping
import app.saeculum.core.importer.ImportCandidate
import app.saeculum.core.importer.ImportPlan
import app.saeculum.core.importer.ImportPlanner
import app.saeculum.core.importer.RowDecision
import app.saeculum.core.model.BookDraft
import app.saeculum.core.model.ReadingStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest

enum class ImportStep { PICK, MAP, PREVIEW, IMPORTING, DONE }

data class ImportSummary(
    val imported: Int,
    val duplicatesSkipped: Int,
    val excluded: Int,
    val rejected: List<ImportCandidate>,
    val alreadyImported: Int,
    val failed: List<Pair<String, String>>,
    val importedIds: List<Long>,
    val needingAttention: Int,
)

class ImportViewModel(private val c: AppContainer) : ViewModel() {
    var step by mutableStateOf(ImportStep.PICK)
        private set
    var error by mutableStateOf<String?>(null)
    var fileName by mutableStateOf<String?>(null)
        private set
    var rows by mutableStateOf<List<CsvRow>>(emptyList())
        private set
    var hasHeader by mutableStateOf(true)
        private set
    var mapping by mutableStateOf<List<CsvField>>(emptyList())
        private set
    var plan by mutableStateOf<ImportPlan?>(null)
        private set
    var decisions by mutableStateOf<Map<Int, RowDecision>>(emptyMap())
        private set
    var defaultStatus by mutableStateOf(ReadingStatus.TO_READ)
    var summary by mutableStateOf<ImportSummary?>(null)
        private set
    private var fileKey = ""

    val columnCount: Int get() = rows.maxOfOrNull { it.fields.size } ?: 0
    val mappingProblems: List<String> get() = CsvMapping.problems(mapping)

    fun load(uri: Uri, displayName: String?) {
        error = null
        viewModelScope.launch {
            try {
                val bytes = withContext(Dispatchers.IO) {
                    c.appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                } ?: throw IllegalStateException("Couldn't open the file.")
                if (bytes.size > 20 * 1024 * 1024) throw IllegalStateException("That file is larger than 20 MB.")
                val text = decode(bytes)
                val parsed = withContext(Dispatchers.Default) { Csv.parse(text) }.filterNot { it.isBlank }
                if (parsed.isEmpty()) throw IllegalStateException("The file is empty.")
                fileKey = sha(bytes)
                fileName = displayName
                rows = parsed
                val (header, map) = CsvMapping.autoMap(parsed.first().fields, parsed.maxOf { it.fields.size })
                hasHeader = header
                mapping = map
                step = ImportStep.MAP
            } catch (e: Exception) {
                error = e.message ?: "Couldn't read that file as CSV."
            }
        }
    }

    /** UTF-8 (with or without BOM); falls back to Windows-1252 for files saved by older spreadsheet apps. */
    private fun decode(bytes: ByteArray): String {
        val utf8 = String(bytes, Charsets.UTF_8)
        return if (utf8.contains('�')) String(bytes, charset("windows-1252")) else utf8
    }

    private fun sha(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).take(8).joinToString("") { "%02x".format(it) }

    fun setHeader(value: Boolean) {
        hasHeader = value
        if (!value) mapping = (0 until columnCount).map { listOf(CsvField.TITLE, CsvField.AUTHOR_FIRST, CsvField.AUTHOR_LAST).getOrElse(it) { CsvField.IGNORE } }
        else mapping = CsvMapping.autoMap(rows.first().fields, columnCount).second
    }

    fun setField(column: Int, field: CsvField) {
        mapping = mapping.toMutableList().also { m ->
            // Keep each field on one column (ISBN may use several).
            if (field != CsvField.IGNORE && field != CsvField.ISBN) {
                m.indices.filter { it != column && m[it] == field }.forEach { m[it] = CsvField.IGNORE }
            }
            m[column] = field
        }
    }

    fun buildPreview() {
        if (mappingProblems.isNotEmpty()) return
        viewModelScope.launch {
            val existing = c.books.liveBooks()
            val p = withContext(Dispatchers.Default) { ImportPlanner.plan(rows, hasHeader, mapping, existing) }
            plan = p
            decisions = p.candidates.associate { it.index to ImportPlanner.defaultDecision(it) }
            step = ImportStep.PREVIEW
        }
    }

    fun backToMapping() { step = ImportStep.MAP }

    fun decide(index: Int, d: RowDecision) {
        decisions = decisions + (index to d)
    }

    /** Lets the user fix a parsed row's title/author (e.g. single-name authors) before importing. */
    fun editRow(index: Int, title: String, authors: List<String>) {
        val p = plan ?: return
        val updated = p.candidates.map { cand ->
            if (cand.index != index) cand else {
                val draft = cand.draft.copy(title = title.trim(), authors = authors.map { it.trim() }.filter { it.isNotEmpty() })
                val issues = cand.issues.filterNot { it.message == "Missing book title." || it.message == "Missing author." } +
                    listOfNotNull(
                        if (draft.title.isEmpty()) app.saeculum.core.importer.ImportIssue(app.saeculum.core.importer.IssueLevel.ERROR, "Missing book title.") else null,
                        if (draft.authors.isEmpty()) app.saeculum.core.importer.ImportIssue(app.saeculum.core.importer.IssueLevel.ERROR, "Missing author.") else null,
                    )
                cand.copy(draft = draft, issues = issues)
            }
        }
        plan = p.copy(candidates = updated)
        updated.firstOrNull { it.index == index }?.let { decisions = decisions + (index to ImportPlanner.defaultDecision(it)) }
    }

    val selectedCount: Int
        get() = plan?.candidates?.count { cand ->
            val d = decisions[cand.index] ?: ImportPlanner.defaultDecision(cand)
            !cand.hasError && d.include && !(cand.isDuplicate && d.duplicateAction == app.saeculum.core.importer.DuplicateAction.SKIP)
        } ?: 0

    fun runImport() {
        val p = plan ?: return
        step = ImportStep.IMPORTING
        viewModelScope.launch {
            val selection = ImportPlanner.select(p, decisions, defaultStatus, fileKey, System.currentTimeMillis()) { c.books.newUuid() }
            val outcome = c.books.insertAll(selection.inserts.map { it.book })
            summary = ImportSummary(
                imported = outcome.inserted.size,
                duplicatesSkipped = selection.skippedDuplicates.size,
                excluded = selection.excluded.size,
                rejected = selection.rejected,
                alreadyImported = outcome.alreadyPresent,
                failed = outcome.failed.map { it.first.title to it.second },
                importedIds = outcome.inserted,
                needingAttention = selection.inserts.count { it.book.needsReview } + selection.rejected.size,
            )
            step = ImportStep.DONE
        }
    }

    /** Opens a rejected row in the editor so it can be fixed and saved on its own. */
    fun fixInEditor(cand: ImportCandidate) {
        val d: BookDraft = cand.draft.copy(status = cand.draft.status ?: defaultStatus)
        c.handoff.put(d, "csv")
    }

    fun restart() {
        step = ImportStep.PICK
        rows = emptyList()
        plan = null
        summary = null
        decisions = emptyMap()
        error = null
    }
}

