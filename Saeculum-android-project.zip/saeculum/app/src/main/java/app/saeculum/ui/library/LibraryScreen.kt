@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package app.saeculum.ui.library

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.LocalLibrary
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.ViewAgenda
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.saeculum.core.model.BookFilter
import app.saeculum.core.model.BookSort
import app.saeculum.core.model.ReadingStatus
import app.saeculum.ui.components.BookGrid
import app.saeculum.ui.components.EmptyState
import app.saeculum.ui.components.appViewModel
import app.saeculum.ui.components.fullWidth
import app.saeculum.ui.theme.LiteraryText

enum class AddMethod(val label: String, val description: String, val icon: ImageVector) {
    SEARCH("Search for a book", "Find it by title and author", Icons.Rounded.Search),
    SCAN("Scan a barcode", "Use the camera on the ISBN barcode", Icons.Rounded.QrCodeScanner),
    MANUAL("Enter manually", "Type the details yourself — works offline", Icons.Rounded.Edit),
    IMPORT_CSV("Import CSV", "Add many books from a spreadsheet file", Icons.Rounded.UploadFile),
}

@Composable
fun LibraryScreen(onOpenBook: (Long) -> Unit, onAddRequested: () -> Unit) {
    val vm = appViewModel { LibraryViewModel(it) }
    val state by vm.state.collectAsStateWithLifecycle()
    val query by vm.queryText.collectAsState()
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var showFilter by rememberSaveable { mutableStateOf(false) }
    val gridState = rememberLazyGridState()
    val pinToolbar by remember { derivedStateOf { gridState.firstVisibleItemIndex >= 2 } }

    val toolbar: @Composable () -> Unit = {
        LibraryToolbar(
            columns = state.options.columns,
            sort = state.sort,
            activeFilters = state.filter.activeCount,
            onAdd = onAddRequested,
            onColumns = vm::setColumns,
            onSort = vm::setSort,
            onFilter = { showFilter = true },
        )
    }

    Box(Modifier.fillMaxSize()) {
        BookGrid(
            books = state.visible,
            options = state.options,
            onOpen = { onOpenBook(it.id) },
            state = gridState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
            header = {
                fullWidth("title") {
                    LibraryHeader(
                        caption = state.caption?.let { c -> c.text to c.attribution?.let { a -> "— $a" + (c.source?.let { s -> ", $s" } ?: "") } },
                        count = state.totalCount,
                        searchOpen = searchOpen,
                        onSearch = { searchOpen = !searchOpen; if (!searchOpen) vm.setQuery("") },
                    )
                }
                if (searchOpen) {
                    fullWidth("search") {
                        OutlinedTextField(
                            value = query,
                            onValueChange = vm::setQuery,
                            placeholder = { Text("Search title, author, ISBN, tag…") },
                            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                            trailingIcon = {
                                IconButton(onClick = { vm.setQuery(""); searchOpen = false }) {
                                    Icon(Icons.Rounded.Close, contentDescription = "Close search")
                                }
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            shape = MaterialTheme.shapes.large,
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        )
                    }
                }
                fullWidth("toolbar") { toolbar() }
                if (state.filter.isActive) {
                    fullWidth("chips") { ActiveFilters(state.filter, state.visible.size, onChange = vm::setFilter, onClear = vm::clearFilters) }
                }
                if (!state.loading && state.visible.isEmpty()) {
                    fullWidth("empty") {
                        if (state.totalCount == 0) {
                            EmptyState(
                                Icons.Rounded.LocalLibrary,
                                "Your shelf is waiting",
                                "Add your first book by searching, scanning its barcode, typing it in, or importing a CSV file.",
                                action = { FilledTonalButton(onClick = onAddRequested) { Text("Add a book") } },
                            )
                        } else {
                            EmptyState(
                                Icons.Rounded.SearchOff,
                                "No books match",
                                "Nothing in your library fits the current search or filters.",
                                action = { OutlinedButton(onClick = { vm.clearFilters(); vm.setQuery("") }) { Text("Clear filters") } },
                            )
                        }
                    }
                }
            },
        )

        AnimatedVisibility(
            visible = pinToolbar,
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it },
            modifier = Modifier.align(Alignment.TopCenter),
        ) {
            Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f), shadowElevation = 3.dp) {
                Box(Modifier.statusBarsPadding().padding(horizontal = 16.dp, vertical = 6.dp)) { toolbar() }
            }
        }
    }

    if (showFilter) {
        FilterSheet(
            filter = state.filter,
            years = state.availableYears,
            hasUnknownYear = state.hasUnknownYear,
            genres = state.availableGenres,
            reviewCount = state.reviewCount,
            onApply = vm::setFilter,
            onDismiss = { showFilter = false },
        )
    }
}

@Composable
private fun LibraryHeader(caption: Pair<String, String?>?, count: Int, searchOpen: Boolean, onSearch: () -> Unit) {
    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 18.dp, bottom = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Saeculum", style = LiteraryText.wordmark, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
            IconButton(onClick = onSearch) {
                Icon(if (searchOpen) Icons.Rounded.Close else Icons.Rounded.Search, contentDescription = if (searchOpen) "Close search" else "Search library")
            }
        }
        if (caption != null) {
            Text(
                caption.first,
                style = LiteraryText.quote,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp, end = 24.dp),
            )
            caption.second?.let {
                Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(top = 2.dp))
            }
        }
        if (count > 0) {
            Text(
                "$count book${if (count == 1) "" else "s"} on your shelves",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(top = 10.dp),
            )
        }
    }
}

/**
 * Add (left, ~1×2 cell pill) · density selector · sort · filter. Everything fits in 328dp so the
 * row works on small phones without overlapping.
 */
@Composable
fun LibraryToolbar(
    columns: Int,
    sort: BookSort,
    activeFilters: Int,
    onAdd: () -> Unit,
    onColumns: (Int) -> Unit,
    onSort: (BookSort) -> Unit,
    onFilter: () -> Unit,
    showAdd: Boolean = true,
    showSortAndFilter: Boolean = true,
) {
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (showAdd) {
            FilledTonalButton(
                onClick = onAdd,
                contentPadding = PaddingValues(horizontal = 14.dp),
                modifier = Modifier.height(44.dp).width(84.dp),
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(4.dp))
                Text("Add", maxLines = 1)
            }
        }
        Spacer(Modifier.weight(1f))
        DensitySelector(columns, onColumns)
        if (showSortAndFilter) {
            Spacer(Modifier.width(4.dp))
            SortButton(sort, onSort)
            BadgedBox(badge = { if (activeFilters > 0) Badge { Text("$activeFilters") } }) {
                IconButton(onClick = onFilter) { Icon(Icons.Rounded.Tune, contentDescription = "Filter") }
            }
        }
    }
}

@Composable
fun DensitySelector(columns: Int, onColumns: (Int) -> Unit) {
    val options = listOf(Triple(1, Icons.Rounded.ViewAgenda, "One column"), Triple(3, Icons.Rounded.GridView, "Three columns"), Triple(6, Icons.Rounded.Apps, "Six columns"))
    SingleChoiceSegmentedButtonRow(Modifier.width(126.dp).height(40.dp)) {
        options.forEachIndexed { i, (n, icon, label) ->
            SegmentedButton(
                selected = columns == n,
                onClick = { onColumns(n) },
                shape = SegmentedButtonDefaults.itemShape(i, options.size),
                icon = {},
                label = { Icon(icon, contentDescription = label, modifier = Modifier.size(18.dp)) },
            )
        }
    }
}

@Composable
private fun SortButton(sort: BookSort, onSort: (BookSort) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.AutoMirrored.Rounded.Sort, contentDescription = "Sort: ${sort.label}") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            Text("Sort by", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
            BookSort.entries.forEach { s ->
                DropdownMenuItem(
                    text = { Text(s.label) },
                    onClick = { onSort(s); open = false },
                    trailingIcon = { if (s == sort) Icon(Icons.Rounded.Check, contentDescription = "Selected") },
                )
            }
        }
    }
}

@Composable
private fun ActiveFilters(filter: BookFilter, shown: Int, onChange: (BookFilter) -> Unit, onClear: () -> Unit) {
    FlowRow(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        filter.statuses.forEach { s ->
            FilterChip(selected = true, onClick = { onChange(filter.copy(statuses = filter.statuses - s)) }, label = { Text(s.shortLabel) }, trailingIcon = { Icon(Icons.Rounded.Close, contentDescription = "Remove", modifier = Modifier.size(16.dp)) })
        }
        filter.completionYears.sortedDescending().forEach { y ->
            FilterChip(selected = true, onClick = { onChange(filter.copy(completionYears = filter.completionYears - y)) }, label = { Text(if (y == BookFilter.UNKNOWN_YEAR) "Year unknown" else "$y") }, trailingIcon = { Icon(Icons.Rounded.Close, contentDescription = "Remove", modifier = Modifier.size(16.dp)) })
        }
        filter.genres.forEach { g ->
            FilterChip(selected = true, onClick = { onChange(filter.copy(genres = filter.genres - g)) }, label = { Text(g) }, trailingIcon = { Icon(Icons.Rounded.Close, contentDescription = "Remove", modifier = Modifier.size(16.dp)) })
        }
        if (filter.needsReviewOnly) {
            FilterChip(selected = true, onClick = { onChange(filter.copy(needsReviewOnly = false)) }, label = { Text("Needs review") }, trailingIcon = { Icon(Icons.Rounded.Close, contentDescription = "Remove", modifier = Modifier.size(16.dp)) })
        }
        TextButton(onClick = onClear) { Text("Clear · $shown shown") }
    }
}

@Composable
fun AddBookSheet(onDismiss: () -> Unit, onPick: (AddMethod) -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.navigationBarsPadding().padding(bottom = 16.dp)) {
            Text("Add a book", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
            AddMethod.entries.forEach { m ->
                ListItem(
                    headlineContent = { Text(m.label) },
                    supportingContent = { Text(m.description) },
                    leadingContent = { Icon(m.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                    colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 3.dp)
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.medium)
                        .clickable(role = Role.Button) { onPick(m) },
                )
            }
        }
    }
}

@Composable
private fun FilterSheet(
    filter: BookFilter,
    years: List<Int>,
    hasUnknownYear: Boolean,
    genres: List<String>,
    reviewCount: Int,
    onApply: (BookFilter) -> Unit,
    onDismiss: () -> Unit,
) {
    var f by remember { mutableStateOf(filter.copy(query = "")) }
    ModalBottomSheet(onDismissRequest = { onApply(f); onDismiss() }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 24.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Filter", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = { f = BookFilter() }) { Text("Reset") }
                FilledTonalButton(onClick = { onApply(f); onDismiss() }) { Text("Apply") }
            }
            Text("Reading status", style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReadingStatus.entries.forEach { s ->
                    FilterChip(
                        selected = s in f.statuses,
                        onClick = { f = f.copy(statuses = if (s in f.statuses) f.statuses - s else f.statuses + s) },
                        label = { Text(s.shortLabel) },
                    )
                }
            }
            if (years.isNotEmpty() || hasUnknownYear) {
                Spacer(Modifier.height(6.dp))
                Text("Completion year", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    years.forEach { y ->
                        FilterChip(
                            selected = y in f.completionYears,
                            onClick = { f = f.copy(completionYears = if (y in f.completionYears) f.completionYears - y else f.completionYears + y) },
                            label = { Text("$y") },
                        )
                    }
                    if (hasUnknownYear) {
                        val u = BookFilter.UNKNOWN_YEAR
                        FilterChip(
                            selected = u in f.completionYears,
                            onClick = { f = f.copy(completionYears = if (u in f.completionYears) f.completionYears - u else f.completionYears + u) },
                            label = { Text("Unknown") },
                        )
                    }
                }
            }
            if (genres.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("Genre & tags", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    genres.forEach { g ->
                        FilterChip(
                            selected = g in f.genres,
                            onClick = { f = f.copy(genres = if (g in f.genres) f.genres - g else f.genres + g) },
                            label = { Text(g) },
                        )
                    }
                }
            }
            if (reviewCount > 0) {
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Needs review only", style = MaterialTheme.typography.titleSmall)
                        Text("$reviewCount imported record${if (reviewCount == 1) "" else "s"} flagged for checking", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = f.needsReviewOnly, onCheckedChange = { f = f.copy(needsReviewOnly = it) })
                }
            }
        }
    }
}
