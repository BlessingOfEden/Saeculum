package app.saeculum.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.saeculum.AppContainer
import app.saeculum.core.model.Book
import app.saeculum.core.model.BookFilter
import app.saeculum.core.model.BookSort
import app.saeculum.core.model.BookSorting
import app.saeculum.core.model.Caption
import app.saeculum.core.model.Captions
import app.saeculum.data.AppSettings
import app.saeculum.ui.components.GridOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LibraryUiState(
    val loading: Boolean = true,
    val totalCount: Int = 0,
    val visible: List<Book> = emptyList(),
    val options: GridOptions = GridOptions(3),
    val sort: BookSort = BookSort.COMPLETED_NEWEST,
    val filter: BookFilter = BookFilter(),
    val caption: Caption? = null,
    val availableYears: List<Int> = emptyList(),
    val hasUnknownYear: Boolean = false,
    val availableGenres: List<String> = emptyList(),
    val reviewCount: Int = 0,
)

class LibraryViewModel(private val c: AppContainer) : ViewModel() {

    private val query = MutableStateFlow("")
    val queryText: StateFlow<String> = query
    /** "Needs review" is a session-only filter (not persisted), shared so other screens can request it. */
    private val reviewOnly = c.reviewOnlyFilter

    val state: StateFlow<LibraryUiState> = combine(c.books.books, c.settings.settings, query, reviewOnly) { books, s: AppSettings, q, r ->
        val filter = s.filter.copy(query = q, needsReviewOnly = r)
        val visible = BookSorting.sort(books.filter { filter.matches(it) }, s.sort)
        LibraryUiState(
            loading = false,
            totalCount = books.size,
            visible = visible,
            options = GridOptions(s.columns, s.showRatings, s.showTitles, s.showCompletionYear),
            sort = s.sort,
            filter = filter,
            caption = Captions.resolve(s.captionMode, s.captionId, s.customCaption),
            availableYears = books.mapNotNull { it.effectiveCompletionYear }.distinct().sortedDescending(),
            hasUnknownYear = books.any { it.isCompleted && it.effectiveCompletionYear == null },
            availableGenres = books.flatMap { listOfNotNull(it.genre) + it.tags }.map { it.trim() }
                .filter { it.isNotEmpty() }.distinctBy { it.lowercase() }.sortedBy { it.lowercase() },
            reviewCount = books.count { it.needsReview },
        )
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LibraryUiState())

    fun setColumns(n: Int) = viewModelScope.launch { c.settings.setColumns(n) }
    fun setSort(s: BookSort) = viewModelScope.launch { c.settings.setSort(s) }
    fun setFilter(f: BookFilter) {
        reviewOnly.value = f.needsReviewOnly
        viewModelScope.launch { c.settings.setFilter(f.copy(query = "", needsReviewOnly = false)) }
    }
    fun setQuery(q: String) { query.value = q }
    fun clearFilters() {
        reviewOnly.value = false
        viewModelScope.launch { c.settings.setFilter(BookFilter()) }
    }
    fun showNeedsReview() = setFilter(BookFilter(needsReviewOnly = true))
}
