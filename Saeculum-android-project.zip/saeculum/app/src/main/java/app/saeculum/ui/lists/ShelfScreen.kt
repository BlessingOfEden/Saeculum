package app.saeculum.ui.lists

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.saeculum.core.model.Book
import app.saeculum.core.model.ReadingStatus
import app.saeculum.ui.components.BookGrid
import app.saeculum.ui.components.EmptyState
import app.saeculum.ui.components.appViewModel
import app.saeculum.ui.components.fullWidth
import app.saeculum.ui.detail.CompletionDialog
import app.saeculum.ui.detail.ProgressDialog
import app.saeculum.ui.library.LibraryToolbar
import app.saeculum.ui.theme.LiteraryText

private data class ShelfCopy(val title: String, val subtitle: String, val emptyTitle: String, val emptyText: String)

private fun copyFor(s: ReadingStatus) = when (s) {
    ReadingStatus.READING -> ShelfCopy("Currently Reading", "Books open on your nightstand.", "Nothing in progress", "Start a book from To Read, or add one you've already begun.")
    ReadingStatus.TO_READ -> ShelfCopy("To Read", "Waiting their turn.", "Your to-read pile is clear", "Add books you plan to read next. They won't count as read until you finish them.")
    ReadingStatus.WANT_TO_BUY -> ShelfCopy("Want to Buy", "For the next visit to the bookshop.", "No books on your wish list", "Add books you'd like to buy. Note a preferred edition or where you heard of it.")
    else -> ShelfCopy(s.label, "", "Nothing here", "")
}

@Composable
fun ShelfScreen(status: ReadingStatus, onOpenBook: (Long) -> Unit, onAdd: () -> Unit) {
    val vm = appViewModel(key = "shelf-$status") { ShelfViewModel(it, status) }
    val state by vm.state.collectAsStateWithLifecycle()
    val copy = copyFor(status)
    var progressFor by remember { mutableStateOf<Book?>(null) }
    var finishFor by remember { mutableStateOf<Book?>(null) }

    BookGrid(
        books = state.books,
        options = state.options,
        onOpen = { onOpenBook(it.id) },
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        rowAction = { b ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                when (status) {
                    ReadingStatus.READING -> {
                        OutlinedButton(onClick = { progressFor = b }) { Text("Progress") }
                        FilledTonalButton(onClick = { finishFor = b }) { Text("Finished") }
                    }
                    ReadingStatus.TO_READ -> {
                        FilledTonalButton(onClick = { vm.move(b.id, ReadingStatus.READING) }) { Text("Start reading") }
                        OutlinedButton(onClick = { finishFor = b }) { Text("Finished") }
                    }
                    ReadingStatus.WANT_TO_BUY -> {
                        FilledTonalButton(onClick = { vm.move(b.id, ReadingStatus.TO_READ) }) { Text("Got it") }
                        OutlinedButton(onClick = { vm.move(b.id, ReadingStatus.READING) }) { Text("Start reading") }
                    }
                    else -> Unit
                }
            }
        },
        header = {
            fullWidth("title") {
                Column(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 18.dp, bottom = 12.dp)) {
                    Text(copy.title, style = LiteraryText.wordmark.copy(fontSize = MaterialTheme.typography.headlineLarge.fontSize), color = MaterialTheme.colorScheme.primary)
                    Text(
                        copy.subtitle + if (state.books.isNotEmpty()) "  ·  ${state.books.size} book${if (state.books.size == 1) "" else "s"}" else "",
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            fullWidth("toolbar") {
                LibraryToolbar(
                    columns = state.options.columns,
                    sort = app.saeculum.core.model.BookSort.ADDED_NEWEST,
                    activeFilters = 0,
                    onAdd = { vm.prepareAdd(); onAdd() },
                    onColumns = vm::setColumns,
                    onSort = {},
                    onFilter = {},
                    showSortAndFilter = false,
                )
            }
            if (!state.loading && state.books.isEmpty()) {
                fullWidth("empty") {
                    EmptyState(
                        when (status) {
                            ReadingStatus.READING -> Icons.Rounded.AutoStories
                            ReadingStatus.WANT_TO_BUY -> Icons.Rounded.ShoppingBag
                            else -> Icons.Rounded.Bookmark
                        },
                        copy.emptyTitle, copy.emptyText,
                    )
                }
            }
            if (state.options.columns != 1 && state.books.isNotEmpty()) {
                fullWidth("hint") {
                    Text(
                        "Tap a book to update it, or switch to the single-column view for quick actions.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.padding(bottom = 10.dp),
                    )
                }
            }
        },
    )

    progressFor?.let { b ->
        ProgressDialog(b, onSave = { cp, tp, pc, st -> vm.progress(b.id, cp, tp, pc, st) }, onDismiss = { progressFor = null })
    }
    finishFor?.let { b ->
        CompletionDialog("When did you finish “${b.title}”?", null, onConfirm = { vm.move(b.id, ReadingStatus.COMPLETED, it) }, onDismiss = { finishFor = null })
    }
}
