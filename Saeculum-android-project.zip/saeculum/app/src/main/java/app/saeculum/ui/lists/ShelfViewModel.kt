package app.saeculum.ui.lists

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.saeculum.AppContainer
import app.saeculum.core.model.Book
import app.saeculum.core.model.Completion
import app.saeculum.core.model.ReadingStatus
import app.saeculum.ui.components.GridOptions
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class ShelfState(val books: List<Book> = emptyList(), val options: GridOptions = GridOptions(3), val loading: Boolean = true)

class ShelfViewModel(private val c: AppContainer, val status: ReadingStatus) : ViewModel() {
    val state: StateFlow<ShelfState> = combine(c.books.books, c.settings.settings) { books, s ->
        val list = books.filter { it.status == status }.let { l ->
            if (status == ReadingStatus.READING) l.sortedByDescending { it.lastModified } else l.sortedByDescending { it.dateAdded }
        }
        ShelfState(list, GridOptions(s.columns, s.showRatings, s.showTitles, s.showCompletionYear), loading = false)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ShelfState())

    fun setColumns(n: Int) = viewModelScope.launch { c.settings.setColumns(n) }
    fun move(id: Long, to: ReadingStatus, completion: Completion? = null) = viewModelScope.launch { c.books.changeStatus(id, to, completion) }
    fun progress(id: Long, cp: Int?, tp: Int?, pc: Int?, started: LocalDate?) = viewModelScope.launch { c.books.updateProgress(id, cp, tp, pc, started) }
    fun prepareAdd() { c.handoff.preferredStatus = status }
}
