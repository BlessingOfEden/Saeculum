package app.saeculum.ui.navigation

import android.graphics.Color as AndroidColor
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.LocalLibrary
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import app.saeculum.AppContainer
import app.saeculum.core.model.ReadingStatus
import app.saeculum.data.AppSettings
import app.saeculum.data.SeedReport
import app.saeculum.data.StartScreen
import app.saeculum.ui.add.ScanScreen
import app.saeculum.ui.add.SearchScreen
import app.saeculum.ui.components.LocalAppContainer
import app.saeculum.ui.detail.BookDetailSheet
import app.saeculum.ui.editor.EditorScreen
import app.saeculum.ui.importcsv.EnrichScreen
import app.saeculum.ui.importcsv.ImportScreen
import app.saeculum.ui.library.AddBookSheet
import app.saeculum.ui.library.AddMethod
import app.saeculum.ui.library.LibraryScreen
import app.saeculum.ui.lists.ShelfScreen
import app.saeculum.ui.settings.SeedReportScreen
import app.saeculum.ui.settings.SettingsScreen
import app.saeculum.ui.settings.TrashScreen
import app.saeculum.ui.stats.StatsScreen
import app.saeculum.ui.theme.LocalIsDark
import app.saeculum.ui.theme.SaeculumTheme
import kotlinx.coroutines.launch

object Routes {
    const val LIBRARY = "library"
    const val READING = "reading"
    const val TO_READ = "toread"
    const val WANT_TO_BUY = "wanttobuy"
    const val STATS = "stats"
    const val SETTINGS = "settings"
    const val EDITOR_NEW = "editor/new"
    const val EDITOR_EDIT = "editor/{id}"
    const val SEARCH = "search?bookId={bookId}"
    const val SCAN = "scan"
    const val IMPORT = "import"
    const val ENRICH = "enrich"
    const val TRASH = "trash"
    const val SEED = "seedreport"

    fun editor(id: Long) = "editor/$id"
    fun search(bookId: Long? = null) = if (bookId == null) "search" else "search?bookId=$bookId"

    fun forStart(s: StartScreen) = when (s) {
        StartScreen.LIBRARY -> LIBRARY
        StartScreen.READING -> READING
        StartScreen.TO_READ -> TO_READ
        StartScreen.WANT_TO_BUY -> WANT_TO_BUY
        StartScreen.STATS -> STATS
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab(Routes.LIBRARY, "Library", Icons.Rounded.LocalLibrary),
    Tab(Routes.READING, "Reading", Icons.Rounded.AutoStories),
    Tab(Routes.TO_READ, "To Read", Icons.Rounded.Bookmark),
    Tab(Routes.WANT_TO_BUY, "To Buy", Icons.Rounded.ShoppingBag),
    Tab(Routes.STATS, "Stats", Icons.Rounded.Insights),
    Tab(Routes.SETTINGS, "Settings", Icons.Rounded.Settings),
)

@Composable
fun SaeculumRoot(container: AppContainer) {
    val settings by container.settings.settings.collectAsStateWithLifecycle(initialValue = null)
    val s = settings
    if (s == null) {
        // Preferences load in a few milliseconds; the window background covers this frame.
        return
    }
    SaeculumTheme(s.theme, s.darkMode, s.dynamicColor) {
        SystemBars()
        CompositionLocalProvider(LocalAppContainer provides container) {
            Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
                AppScaffold(container, s)
            }
        }
    }
}

/** Keeps status/navigation bar icons legible when the app's theme differs from the system's. */
@Composable
private fun SystemBars() {
    val activity = LocalContext.current as? ComponentActivity ?: return
    val dark = LocalIsDark.current
    SideEffect {
        val style = if (dark) SystemBarStyle.dark(AndroidColor.TRANSPARENT) else SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
        activity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }
}

@Composable
private fun AppScaffold(container: AppContainer, settings: AppSettings) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val start = remember { Routes.forStart(settings.startScreen) }
    var lastTab by rememberSaveable { mutableStateOf(start) }
    LaunchedEffect(route) {
        if (route != null && tabs.any { it.route == route }) lastTab = route
    }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var openBook by rememberSaveable { mutableStateOf<Long?>(null) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var seedReport by remember { mutableStateOf<SeedReport?>(null) }

    fun message(text: String, action: String? = null, onAction: (() -> Unit)? = null) {
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val r = snackbar.showSnackbar(
                message = text,
                actionLabel = action,
                withDismissAction = action == null,
                duration = if (action != null) SnackbarDuration.Long else SnackbarDuration.Short,
            )
            if (r == SnackbarResult.ActionPerformed) onAction?.invoke()
        }
    }

    fun returnToTab() {
        if (!nav.popBackStack(lastTab, inclusive = false)) {
            nav.navigate(lastTab) { popUpTo(nav.graph.findStartDestination().id); launchSingleTop = true }
        }
    }

    // One-time startup work: purge old trash, migrate the historical reading list, cache covers.
    LaunchedEffect(Unit) {
        try {
            container.books.purgeTrash(30)
            val report = container.seed.runIfNeeded()
            if (report != null && !container.settings.current().seedReportSeen) seedReport = report
        } catch (e: Exception) {
            message("Couldn't import the initial reading list: ${e.message}. It will be retried next launch.")
        }
        container.books.cacheMissingCovers()
    }

    val blurContent = openBook != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    Scaffold(
        bottomBar = { if (tabs.any { it.route == route }) BottomBar(nav, route) },
        snackbarHost = { SnackbarHost(snackbar) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { padding ->
        Box(
            Modifier
                .padding(padding)
                .consumeWindowInsets(padding)
                .fillMaxSize()
                .then(if (blurContent) Modifier.blur(8.dp) else Modifier),
        ) {
            NavHost(
                navController = nav,
                startDestination = start,
                enterTransition = { fadeIn(tween(180)) },
                exitTransition = { fadeOut(tween(120)) },
                popEnterTransition = { fadeIn(tween(180)) },
                popExitTransition = { fadeOut(tween(120)) },
            ) {
                composable(Routes.LIBRARY) {
                    LibraryScreen(
                        onOpenBook = { openBook = it },
                        onAddRequested = { container.handoff.preferredStatus = null; showAdd = true },
                    )
                }
                composable(Routes.READING) { ShelfScreen(ReadingStatus.READING, onOpenBook = { openBook = it }, onAdd = { showAdd = true }) }
                composable(Routes.TO_READ) { ShelfScreen(ReadingStatus.TO_READ, onOpenBook = { openBook = it }, onAdd = { showAdd = true }) }
                composable(Routes.WANT_TO_BUY) { ShelfScreen(ReadingStatus.WANT_TO_BUY, onOpenBook = { openBook = it }, onAdd = { showAdd = true }) }
                composable(Routes.STATS) { StatsScreen(onOpenBook = { openBook = it }) }
                composable(Routes.SETTINGS) {
                    SettingsScreen(
                        onMessage = { message(it) },
                        onImportCsv = { nav.navigate(Routes.IMPORT) },
                        onFindCovers = { container.pendingEnrichIds = null; nav.navigate(Routes.ENRICH) },
                        onTrash = { nav.navigate(Routes.TRASH) },
                        onSeedReport = { nav.navigate(Routes.SEED) },
                    )
                }
                composable(Routes.EDITOR_NEW) {
                    EditorScreen(
                        bookId = null,
                        onClose = { nav.popBackStack() },
                        onSaved = { id, _ ->
                            returnToTab()
                            message("Added to your library.", "Open") { openBook = id }
                        },
                        onOpenExisting = { id -> returnToTab(); openBook = id },
                    )
                }
                composable(Routes.EDITOR_EDIT, arguments = listOf(navArgument("id") { type = NavType.LongType })) { entry ->
                    val id = entry.arguments?.getLong("id") ?: -1L
                    EditorScreen(
                        bookId = id,
                        onClose = { nav.popBackStack(); openBook = id },
                        onSaved = { savedId, _ -> nav.popBackStack(); openBook = savedId; message("Changes saved.") },
                        onOpenExisting = { other -> nav.popBackStack(); openBook = other },
                    )
                }
                composable(Routes.SEARCH, arguments = listOf(navArgument("bookId") { type = NavType.LongType; defaultValue = -1L })) { entry ->
                    val id = entry.arguments?.getLong("bookId")?.takeIf { it > 0 }
                    SearchScreen(
                        enrichBookId = id,
                        onBack = { nav.popBackStack(); if (id != null) openBook = id },
                        onOpenEditor = { nav.navigate(Routes.EDITOR_NEW) },
                        onApplied = { msg -> nav.popBackStack(); openBook = id; message(msg) },
                    )
                }
                composable(Routes.SCAN) { ScanScreen(onBack = { nav.popBackStack() }, onOpenEditor = { nav.navigate(Routes.EDITOR_NEW) }) }
                composable(Routes.IMPORT) {
                    ImportScreen(
                        onBack = { nav.popBackStack() },
                        onOpenEditor = { nav.navigate(Routes.EDITOR_NEW) },
                        onEnrich = { ids -> container.pendingEnrichIds = ids; nav.navigate(Routes.ENRICH) },
                        onOpenLibrary = {
                            nav.navigate(Routes.LIBRARY) { popUpTo(nav.graph.findStartDestination().id); launchSingleTop = true }
                        },
                    )
                }
                composable(Routes.ENRICH) { EnrichScreen(onBack = { nav.popBackStack() }) }
                composable(Routes.TRASH) { TrashScreen(onBack = { nav.popBackStack() }) }
                composable(Routes.SEED) {
                    SeedReportScreen(
                        onBack = { nav.popBackStack() },
                        onShowNeedsReview = {
                            container.reviewOnlyFilter.value = true
                            nav.navigate(Routes.LIBRARY) { popUpTo(nav.graph.findStartDestination().id); launchSingleTop = true }
                        },
                    )
                }
            }
        }
    }

    if (showAdd) {
        AddBookSheet(
            onDismiss = { showAdd = false },
            onPick = { m ->
                showAdd = false
                when (m) {
                    AddMethod.SEARCH -> nav.navigate(Routes.search())
                    AddMethod.SCAN -> nav.navigate(Routes.SCAN)
                    AddMethod.MANUAL -> nav.navigate(Routes.EDITOR_NEW)
                    AddMethod.IMPORT_CSV -> nav.navigate(Routes.IMPORT)
                }
            },
        )
    }

    openBook?.let { id ->
        BookDetailSheet(
            bookId = id,
            onDismiss = { openBook = null },
            onEdit = { bid -> openBook = null; nav.navigate(Routes.editor(bid)) },
            onFindDetails = { bid -> openBook = null; nav.navigate(Routes.search(bid)) },
            onMessage = { message(it) },
            onTrashed = { tid, title ->
                message("Moved “$title” to Recently Deleted.", "Undo") {
                    scope.launch { container.books.restoreFromTrash(tid) }
                }
            },
        )
    }

    seedReport?.let { r ->
        val p = r.parse
        val years = p.sections.map { it.year }
        val disc = p.discrepancies
        AlertDialog(
            onDismissRequest = { seedReport = null; scope.launch { container.settings.markSeedReportSeen() } },
            title = { Text("Your reading history is here") },
            text = {
                Text(
                    "Imported ${r.imported} books from your “Novels Read” list" +
                        (if (years.isNotEmpty()) " (${years.min()}–${years.max()})" else "") + ", each marked Completed in the year it was listed. " +
                        "Nothing was invented — no ratings, ISBNs, covers or exact dates.\n\n" +
                        "${p.reviewCount} records are flagged for a quick check (e.g. no author in the list)" +
                        (if (p.duplicates.isNotEmpty()) ", and ${p.duplicates.size} possible duplicates were kept" else "") + "." +
                        disc.joinToString("") { "\n\nThe list states ${it.statedTotal} books for ${it.year}, but ${it.entryCount} titles are listed." },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    seedReport = null
                    scope.launch { container.settings.markSeedReportSeen() }
                    nav.navigate(Routes.SEED)
                }) { Text("View report") }
            },
            dismissButton = {
                TextButton(onClick = { seedReport = null; scope.launch { container.settings.markSeedReportSeen() } }) { Text("OK") }
            },
        )
    }
}

@Composable
private fun BottomBar(nav: NavHostController, current: String?) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
        tabs.forEach { t ->
            NavigationBarItem(
                selected = current == t.route,
                onClick = {
                    if (current != t.route) {
                        nav.navigate(t.route) {
                            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = { Icon(t.icon, contentDescription = null) },
                label = { Text(t.label, maxLines = 1, overflow = TextOverflow.Clip, fontSize = 11.sp) },
                alwaysShowLabel = true,
            )
        }
    }
}
