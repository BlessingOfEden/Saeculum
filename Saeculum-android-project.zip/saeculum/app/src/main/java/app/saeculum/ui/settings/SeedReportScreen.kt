@file:OptIn(ExperimentalMaterial3Api::class)

package app.saeculum.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.saeculum.data.SeedReport
import app.saeculum.ui.components.LocalAppContainer
import app.saeculum.ui.components.Panel
import app.saeculum.ui.components.SectionHeader

/** Migration report for the historical reading list bundled with the app (spec §15). */
@Composable
fun SeedReportScreen(onBack: () -> Unit, onShowNeedsReview: () -> Unit) {
    val c = LocalAppContainer.current
    var report by remember { mutableStateOf<SeedReport?>(null) }
    var showSource by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { report = c.seed.report() }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Reading-list import") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back") } },
        )
    }) { padding ->
        val r = report
        if (r == null) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        val p = r.parse
        LazyColumn(Modifier.padding(padding).fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Panel {
                    Text("Your “Novels Read” list was imported as the starting library.", style = MaterialTheme.typography.titleSmall)
                    ReportLine("Entries found in the list", p.entries.size)
                    ReportLine("Records in the library from this list", r.imported)
                    ReportLine("Possible duplicates (kept, not merged)", p.duplicates.size)
                    ReportLine("Incomplete records (no author found)", p.incompleteCount)
                    ReportLine("Uncertain completion years", p.uncertainYearCount)
                    ReportLine("Lines that couldn't be parsed", p.unparsedLines.size)
                    Text(
                        "Every entry is marked Completed in the year it's listed under. No ratings, ISBNs, covers or exact dates were invented. Flagged records show a notice on their detail page.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp),
                    )
                    OutlinedButton(onClick = onShowNeedsReview, modifier = Modifier.padding(top = 6.dp)) { Text("Show records that need review") }
                }
            }
            item { SectionHeader("Year totals") }
            items(p.sections) { sec ->
                Row(Modifier.fillMaxWidth()) {
                    Text("${sec.year}", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "${sec.entryCount} listed" + (sec.statedTotal?.let { " · list says $it" } ?: ""),
                        color = if (sec.discrepancy) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (sec.discrepancy) {
                    Text(
                        "The stated total (${sec.statedTotal}) doesn't match the ${sec.entryCount} titles listed for ${sec.year}. Nothing was changed — add the missing book if one was left off.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error,
                    )
                }
            }
            if (p.duplicates.isNotEmpty()) {
                item { SectionHeader("Possible duplicates") }
                items(p.duplicates) { d ->
                    Text("“${d.first.title}” (${d.first.year}) and “${d.second.title}” (${d.second.year}) — ${d.reason.description.lowercase()}. Both kept; a re-read or a different volume is likely.", style = MaterialTheme.typography.bodySmall)
                }
            }
            val flagged = p.entries.filter { it.needsReview }
            if (flagged.isNotEmpty()) {
                item { SectionHeader("Needs review (${flagged.size})") }
                items(flagged) { e ->
                    Panel {
                        Text("${e.year ?: "No year"} · line ${e.lineNumber}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        Text(e.raw, style = MaterialTheme.typography.bodyMedium)
                        Text(e.reviewReasons.joinToString(" "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
            if (p.unparsedLines.isNotEmpty()) {
                item { SectionHeader("Not imported") }
                items(p.unparsedLines) { (line, text) -> Text("Line $line: $text", style = MaterialTheme.typography.bodySmall) }
            }
            item {
                SectionHeader("Original source")
                OutlinedButton(onClick = { showSource = !showSource }) { Text(if (showSource) "Hide original list" else "Show original list") }
                if (showSource) {
                    SelectionContainer {
                        Text(c.seed.sourceText(), fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportLine(label: String, value: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text("$value", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
    }
}
