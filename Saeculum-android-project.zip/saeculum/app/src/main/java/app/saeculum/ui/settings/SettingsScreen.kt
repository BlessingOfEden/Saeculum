@file:OptIn(ExperimentalMaterial3Api::class)

package app.saeculum.ui.settings

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.ImageSearch
import androidx.compose.material.icons.automirrored.rounded.ListAlt
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.saeculum.BuildConfig
import app.saeculum.core.backup.RestoreMode
import app.saeculum.core.model.BookSort
import app.saeculum.core.model.CaptionMode
import app.saeculum.core.model.Captions
import app.saeculum.data.DarkMode
import app.saeculum.data.StartScreen
import app.saeculum.data.ThemePreset
import app.saeculum.ui.components.BookCover
import app.saeculum.ui.components.ConfirmDialog
import app.saeculum.ui.components.DropdownSelector
import app.saeculum.ui.components.EmptyState
import app.saeculum.ui.components.appViewModel
import app.saeculum.ui.components.coverSource
import app.saeculum.ui.library.DensitySelector
import app.saeculum.ui.theme.LiteraryText
import app.saeculum.ui.theme.LocalIsDark
import app.saeculum.ui.theme.presetSwatch
import java.time.LocalDate

@Composable
fun SettingsScreen(
    onMessage: (String) -> Unit,
    onImportCsv: () -> Unit,
    onFindCovers: () -> Unit,
    onTrash: () -> Unit,
    onSeedReport: () -> Unit,
) {
    val vm = appViewModel { SettingsViewModel(it) }
    val s by vm.settings.collectAsStateWithLifecycle()
    val trash by vm.trash.collectAsStateWithLifecycle()
    val today = LocalDate.now().toString()

    val csvOut = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri -> uri?.let { vm.exportCsv(it, onMessage) } }
    val txtOut = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri -> uri?.let { vm.exportTxt(it, onMessage) } }
    val zipOut = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri -> uri?.let { vm.exportBackup(it, onMessage) } }
    val backupIn = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { vm.readBackup(it, onMessage) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(horizontal = 16.dp).padding(bottom = 32.dp)) {
        Text("Settings", style = LiteraryText.wordmark.copy(fontSize = MaterialTheme.typography.headlineLarge.fontSize), color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp))

        Group("Appearance") {
            Label("Mode")
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                DarkMode.entries.forEachIndexed { i, m ->
                    SegmentedButton(selected = s.darkMode == m, onClick = { vm.setDarkMode(m) }, shape = SegmentedButtonDefaults.itemShape(i, DarkMode.entries.size)) {
                        Text(m.label, maxLines = 1)
                    }
                }
            }
            Label("Theme", top = 14.dp)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ThemePreset.entries.forEach { p -> ThemeCard(p, selected = s.theme == p && !s.dynamicColor) { vm.setTheme(p); if (s.dynamicColor) vm.setDynamic(false) } }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ToggleRow("Use wallpaper colours", "Material You colours from your wallpaper instead of a preset.", s.dynamicColor, vm::setDynamic)
            }
        }

        Group("Library") {
            Label("Grid density (remembered between sessions)")
            DensitySelector(s.columns, vm::setColumns)
            DropdownSelector("Default sort order", BookSort.entries, s.sort, { it.label }, vm::setSort, Modifier.fillMaxWidth().padding(top = 12.dp))
            DropdownSelector("Open the app on", StartScreen.entries, s.startScreen, { it.label }, vm::setStart, Modifier.fillMaxWidth().padding(top = 12.dp))
            ToggleRow("Ratings under covers", "Show your star rating beneath each cover.", s.showRatings, vm::setShowRatings)
            ToggleRow("Titles under covers", "In the three-column view.", s.showTitles, vm::setShowTitles)
            ToggleRow("Completion year under covers", "Shows the year you finished each book.", s.showCompletionYear, vm::setShowYear)
        }

        Group("Library caption") {
            Text("A line shown beneath the Saeculum title.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            CaptionMode.entries.forEach { m ->
                RadioRow(
                    when (m) {
                        CaptionMode.HIDDEN -> "Hidden"
                        CaptionMode.MOTIVATIONAL -> "Short reading caption"
                        CaptionMode.QUOTATION -> "Literary quotation"
                        CaptionMode.CUSTOM -> "My own caption"
                    },
                    s.captionMode == m,
                ) { vm.setCaption(m, if (m == s.captionMode) s.captionId else null) }
            }
            val list = when (s.captionMode) {
                CaptionMode.MOTIVATIONAL -> Captions.motivational
                CaptionMode.QUOTATION -> Captions.quotations
                else -> emptyList()
            }
            if (list.isNotEmpty()) {
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                val current = Captions.resolve(s.captionMode, s.captionId, s.customCaption)
                list.forEach { cap ->
                    Row(
                        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.small).selectable(current?.id == cap.id, role = Role.RadioButton) { vm.setCaption(s.captionMode, cap.id) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        RadioButton(selected = current?.id == cap.id, onClick = null)
                        Column(Modifier.padding(start = 8.dp)) {
                            Text(cap.text, style = LiteraryText.quote)
                            cap.attribution?.let { Text("— $it" + (cap.source?.let { src -> ", $src" } ?: ""), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline) }
                        }
                    }
                }
            }
            if (s.captionMode == CaptionMode.CUSTOM) {
                var text by remember(s.customCaption) { mutableStateOf(s.customCaption) }
                OutlinedTextField(
                    value = text, onValueChange = { text = it.take(140) },
                    label = { Text("Your caption") }, supportingText = { Text("${text.length}/140 · stored only on this device") },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                )
                TextButton(enabled = text != s.customCaption, onClick = { vm.setCustomCaption(text) }) { Text("Save caption") }
            }
        }

        Group("Reading goal") {
            var goal by remember(s.annualGoal) { mutableStateOf(if (s.annualGoal > 0) s.annualGoal.toString() else "") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = goal, onValueChange = { goal = it.filter { c -> c.isDigit() }.take(4) },
                    label = { Text("Books per year") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                TextButton(enabled = (goal.toIntOrNull() ?: 0) != s.annualGoal, onClick = { vm.setGoal(goal.toIntOrNull() ?: 0) }) { Text("Save") }
            }
            Text("Empty or 0 turns the goal off. Progress appears on the Statistics screen.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Group("Data management") {
            Text(
                "Everything is stored on this device — no account needed. Export regularly to keep a copy elsewhere.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            ActionRow(Icons.Rounded.Backup, "Full backup (.zip)", "Every book, note, rating, date and cover image, plus your preferences") { zipOut.launch("saeculum-backup-$today.zip") }
            ActionRow(Icons.Rounded.Restore, "Restore from backup", "Preview first; choose to merge or replace") { backupIn.launch(arrayOf("application/zip", "application/json", "application/octet-stream")) }
            ActionRow(Icons.Rounded.TableChart, "Export CSV", "Spreadsheet of your collection (re-importable)") { csvOut.launch("saeculum-books-$today.csv") }
            ActionRow(Icons.Rounded.Description, "Export reading list (.txt)", "Readable list by completion year and status") { txtOut.launch("saeculum-reading-list-$today.txt") }
            ActionRow(Icons.Rounded.UploadFile, "Import CSV", "Add many books from a spreadsheet", onImportCsv)
            ActionRow(Icons.Rounded.ImageSearch, "Find missing covers & details", "Looks up books without a cover or ISBN", onFindCovers)
            ActionRow(Icons.Rounded.DeleteOutline, "Recently deleted (${trash.size})", "Restore books deleted in the last 30 days", onTrash)
            if (BuildConfig.INCLUDE_READING_HISTORY) {
                ActionRow(Icons.AutoMirrored.Rounded.ListAlt, "Initial reading-list import", "Report for your historical list imported on first launch", onSeedReport)
            }
        }

        Group("About") {
            Text("Saeculum ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.titleSmall)
            Text(
                "Latin for “an age” or “a lifetime” — a record of your reading life.\n\n" +
                    "Book search, ISBN lookup and covers use Open Library and Google Books when you're online. " +
                    "Nothing else leaves your device. The camera is used only on the barcode screen.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    vm.busy?.let { label ->
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            title = { Text(label) },
            text = { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(28.dp)); Text("   Please keep the app open.") } },
        )
    }
    vm.restorePreview?.let { p ->
        var confirmReplace by remember { mutableStateOf(false) }
        val plan = p.plan
        AlertDialog(
            onDismissRequest = vm::cancelRestore,
            title = { Text("Restore backup") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("This backup contains ${plan.total} book${if (plan.total == 1) "" else "s"}.")
                    Text("• ${plan.newBooks.size} not in your library")
                    Text("• ${plan.alreadyPresent.size} already in your library (same record)")
                    Text("• ${plan.likelyDuplicates.size} look like books you already have")
                    if (p.data.skipped.isNotEmpty()) Text("• ${p.data.skipped.size} damaged entr${if (p.data.skipped.size == 1) "y" else "ies"} will be skipped", color = MaterialTheme.colorScheme.error)
                    Text(
                        "Merge adds only the ${plan.newBooks.size} new book${if (plan.newBooks.size == 1) "" else "s"}. Replace deletes your current library and restores the backup exactly.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp),
                    )
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { confirmReplace = true }) { Text("Replace…", color = MaterialTheme.colorScheme.error) }
                    TextButton(enabled = plan.newBooks.isNotEmpty(), onClick = { vm.restore(RestoreMode.MERGE, onMessage) }) { Text("Merge") }
                }
            },
            dismissButton = { TextButton(onClick = vm::cancelRestore) { Text("Cancel") } },
        )
        if (confirmReplace) {
            ConfirmDialog(
                title = "Replace your whole library?",
                message = "All books currently in Saeculum (including Recently Deleted) will be removed and replaced by the ${plan.total} books in this backup. This can't be undone — consider making a backup of your current library first.",
                confirmLabel = "Replace library",
                destructive = true,
                onConfirm = { vm.restore(RestoreMode.REPLACE, onMessage) },
                onDismiss = { confirmReplace = false },
            )
        }
    }
}

@Composable
private fun Group(title: String, content: @Composable () -> Unit) {
    Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 18.dp, bottom = 8.dp, start = 4.dp))
    Surface(shape = MaterialTheme.shapes.extraLarge, color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) { content() }
    }
}

@Composable
private fun Label(text: String, top: androidx.compose.ui.unit.Dp = 0.dp) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = top, bottom = 6.dp))
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 12.dp).clip(MaterialTheme.shapes.small).clickable(role = Role.Switch) { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.small).selectable(selected, role = Role.RadioButton, onClick = onClick).padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Text(label, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun ActionRow(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).clickable(role = Role.Button, onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.outline)
    }
}

@Composable
private fun ThemeCard(p: ThemePreset, selected: Boolean, onClick: () -> Unit) {
    val swatch = presetSwatch(p, LocalIsDark.current)
    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier
            .width(128.dp)
            .clip(MaterialTheme.shapes.large)
            .border(if (selected) 2.dp else 0.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh, MaterialTheme.shapes.large)
            .selectable(selected, role = Role.RadioButton, onClick = onClick),
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                swatch.forEach { c -> Box(Modifier.size(20.dp).clip(CircleShape).background(c)) }
            }
            Spacer(Modifier.height(8.dp))
            Text(p.label, style = MaterialTheme.typography.titleSmall)
            Text(p.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Recently Deleted: soft-deleted books, restorable for 30 days. */
@Composable
fun TrashScreen(onBack: () -> Unit) {
    val vm = appViewModel { SettingsViewModel(it) }
    val trash by vm.trash.collectAsStateWithLifecycle()
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmOne by remember { mutableStateOf<app.saeculum.core.model.Book?>(null) }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Recently deleted") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back") } },
            actions = { if (trash.isNotEmpty()) TextButton(onClick = { confirmEmpty = true }) { Text("Empty") } },
        )
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Deleted books stay here for 30 days, then are removed permanently. Restoring brings back everything, including notes and ratings.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (trash.isEmpty()) EmptyState(Icons.Rounded.DeleteOutline, "Nothing here", "Books you delete appear here so you can change your mind.")
            trash.forEach { b ->
                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerLow) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        BookCover(b.coverSource(), Modifier.width(44.dp), corner = 3.dp, elevation = 1.dp, showFallbackText = false)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(b.title, style = LiteraryText.bookTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(b.authorLine, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                        TextButton(onClick = { vm.restoreFromTrash(b.id) }) { Text("Restore") }
                        TextButton(onClick = { confirmOne = b }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }
    if (confirmEmpty) {
        ConfirmDialog("Delete ${trash.size} book${if (trash.size == 1) "" else "s"} permanently?", "This can't be undone.", "Delete permanently", onConfirm = vm::emptyTrash, onDismiss = { confirmEmpty = false }, destructive = true)
    }
    confirmOne?.let { b ->
        ConfirmDialog("Delete permanently?", "“${b.title}” and its notes will be removed for good.", "Delete", onConfirm = { vm.deleteForever(b.id) }, onDismiss = { confirmOne = null }, destructive = true)
    }
}
