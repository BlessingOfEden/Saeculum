package app.saeculum.ui.settings

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.saeculum.AppContainer
import app.saeculum.core.backup.RestoreMode
import app.saeculum.core.model.Book
import app.saeculum.core.model.BookSort
import app.saeculum.core.model.CaptionMode
import app.saeculum.data.AppSettings
import app.saeculum.data.DarkMode
import app.saeculum.data.RestorePreview
import app.saeculum.data.StartScreen
import app.saeculum.data.ThemePreset
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(private val c: AppContainer) : ViewModel() {
    val settings: StateFlow<AppSettings> = c.settings.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())
    val trash: StateFlow<List<Book>> = c.books.trash.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    var busy by mutableStateOf<String?>(null)
        private set
    var restorePreview by mutableStateOf<RestorePreview?>(null)
        private set

    private fun set(block: suspend () -> Unit) = viewModelScope.launch { block() }

    fun setTheme(v: ThemePreset) = set { c.settings.setTheme(v) }
    fun setDarkMode(v: DarkMode) = set { c.settings.setDarkMode(v) }
    fun setDynamic(v: Boolean) = set { c.settings.setDynamicColor(v) }
    fun setColumns(v: Int) = set { c.settings.setColumns(v) }
    fun setSort(v: BookSort) = set { c.settings.setSort(v) }
    fun setStart(v: StartScreen) = set { c.settings.setStartScreen(v) }
    fun setShowRatings(v: Boolean) = set { c.settings.setShowRatings(v) }
    fun setShowTitles(v: Boolean) = set { c.settings.setShowTitles(v) }
    fun setShowYear(v: Boolean) = set { c.settings.setShowCompletionYear(v) }
    fun setCaption(mode: CaptionMode, id: String?) = set { c.settings.setCaption(mode, id) }
    fun setCustomCaption(text: String) = set { c.settings.setCustomCaption(text) }
    fun setGoal(n: Int) = set { c.settings.setAnnualGoal(n) }

    /** Runs an export and reports success only after the file has been fully written. */
    private fun export(label: String, onResult: (String) -> Unit, block: suspend () -> String) {
        busy = label
        viewModelScope.launch {
            val msg = try {
                block()
            } catch (e: Exception) {
                "Export failed: ${e.message ?: "unknown error"}. Nothing was changed."
            }
            busy = null
            onResult(msg)
        }
    }

    fun exportCsv(uri: Uri, onResult: (String) -> Unit) = export("Exporting CSV…", onResult) {
        val n = c.transfer.exportCsv(uri)
        "Exported $n book${if (n == 1) "" else "s"} to CSV."
    }

    fun exportTxt(uri: Uri, onResult: (String) -> Unit) = export("Exporting text list…", onResult) {
        val n = c.transfer.exportTxt(uri)
        "Exported a reading list of $n book${if (n == 1) "" else "s"}."
    }

    fun exportBackup(uri: Uri, onResult: (String) -> Unit) = export("Creating backup…", onResult) {
        val s = c.transfer.exportBackup(uri)
        "Backup saved: ${s.books} book${if (s.books == 1) "" else "s"} and ${s.covers} cover image${if (s.covers == 1) "" else "s"}."
    }

    fun readBackup(uri: Uri, onError: (String) -> Unit) {
        busy = "Reading backup…"
        viewModelScope.launch {
            try {
                restorePreview = c.transfer.readBackup(uri)
            } catch (e: Exception) {
                onError(e.message ?: "Couldn't read that backup.")
            } finally {
                busy = null
            }
        }
    }

    fun cancelRestore() {
        restorePreview?.let { c.transfer.discard(it) }
        restorePreview = null
    }

    fun restore(mode: RestoreMode, onResult: (String) -> Unit) {
        val p = restorePreview ?: return
        restorePreview = null
        busy = "Restoring…"
        viewModelScope.launch {
            val msg = try {
                val r = c.transfer.restore(p, mode)
                "Restored ${r.restored} book${if (r.restored == 1) "" else "s"}" +
                    (if (r.coversRestored > 0) " with ${r.coversRestored} cover${if (r.coversRestored == 1) "" else "s"}" else "") +
                    (if (r.failed > 0) ". ${r.failed} couldn't be restored." else ".")
            } catch (e: Exception) {
                c.transfer.discard(p)
                "Restore failed: ${e.message ?: "unknown error"}. Your library was not changed."
            }
            busy = null
            onResult(msg)
        }
    }

    fun restoreFromTrash(id: Long) = set { c.books.restoreFromTrash(id) }
    fun deleteForever(id: Long) = set { c.books.deleteForever(id) }
    fun emptyTrash() = set { trash.value.forEach { c.books.deleteForever(it.id) } }
}
