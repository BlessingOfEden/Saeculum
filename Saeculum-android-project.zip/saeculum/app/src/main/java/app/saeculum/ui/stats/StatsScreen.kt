@file:OptIn(ExperimentalLayoutApi::class)

package app.saeculum.ui.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.saeculum.core.stats.StatsCalculator
import app.saeculum.ui.components.BookCover
import app.saeculum.ui.components.EmptyState
import app.saeculum.ui.components.Panel
import app.saeculum.ui.components.SectionHeader
import app.saeculum.ui.components.StarsDisplay
import app.saeculum.ui.components.appViewModel
import app.saeculum.ui.components.coverSource
import app.saeculum.ui.components.progressText
import app.saeculum.ui.theme.LiteraryText
import app.saeculum.ui.theme.Saeculum
import java.util.Locale

@Composable
fun StatsScreen(onOpenBook: (Long) -> Unit) {
    val vm = appViewModel { StatsViewModel(it) }
    val ui by vm.state.collectAsStateWithLifecycle()
    val s = ui.stats
    var selectedYear by rememberSaveable { mutableStateOf<Int?>(null) }
    var unknownSelected by rememberSaveable { mutableStateOf(false) }
    var editGoal by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(horizontal = 16.dp).padding(bottom = 32.dp),
    ) {
        Text("Statistics", style = LiteraryText.wordmark.copy(fontSize = MaterialTheme.typography.headlineLarge.fontSize), color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 18.dp))
        Text("Your reading life, counted from what you've recorded.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (s == null) return@Column
        if (s.totalInLibrary == 0) {
            EmptyState(Icons.Rounded.Insights, "No statistics yet", "Add books and mark them completed to see yearly totals, ratings and insights here.")
            return@Column
        }

        // Headline numbers
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("Completed", s.totalCompleted.toString(), "all time", Modifier.weight(1f))
            Tile("In ${s.currentYear}", s.completedThisYear.toString(), "books finished", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("Reading", s.reading.toString(), "now", Modifier.weight(1f))
            Tile("To read", s.toRead.toString(), "waiting", Modifier.weight(1f))
            Tile("In library", s.totalInLibrary.toString(), "all statuses", Modifier.weight(1f))
        }

        // Goal
        Spacer(Modifier.height(12.dp))
        Panel {
            val g = s.goal
            if (g == null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("No reading goal set for ${s.currentYear}.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = { editGoal = true }) { Text("Set goal") }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GoalRing(g.fraction, Modifier.size(84.dp))
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Goal: ${g.goal} books in ${s.currentYear}", style = MaterialTheme.typography.titleMedium)
                        Text("${g.done} read" + if (g.remaining > 0) " · ${g.remaining} to go" else " · goal reached", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                        TextButton(onClick = { editGoal = true }) { Text("Change goal") }
                    }
                }
            }
        }

        // By year
        if (s.completedByYear.isNotEmpty() || s.completedUnknownYear > 0) {
            SectionHeader("Books completed by year")
            if (s.completedByYear.isNotEmpty()) {
                YearBars(s.completedByYear.reversed(), selectedYear) { y -> selectedYear = if (selectedYear == y) null else y; unknownSelected = false }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                s.completedByYear.forEach { (y, n) ->
                    FilterChip(selected = selectedYear == y && !unknownSelected, onClick = { selectedYear = y; unknownSelected = false }, label = { Text("$y · $n") })
                }
                if (s.completedUnknownYear > 0) {
                    FilterChip(selected = unknownSelected, onClick = { unknownSelected = true; selectedYear = null }, label = { Text("Year unknown · ${s.completedUnknownYear}") })
                }
            }
            val showYear = if (unknownSelected) null else (selectedYear ?: s.completedByYear.firstOrNull()?.first)
            if (unknownSelected || showYear != null) {
                val list = StatsCalculator.booksForYear(ui.books, if (unknownSelected) null else showYear)
                Text(
                    if (unknownSelected) "${list.size} completed book${if (list.size == 1) "" else "s"} without a recorded year"
                    else "${list.size} book${if (list.size == 1) "" else "s"} completed in $showYear",
                    style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 12.dp, bottom = 8.dp),
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    list.forEach { b ->
                        Box(Modifier.width(62.dp).clip(RoundedCornerShape(4.dp)).clickable(role = Role.Button) { onOpenBook(b.id) }) {
                            BookCover(b.coverSource(), Modifier.fillMaxWidth(), corner = 4.dp, elevation = 1.5.dp)
                        }
                    }
                }
            }
        }

        // Insights
        SectionHeader("Insights")
        Panel {
            val insights = buildList {
                s.mostProductiveYear?.let { (y, n) -> add("Your most productive year was $y, with $n completed book${if (n == 1) "" else "s"}.") }
                s.yearChange?.let { ch ->
                    val d = ch.delta
                    add(
                        when {
                            d > 0 -> "${ch.year}: $d more book${if (d == 1) "" else "s"} than ${ch.previousYear} (${ch.count} vs ${ch.previousCount})."
                            d < 0 -> "${ch.year}: ${-d} fewer book${if (d == -1) "" else "s"} than ${ch.previousYear} so far (${ch.count} vs ${ch.previousCount})."
                            else -> "${ch.year} matches ${ch.previousYear} with ${ch.count} books each."
                        },
                    )
                }
                if (s.completedUnknownYear > 0) add("${s.completedUnknownYear} completed book${if (s.completedUnknownYear == 1) " has" else "s have"} no recorded year and ${if (s.completedUnknownYear == 1) "isn't" else "aren't"} in the yearly totals.")
            }
            if (insights.isEmpty()) {
                Text("Insights appear once you've completed books in at least one year.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                insights.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
            }
        }

        if (s.topAuthors.isNotEmpty()) {
            SectionHeader("Most-read authors")
            Panel {
                s.topAuthors.forEach { a ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(a.name, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${a.count} books", color = MaterialTheme.colorScheme.secondary)
                    }
                }
                Text("Authors with two or more completed books.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            }
        }

        if (s.favorites.isNotEmpty()) {
            SectionHeader("Five-star favourites")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                s.favorites.forEach { b ->
                    Column(Modifier.width(76.dp).clickable(role = Role.Button) { onOpenBook(b.id) }) {
                        BookCover(b.coverSource(), Modifier.fillMaxWidth())
                        Text(b.title, style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }

        SectionHeader("Ratings")
        Panel {
            if (s.rated == 0) {
                Text("No books rated yet. Ratings are your own — open a book to rate it.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(String.format(Locale.getDefault(), "%.1f", s.averageRating ?: 0.0), style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("average of ${s.rated} rated book${if (s.rated == 1) "" else "s"}", style = MaterialTheme.typography.bodyMedium)
                        Text("${s.unrated} unrated", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }
                }
                val max = (s.ratingDistribution.maxOrNull() ?: 0).coerceAtLeast(1)
                for (star in 5 downTo 1) {
                    val n = s.ratingDistribution[star - 1]
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp).semantics(mergeDescendants = true) { contentDescription = "$star stars: $n books" }) {
                        StarsDisplay(star, 12.dp)
                        Spacer(Modifier.width(8.dp))
                        Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Saeculum.colors.chartMuted)) {
                            Box(Modifier.fillMaxWidth(n.toFloat() / max).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Saeculum.colors.chart))
                        }
                        Text("  $n", style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(36.dp))
                    }
                }
            }
        }

        if (s.inProgress.isNotEmpty()) {
            SectionHeader("In progress")
            Panel {
                s.inProgress.forEach { b ->
                    Column(Modifier.fillMaxWidth().clickable(role = Role.Button) { onOpenBook(b.id) }.padding(vertical = 6.dp)) {
                        Text(b.title, style = LiteraryText.bookTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val f = b.progressFraction
                        if (f != null) {
                            LinearProgressIndicator(progress = { f }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(5.dp).clip(RoundedCornerShape(3.dp)))
                            Text(progressText(b) + (b.progressPercentDisplay?.takeIf { b.currentPage != null }?.let { " · $it%" } ?: ""), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            Text("Progress not tracked", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        }
                    }
                }
            }
        }

        Text(
            "How these are counted: every completed book counts once, whatever its length — a graphic novel and an 800-page novel are each one book. " +
                "Books in To Read, Want to Buy, Currently Reading, Paused or Abandoned never count as read. Yearly totals use the completion year, not the publication year or the date a book was added.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline,
            modifier = Modifier.padding(top = 20.dp),
        )
    }

    if (editGoal) {
        var text by remember { mutableStateOf(if (ui.goal > 0) ui.goal.toString() else "") }
        AlertDialog(
            onDismissRequest = { editGoal = false },
            title = { Text("Annual reading goal") },
            text = {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.filter { c -> c.isDigit() }.take(4) },
                    label = { Text("Books per year") }, singleLine = true,
                    supportingText = { Text("Leave empty or 0 to turn the goal off.") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            },
            confirmButton = { TextButton(onClick = { vm.setGoal(text.toIntOrNull() ?: 0); editGoal = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editGoal = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Tile(label: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = modifier) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            Text(value, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Text(caption, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline, maxLines = 1)
        }
    }
}

@Composable
private fun GoalRing(fraction: Float, modifier: Modifier) {
    val track = Saeculum.colors.chartMuted
    val fill = Saeculum.colors.chart
    Box(modifier.semantics { contentDescription = "${(fraction * 100).toInt()} percent of goal" }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 9.dp.toPx()
            val d = size.minDimension - stroke
            val topLeft = Offset((size.width - d) / 2, (size.height - d) / 2)
            drawArc(track, 0f, 360f, false, topLeft, Size(d, d), style = Stroke(stroke))
            drawArc(fill, -90f, 360f * fraction, false, topLeft, Size(d, d), style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Text("${(fraction * 100).toInt()}%", style = MaterialTheme.typography.titleMedium)
    }
}

/** Simple, readable vertical bars (oldest → newest). Tapping a bar shows that year's books. */
@Composable
private fun YearBars(data: List<Pair<Int, Int>>, selected: Int?, onSelect: (Int) -> Unit) {
    val max = (data.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)
    val chart = Saeculum.colors.chart
    val muted = chart.copy(alpha = 0.45f)
    val scroll = data.size > 8
    Row(
        Modifier.fillMaxWidth().height(170.dp).then(if (scroll) Modifier.horizontalScroll(rememberScrollState()) else Modifier),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        data.forEach { (year, n) ->
            val active = selected == null || selected == year
            Column(
                (if (scroll) Modifier.width(40.dp) else Modifier.weight(1f))
                    .clickable(role = Role.Button) { onSelect(year) }
                    .semantics(mergeDescendants = true) { contentDescription = "$year: $n books" },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("$n", style = MaterialTheme.typography.labelMedium, color = if (active) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline)
                Box(
                    Modifier
                        .padding(top = 2.dp)
                        .fillMaxWidth(0.72f)
                        .height((120f * n / max).dp.coerceAtLeast(3.dp))
                        .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                        .background(if (active) chart else muted),
                )
                Text("$year", style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp), maxLines = 1)
            }
        }
    }
}
