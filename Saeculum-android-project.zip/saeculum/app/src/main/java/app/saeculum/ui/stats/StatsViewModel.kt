package app.saeculum.ui.stats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.saeculum.AppContainer
import app.saeculum.core.model.Book
import app.saeculum.core.stats.ReadingStats
import app.saeculum.core.stats.StatsCalculator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class StatsUi(val stats: ReadingStats? = null, val books: List<Book> = emptyList(), val goal: Int = 0)

class StatsViewModel(private val c: AppContainer) : ViewModel() {
    val state: StateFlow<StatsUi> = combine(c.books.books, c.settings.settings) { books, s ->
        StatsUi(StatsCalculator.compute(books, LocalDate.now().year, s.annualGoal), books, s.annualGoal)
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatsUi())

    fun setGoal(n: Int) = viewModelScope.launch { c.settings.setAnnualGoal(n) }
}
