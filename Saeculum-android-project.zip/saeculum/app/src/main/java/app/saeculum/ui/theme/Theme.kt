package app.saeculum.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.saeculum.data.DarkMode
import app.saeculum.data.ThemePreset

/** Colours outside the Material scheme that the library UI needs. */
@Immutable
data class SaeculumColors(
    val star: Color,
    val starEmpty: Color,
    val coverEdge: Color,
    val coverShadow: Color,
    /** Background tones for generated fallback covers. */
    val fallbackCovers: List<Color>,
    val onFallbackCover: Color,
    val chart: Color,
    val chartMuted: Color,
)

val LocalSaeculumColors = staticCompositionLocalOf {
    SaeculumColors(Color(0xFFC08A12), Color(0x33000000), Color(0x1F000000), Color(0x33000000), listOf(Color.Gray), Color.White, Color.Red, Color.Gray)
}

object Saeculum {
    val colors: SaeculumColors @Composable get() = LocalSaeculumColors.current
}

private data class Palette(val light: ColorScheme, val dark: ColorScheme, val lightExtra: SaeculumColors, val darkExtra: SaeculumColors)

private fun extras(dark: Boolean, chart: Color, covers: List<Color>) = SaeculumColors(
    star = if (dark) Color(0xFFF2C14E) else Color(0xFFC08A12),
    starEmpty = if (dark) Color(0x40FFFFFF) else Color(0x33000000),
    coverEdge = if (dark) Color(0x26FFFFFF) else Color(0x1F2A1A12),
    coverShadow = if (dark) Color(0x99000000) else Color(0x40301A10),
    fallbackCovers = covers,
    onFallbackCover = Color(0xFFFBF5EC),
    chart = chart,
    chartMuted = if (dark) Color(0x33FFFFFF) else Color(0x22000000),
)

// ---- Saeculum (default): crimson #B32134, oxblood #8B0101, sienna #A0522C, parchment #D8C6B2, white.
private val saeculum = Palette(
    light = lightColorScheme(
        primary = Color(0xFFB32134), onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFF8DADC), onPrimaryContainer = Color(0xFF5C0A14),
        secondary = Color(0xFFA0522C), onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFF4DFD1), onSecondaryContainer = Color(0xFF4A2410),
        tertiary = Color(0xFF8B0101), onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFEBD3CB), onTertiaryContainer = Color(0xFF3B0000),
        background = Color(0xFFFAF6F0), onBackground = Color(0xFF231A17),
        surface = Color(0xFFFAF6F0), onSurface = Color(0xFF231A17),
        surfaceVariant = Color(0xFFEDE3D6), onSurfaceVariant = Color(0xFF5A4A40),
        surfaceTint = Color(0xFFB32134),
        surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFF6F0E8),
        surfaceContainer = Color(0xFFF1E9DE), surfaceContainerHigh = Color(0xFFEBE1D4),
        surfaceContainerHighest = Color(0xFFE4D8C8),
        outline = Color(0xFF8C7B6E), outlineVariant = Color(0xFFD8C6B2),
        error = Color(0xFFB3261E), onError = Color(0xFFFFFFFF),
        inverseSurface = Color(0xFF382E2A), inverseOnSurface = Color(0xFFFAEEE6), inversePrimary = Color(0xFFF0A0A8),
        scrim = Color(0xFF000000),
    ),
    dark = darkColorScheme(
        primary = Color(0xFFF0A0A8), onPrimary = Color(0xFF5C0A14),
        primaryContainer = Color(0xFF8B0101), onPrimaryContainer = Color(0xFFFFDADC),
        secondary = Color(0xFFE7A887), onSecondary = Color(0xFF4A2410),
        secondaryContainer = Color(0xFF6E3618), onSecondaryContainer = Color(0xFFFFDCC8),
        tertiary = Color(0xFFD8C6B2), onTertiary = Color(0xFF3A2E22),
        tertiaryContainer = Color(0xFF52443A), onTertiaryContainer = Color(0xFFF4E6D6),
        background = Color(0xFF15100E), onBackground = Color(0xFFEDE0D8),
        surface = Color(0xFF15100E), onSurface = Color(0xFFEDE0D8),
        surfaceVariant = Color(0xFF3A302B), onSurfaceVariant = Color(0xFFD4C4B8),
        surfaceTint = Color(0xFFF0A0A8),
        surfaceContainerLowest = Color(0xFF100B09), surfaceContainerLow = Color(0xFF1D1714),
        surfaceContainer = Color(0xFF221B18), surfaceContainerHigh = Color(0xFF2C2421),
        surfaceContainerHighest = Color(0xFF372E2A),
        outline = Color(0xFF9C8B80), outlineVariant = Color(0xFF4E423B),
        error = Color(0xFFF2B8B5), onError = Color(0xFF601410),
        inverseSurface = Color(0xFFEDE0D8), inverseOnSurface = Color(0xFF382E2A), inversePrimary = Color(0xFFB32134),
        scrim = Color(0xFF000000),
    ),
    lightExtra = extras(false, Color(0xFFB32134), listOf(Color(0xFF8B0101), Color(0xFFA0522C), Color(0xFF6B3E2E), Color(0xFF7A2A35), Color(0xFF5C4A3D))),
    darkExtra = extras(true, Color(0xFFF0A0A8), listOf(Color(0xFF6E1414), Color(0xFF7D4122), Color(0xFF55332A), Color(0xFF5E2129), Color(0xFF4A3C31))),
)

// ---- Folio: library green & brass
private val folio = Palette(
    light = lightColorScheme(
        primary = Color(0xFF2F5D50), onPrimary = Color.White,
        primaryContainer = Color(0xFFCFE6DC), onPrimaryContainer = Color(0xFF0B2A21),
        secondary = Color(0xFF8A6D3B), onSecondary = Color.White,
        secondaryContainer = Color(0xFFF1E3C8), onSecondaryContainer = Color(0xFF3A2A0C),
        tertiary = Color(0xFF6B4E2E), onTertiary = Color.White,
        tertiaryContainer = Color(0xFFEBDDCB), onTertiaryContainer = Color(0xFF2B1A08),
        background = Color(0xFFF7F6F0), onBackground = Color(0xFF1A1D1B),
        surface = Color(0xFFF7F6F0), onSurface = Color(0xFF1A1D1B),
        surfaceVariant = Color(0xFFE2E5DC), onSurfaceVariant = Color(0xFF444B45),
        surfaceTint = Color(0xFF2F5D50),
        surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFF1F1EA),
        surfaceContainer = Color(0xFFEBECE4), surfaceContainerHigh = Color(0xFFE5E6DE),
        surfaceContainerHighest = Color(0xFFDFE1D8),
        outline = Color(0xFF747B74), outlineVariant = Color(0xFFC6CBC2),
        inverseSurface = Color(0xFF2E322F), inverseOnSurface = Color(0xFFEFF1EB), inversePrimary = Color(0xFF9CCFBE),
    ),
    dark = darkColorScheme(
        primary = Color(0xFF9CCFBE), onPrimary = Color(0xFF00382C),
        primaryContainer = Color(0xFF1C4A3E), onPrimaryContainer = Color(0xFFCFE6DC),
        secondary = Color(0xFFDDC08A), onSecondary = Color(0xFF3E2D06),
        secondaryContainer = Color(0xFF574419), onSecondaryContainer = Color(0xFFF1E3C8),
        tertiary = Color(0xFFD9BE9A), onTertiary = Color(0xFF3B2810),
        tertiaryContainer = Color(0xFF523C22), onTertiaryContainer = Color(0xFFEBDDCB),
        background = Color(0xFF0F1412), onBackground = Color(0xFFE0E4DE),
        surface = Color(0xFF0F1412), onSurface = Color(0xFFE0E4DE),
        surfaceVariant = Color(0xFF2F3632), onSurfaceVariant = Color(0xFFC2C9C2),
        surfaceTint = Color(0xFF9CCFBE),
        surfaceContainerLowest = Color(0xFF0A0F0D), surfaceContainerLow = Color(0xFF171D1A),
        surfaceContainer = Color(0xFF1B211E), surfaceContainerHigh = Color(0xFF252C28),
        surfaceContainerHighest = Color(0xFF303733),
        outline = Color(0xFF8C948D), outlineVariant = Color(0xFF414943),
        inverseSurface = Color(0xFFE0E4DE), inverseOnSurface = Color(0xFF2E322F), inversePrimary = Color(0xFF2F5D50),
    ),
    lightExtra = extras(false, Color(0xFF2F5D50), listOf(Color(0xFF2F5D50), Color(0xFF6B4E2E), Color(0xFF3D4F5C), Color(0xFF5B5A3A), Color(0xFF7A4E3A))),
    darkExtra = extras(true, Color(0xFF9CCFBE), listOf(Color(0xFF1F443A), Color(0xFF4E3820), Color(0xFF2C3A44), Color(0xFF42412A), Color(0xFF59392A))),
)

// ---- Midnight Ink: navy & gilt
private val ink = Palette(
    light = lightColorScheme(
        primary = Color(0xFF2B3A67), onPrimary = Color.White,
        primaryContainer = Color(0xFFDCE1FF), onPrimaryContainer = Color(0xFF0D1A42),
        secondary = Color(0xFF9A7B1C), onSecondary = Color.White,
        secondaryContainer = Color(0xFFF5E6B8), onSecondaryContainer = Color(0xFF332600),
        tertiary = Color(0xFF6A4C7A), onTertiary = Color.White,
        tertiaryContainer = Color(0xFFF0DBFF), onTertiaryContainer = Color(0xFF26113A),
        background = Color(0xFFF8F7F4), onBackground = Color(0xFF1B1B1F),
        surface = Color(0xFFF8F7F4), onSurface = Color(0xFF1B1B1F),
        surfaceVariant = Color(0xFFE3E2EC), onSurfaceVariant = Color(0xFF46464F),
        surfaceTint = Color(0xFF2B3A67),
        surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFF2F1F0),
        surfaceContainer = Color(0xFFECEBEB), surfaceContainerHigh = Color(0xFFE6E5E6),
        surfaceContainerHighest = Color(0xFFE0DFE1),
        outline = Color(0xFF777680), outlineVariant = Color(0xFFC7C6D0),
        inverseSurface = Color(0xFF303034), inverseOnSurface = Color(0xFFF3F0F4), inversePrimary = Color(0xFFB6C4FF),
    ),
    dark = darkColorScheme(
        primary = Color(0xFFB6C4FF), onPrimary = Color(0xFF15275A),
        primaryContainer = Color(0xFF2E3F71), onPrimaryContainer = Color(0xFFDCE1FF),
        secondary = Color(0xFFE6C55A), onSecondary = Color(0xFF3B2F00),
        secondaryContainer = Color(0xFF574500), onSecondaryContainer = Color(0xFFF5E6B8),
        tertiary = Color(0xFFDAB9EA), onTertiary = Color(0xFF3D2650),
        tertiaryContainer = Color(0xFF553C67), onTertiaryContainer = Color(0xFFF0DBFF),
        background = Color(0xFF0E1018), onBackground = Color(0xFFE4E1E9),
        surface = Color(0xFF0E1018), onSurface = Color(0xFFE4E1E9),
        surfaceVariant = Color(0xFF2E3040), onSurfaceVariant = Color(0xFFC7C6D0),
        surfaceTint = Color(0xFFB6C4FF),
        surfaceContainerLowest = Color(0xFF090B12), surfaceContainerLow = Color(0xFF161925),
        surfaceContainer = Color(0xFF1A1D2A), surfaceContainerHigh = Color(0xFF242836),
        surfaceContainerHighest = Color(0xFF2F3342),
        outline = Color(0xFF91909A), outlineVariant = Color(0xFF46464F),
        inverseSurface = Color(0xFFE4E1E9), inverseOnSurface = Color(0xFF303034), inversePrimary = Color(0xFF2B3A67),
    ),
    lightExtra = extras(false, Color(0xFF2B3A67), listOf(Color(0xFF2B3A67), Color(0xFF6A4C7A), Color(0xFF3B5566), Color(0xFF7A6420), Color(0xFF4A4A5C))),
    darkExtra = extras(true, Color(0xFFB6C4FF), listOf(Color(0xFF233056), Color(0xFF4A3557), Color(0xFF2A3D49), Color(0xFF574812), Color(0xFF363645))),
)

// ---- Sepia: umber & cream
private val sepia = Palette(
    light = lightColorScheme(
        primary = Color(0xFF7A5230), onPrimary = Color.White,
        primaryContainer = Color(0xFFF2DCC6), onPrimaryContainer = Color(0xFF2E1604),
        secondary = Color(0xFF6E5B48), onSecondary = Color.White,
        secondaryContainer = Color(0xFFEDDFCF), onSecondaryContainer = Color(0xFF261A0E),
        tertiary = Color(0xFF55624A), onTertiary = Color.White,
        tertiaryContainer = Color(0xFFD8E7C8), onTertiaryContainer = Color(0xFF131F0B),
        background = Color(0xFFFBF5EA), onBackground = Color(0xFF221A13),
        surface = Color(0xFFFBF5EA), onSurface = Color(0xFF221A13),
        surfaceVariant = Color(0xFFEFE2D1), onSurfaceVariant = Color(0xFF52443A),
        surfaceTint = Color(0xFF7A5230),
        surfaceContainerLowest = Color(0xFFFFFDF8), surfaceContainerLow = Color(0xFFF7EFE2),
        surfaceContainer = Color(0xFFF2E9DA), surfaceContainerHigh = Color(0xFFECE2D2),
        surfaceContainerHighest = Color(0xFFE6DBCA),
        outline = Color(0xFF85746A), outlineVariant = Color(0xFFD8C6B4),
        inverseSurface = Color(0xFF372F27), inverseOnSurface = Color(0xFFFBEEE2), inversePrimary = Color(0xFFE8BC93),
    ),
    dark = darkColorScheme(
        primary = Color(0xFFE8BC93), onPrimary = Color(0xFF462A0D),
        primaryContainer = Color(0xFF5F3E1F), onPrimaryContainer = Color(0xFFF2DCC6),
        secondary = Color(0xFFD9C2AC), onSecondary = Color(0xFF3C2D1E),
        secondaryContainer = Color(0xFF544332), onSecondaryContainer = Color(0xFFEDDFCF),
        tertiary = Color(0xFFBCCBAD), onTertiary = Color(0xFF28341F),
        tertiaryContainer = Color(0xFF3E4A34), onTertiaryContainer = Color(0xFFD8E7C8),
        background = Color(0xFF17120D), onBackground = Color(0xFFEEE0D3),
        surface = Color(0xFF17120D), onSurface = Color(0xFFEEE0D3),
        surfaceVariant = Color(0xFF3B3129), onSurfaceVariant = Color(0xFFD6C4B4),
        surfaceTint = Color(0xFFE8BC93),
        surfaceContainerLowest = Color(0xFF110D09), surfaceContainerLow = Color(0xFF1F1913),
        surfaceContainer = Color(0xFF241D17), surfaceContainerHigh = Color(0xFF2E2721),
        surfaceContainerHighest = Color(0xFF39312B),
        outline = Color(0xFF9F8E80), outlineVariant = Color(0xFF52443A),
        inverseSurface = Color(0xFFEEE0D3), inverseOnSurface = Color(0xFF372F27), inversePrimary = Color(0xFF7A5230),
    ),
    lightExtra = extras(false, Color(0xFF7A5230), listOf(Color(0xFF7A5230), Color(0xFF55624A), Color(0xFF6E5B48), Color(0xFF8A4B3A), Color(0xFF4F4A42))),
    darkExtra = extras(true, Color(0xFFE8BC93), listOf(Color(0xFF5A3B20), Color(0xFF3E4A34), Color(0xFF4F4031), Color(0xFF633527), Color(0xFF3B3731))),
)

private fun paletteFor(p: ThemePreset) = when (p) {
    ThemePreset.SAECULUM -> saeculum
    ThemePreset.FOLIO -> folio
    ThemePreset.INK -> ink
    ThemePreset.SEPIA -> sepia
}

/** Preview swatches for the theme picker. */
fun presetSwatch(p: ThemePreset, dark: Boolean): List<Color> {
    val s = if (dark) paletteFor(p).dark else paletteFor(p).light
    return listOf(s.primary, s.secondary, s.tertiary, s.surfaceContainerHigh)
}

// ---- Typography: serif for literary display text, the platform sans for controls and body.
private val Serif = FontFamily.Serif
private val base = Typography()
val SaeculumTypography = Typography(
    displayLarge = base.displayLarge.copy(fontFamily = Serif),
    displayMedium = base.displayMedium.copy(fontFamily = Serif),
    displaySmall = base.displaySmall.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    headlineLarge = base.headlineLarge.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    headlineMedium = base.headlineMedium.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    headlineSmall = base.headlineSmall.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    titleLarge = base.titleLarge.copy(fontFamily = Serif, fontWeight = FontWeight.SemiBold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    titleSmall = base.titleSmall,
    bodyLarge = base.bodyLarge,
    bodyMedium = base.bodyMedium,
    bodySmall = base.bodySmall,
    labelLarge = base.labelLarge,
    labelMedium = base.labelMedium,
    labelSmall = base.labelSmall,
)

/** Serif styles for book titles and quotations. */
object LiteraryText {
    val bookTitle = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 19.sp)
    val bookTitleLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 26.sp, lineHeight = 31.sp)
    val quote = TextStyle(fontFamily = FontFamily.Serif, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, fontSize = 15.sp, lineHeight = 21.sp)
    val wordmark = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 38.sp, letterSpacing = 0.5.sp)
}

val SaeculumShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun SaeculumTheme(
    preset: ThemePreset = ThemePreset.SAECULUM,
    darkMode: DarkMode = DarkMode.SYSTEM,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val dark = when (darkMode) {
        DarkMode.SYSTEM -> isSystemInDarkTheme()
        DarkMode.LIGHT -> false
        DarkMode.DARK -> true
    }
    val palette = paletteFor(preset)
    val scheme = if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val ctx = LocalContext.current
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else if (dark) palette.dark else palette.light
    val extra = (if (dark) palette.darkExtra else palette.lightExtra).let {
        if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) it.copy(chart = scheme.primary) else it
    }
    CompositionLocalProvider(LocalSaeculumColors provides extra, LocalIsDark provides dark) {
        MaterialTheme(colorScheme = scheme, typography = SaeculumTypography, shapes = SaeculumShapes, content = content)
    }
}

val LocalIsDark = staticCompositionLocalOf { false }
