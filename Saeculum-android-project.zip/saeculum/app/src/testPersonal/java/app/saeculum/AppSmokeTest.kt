package app.saeculum

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.ui.platform.ViewRootForTest
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.ExperimentalTestApi
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.hasContentDescription
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.isRoot
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.ext.junit.runners.AndroidJUnit4
import app.saeculum.core.model.ReadingStatus
import app.saeculum.data.DarkMode
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

/**
 * End-to-end smoke test on the JVM (Robolectric): launches the real MainActivity with the real Room
 * database, DataStore and Compose UI, runs the first-launch migration, walks the main screens and
 * saves screenshots to app/build/screenshots.
 */
@OptIn(ExperimentalTestApi::class)
@RunWith(AndroidJUnit4::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [34], qualifiers = "w400dp-h860dp-xxhdpi")
class AppSmokeTest {

    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    private val outDir = File(System.getProperty("user.dir"), "build/screenshots").apply { mkdirs() }
    private val container get() = (rule.activity.application as SaeculumApp).container

    /** Draws every Compose window (main screen, then dialogs/sheets on top) into one bitmap. */
    private fun shot(name: String) {
        rule.waitForIdle()
        val views = rule.onAllNodes(isRoot()).fetchSemanticsNodes().map { (it.root as ViewRootForTest).view.rootView }.distinct()
        val main = views.first()
        val bmp = Bitmap.createBitmap(main.width, main.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val origin = IntArray(2).also { main.getLocationOnScreen(it) }
        views.forEachIndexed { i, v ->
            val loc = IntArray(2).also { v.getLocationOnScreen(it) }
            // Robolectric reports (0,0) for dialog windows; dialogs are centred on a real device.
            val dx = if (i > 0 && loc[0] == 0 && v.width < main.width) (main.width - v.width) / 2 else loc[0] - origin[0]
            val dy = if (i > 0 && loc[1] == 0 && v.height < main.height) (main.height - v.height) / 2 else loc[1] - origin[1]
            if (i > 0 && v.width < main.width) canvas.drawColor(0x66000000)
            canvas.save()
            canvas.translate(dx.toFloat(), dy.toFloat())
            v.draw(canvas)
            canvas.restore()
        }
        File(outDir, "$name.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    private fun tab(label: String) {
        rule.onAllNodes(hasText(label) and SemanticsMatcher.expectValue(SemanticsProperties.Role, Role.Tab)).onFirst().performClick()
        rule.waitForIdle()
    }

    private fun dump(n: androidx.compose.ui.semantics.SemanticsNode, depth: Int = 0): String =
        "  ".repeat(depth) + n.config.toString().take(160) + "\n" + n.children.joinToString("") { dump(it, depth + 1) }

    private fun waitText(t: String, ms: Long = 20_000) = rule.waitUntil(ms) {
        rule.onAllNodes(hasText(t, substring = true)).fetchSemanticsNodes().isNotEmpty()
    }

    @Test fun firstLaunchMigratesHistoryAndMainScreensWork() {
        // First-launch migration of the bundled reading list
        rule.waitUntil(30_000) { runBlocking { container.books.liveBooks().size } == 81 }
        val books = runBlocking { container.books.liveBooks() }
        assertEquals(81, books.size)
        assertTrue(books.all { it.status == ReadingStatus.COMPLETED && it.rating == null })
        assertEquals(6, books.count { it.completedYear == 2026 })

        waitText("Your reading history is here")
        shot("01-first-launch-report")
        rule.onNodeWithText("OK").performClick()

        waitText("Saeculum")
        shot("02-library-3-columns")

        rule.onNodeWithContentDescription("One column").performClick()
        waitText("Completed 2026")
        shot("03-library-1-column")

        rule.onNodeWithContentDescription("Six columns").performClick()
        rule.waitUntil(10_000) { rule.onAllNodes(hasText("Completed 2026", substring = true)).fetchSemanticsNodes().isEmpty() }
        rule.waitUntil(10_000) { runBlocking { container.settings.current().columns } == 6 }
        shot("04-library-6-columns")

        rule.onNodeWithContentDescription("Three columns").performClick()
        rule.waitUntil(10_000) { runBlocking { container.settings.current().columns } == 3 }
        rule.waitForIdle()
        rule.onAllNodes(hasContentDescription("Cover of Tortilla Flat", substring = true)).onFirst().performClick()
        try {
            waitText("Your rating")
        } catch (e: Throwable) {
            val roots = rule.onAllNodes(isRoot()).fetchSemanticsNodes()
            File(outDir, "debug.txt").writeText("roots=${roots.size}\n" + roots.joinToString("\n---\n") { r -> dump(r) })
            shot("05-debug")
            throw e
        }
        shot("05-detail-sheet")
        androidx.test.espresso.Espresso.pressBack()
        rule.waitForIdle()

        tab("Stats")
        waitText("Books completed by year")
        shot("06-statistics")

        tab("Reading")
        waitText("Nothing in progress")
        shot("07-currently-reading-empty")

        tab("Settings")
        waitText("Data management")
        shot("08-settings")

        tab("Library")
        rule.onAllNodesWithText("Add").onFirst().performClick()
        waitText("Enter manually")
        shot("09-add-menu")
        rule.onNodeWithText("Enter manually").performClick()
        waitText("Add to library")
        shot("10-manual-entry")
        androidx.test.espresso.Espresso.pressBack()
        rule.waitForIdle()

        runBlocking { container.settings.setDarkMode(DarkMode.DARK) }
        rule.waitForIdle()
        waitText("Saeculum")
        shot("11-library-dark")
    }
}
