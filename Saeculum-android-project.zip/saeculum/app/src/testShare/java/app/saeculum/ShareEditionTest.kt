package app.saeculum

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.ui.platform.ViewRootForTest
import androidx.compose.ui.test.hasSetTextAction
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.isRoot
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

/** The shareable edition: no bundled reading history, empty library, adding a book works. */
@RunWith(AndroidJUnit4::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [34], qualifiers = "w400dp-h860dp-xxhdpi")
class ShareEditionTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()
    private val container get() = (rule.activity.application as SaeculumApp).container
    private val outDir = File(System.getProperty("user.dir"), "build/screenshots-share").apply { mkdirs() }

    private fun shot(name: String) {
        rule.waitForIdle()
        val v = (rule.onAllNodes(isRoot()).fetchSemanticsNodes().first().root as ViewRootForTest).view.rootView
        val bmp = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        v.draw(Canvas(bmp))
        File(outDir, "$name.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    private fun waitText(t: String) = rule.waitUntil(20_000) {
        rule.onAllNodes(hasText(t, substring = true)).fetchSemanticsNodes().isNotEmpty()
    }

    @Test fun startsEmptyWithoutPersonalDataAndCanAddABook() {
        assertFalse(BuildConfig.INCLUDE_READING_HISTORY)
        val seedFiles = rule.activity.assets.list("seed").orEmpty()
        assertTrue("reading list must not be packaged", seedFiles.isEmpty())

        waitText("Your shelf is waiting")
        assertEquals(0, runBlocking { container.books.liveBooks().size })
        assertTrue(rule.onAllNodes(hasText("Your reading history is here")).fetchSemanticsNodes().isEmpty())
        shot("01-empty-library")

        rule.onAllNodesWithText("Add").onFirst().performClick()
        waitText("Enter manually")
        rule.onNodeWithText("Enter manually").performClick()
        waitText("Add to library")
        val fields = rule.onAllNodes(hasSetTextAction())
        fields[0].performTextInput("The Hobbit")
        fields[1].performTextInput("J. R. R. Tolkien")
        rule.onNodeWithText("Save").performClick()

        rule.waitUntil(20_000) { runBlocking { container.books.liveBooks().size } == 1 }
        val b = runBlocking { container.books.liveBooks().single() }
        assertEquals("The Hobbit", b.title)
        assertEquals(listOf("J. R. R. Tolkien"), b.authors)
        waitText("1 book on your shelves")
        shot("02-first-book-added")
    }
}
