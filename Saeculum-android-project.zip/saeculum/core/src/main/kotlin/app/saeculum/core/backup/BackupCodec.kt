package app.saeculum.core.backup

import app.saeculum.core.json.Json
import app.saeculum.core.json.bool
import app.saeculum.core.json.int
import app.saeculum.core.json.long
import app.saeculum.core.json.obj
import app.saeculum.core.json.objects
import app.saeculum.core.json.str
import app.saeculum.core.json.strings
import app.saeculum.core.model.Book
import app.saeculum.core.model.ReadingStatus
import app.saeculum.core.text.Dates

/** A book as stored in a backup, plus the archive path of its cover file (if included). */
data class BackupBook(val book: Book, val coverFile: String?)

data class BackupData(
    val formatVersion: Int,
    val exportedAt: Long,
    val books: List<BackupBook>,
    val settings: Map<String, String>,
    /** Entries that could not be read; the rest of the backup still restores. */
    val skipped: List<String>,
)

/**
 * Full-fidelity JSON backup. The archive (written by the app) is a ZIP holding `backup.json`
 * and `covers/<uuid>.<ext>` files. Every field of [Book] is preserved.
 */
object BackupCodec {
    const val FORMAT = "saeculum-backup"
    const val VERSION = 1
    const val JSON_ENTRY = "backup.json"

    fun encode(books: List<Pair<Book, String?>>, settings: Map<String, String>, exportedAt: Long): String {
        val root = linkedMapOf<String, Any?>(
            "format" to FORMAT,
            "version" to VERSION,
            "app" to "Saeculum",
            "exportedAt" to exportedAt,
            "bookCount" to books.size,
            "settings" to settings.toSortedMap(),
            "books" to books.map { (b, cover) -> encodeBook(b, cover) },
        )
        return Json.write(root)
    }

    private fun encodeBook(b: Book, coverFile: String?): Map<String, Any?> = linkedMapOf(
        "uuid" to b.uuid,
        "title" to b.title,
        "authors" to b.authors,
        "isbn10" to b.isbn10,
        "isbn13" to b.isbn13,
        "coverUrl" to b.coverUrl,
        "coverFile" to coverFile,
        "coverIsCustom" to b.coverIsCustom,
        "publicationYear" to b.publicationYear,
        "publisher" to b.publisher,
        "status" to b.status.name,
        "rating" to b.rating,
        "notes" to b.notes,
        "dateAdded" to b.dateAdded,
        "completedDate" to b.completedDate?.toString(),
        "completedYear" to b.completedYear,
        "startedDate" to b.startedDate?.toString(),
        "currentPage" to b.currentPage,
        "totalPages" to b.totalPages,
        "progressPercent" to b.progressPercent,
        "genre" to b.genre,
        "tags" to b.tags,
        "source" to b.source,
        "sourceText" to b.sourceText,
        "needsReview" to b.needsReview,
        "reviewReason" to b.reviewReason,
        "importKey" to b.importKey,
        "lastModified" to b.lastModified,
        "deletedAt" to b.deletedAt,
    )

    class InvalidBackupException(message: String) : Exception(message)

    fun decode(json: String): BackupData {
        val root = try {
            Json.parse(json)
        } catch (e: Json.ParseException) {
            throw InvalidBackupException("The backup file is damaged (${e.message}).")
        }
        @Suppress("UNCHECKED_CAST")
        val map = root as? Map<String, Any?> ?: throw InvalidBackupException("Not a Saeculum backup.")
        if (map.str("format") != FORMAT) throw InvalidBackupException("Not a Saeculum backup.")
        val version = map.int("version") ?: throw InvalidBackupException("Backup version missing.")
        if (version > VERSION) throw InvalidBackupException("This backup was made by a newer version of Saeculum.")

        val skipped = mutableListOf<String>()
        val books = map.objects("books").mapIndexedNotNull { i, m ->
            try {
                decodeBook(m)
            } catch (e: Exception) {
                skipped += "Book #${i + 1} (${m.str("title") ?: "untitled"}): ${e.message}"
                null
            }
        }
        val settings = map.obj("settings")?.mapNotNull { (k, v) -> (v as? String)?.let { k to it } }?.toMap() ?: emptyMap()
        return BackupData(version, map.long("exportedAt") ?: 0L, books, settings, skipped)
    }

    private fun decodeBook(m: Map<String, Any?>): BackupBook {
        val uuid = m.str("uuid")?.takeIf { it.isNotBlank() } ?: throw IllegalArgumentException("missing id")
        val title = m.str("title")?.takeIf { it.isNotBlank() } ?: throw IllegalArgumentException("missing title")
        val status = ReadingStatus.parse(m.str("status")) ?: throw IllegalArgumentException("unknown status")
        val rating = m.int("rating")?.takeIf { it in 1..5 }
        val book = Book(
            uuid = uuid,
            title = title,
            authors = m.strings("authors"),
            isbn10 = m.str("isbn10"),
            isbn13 = m.str("isbn13"),
            coverUrl = m.str("coverUrl"),
            coverIsCustom = m.bool("coverIsCustom") ?: false,
            publicationYear = m.int("publicationYear"),
            publisher = m.str("publisher"),
            status = status,
            rating = rating,
            notes = m.str("notes") ?: "",
            dateAdded = m.long("dateAdded") ?: 0L,
            completedDate = Dates.parseIsoOrNull(m.str("completedDate")),
            completedYear = m.int("completedYear"),
            startedDate = Dates.parseIsoOrNull(m.str("startedDate")),
            currentPage = m.int("currentPage"),
            totalPages = m.int("totalPages"),
            progressPercent = m.int("progressPercent"),
            genre = m.str("genre"),
            tags = m.strings("tags"),
            source = m.str("source"),
            sourceText = m.str("sourceText"),
            needsReview = m.bool("needsReview") ?: false,
            reviewReason = m.str("reviewReason"),
            importKey = m.str("importKey"),
            lastModified = m.long("lastModified") ?: 0L,
            deletedAt = m.long("deletedAt"),
        )
        return BackupBook(book, m.str("coverFile"))
    }
}
