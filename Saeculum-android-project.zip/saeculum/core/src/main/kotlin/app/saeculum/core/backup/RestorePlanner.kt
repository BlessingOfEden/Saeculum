package app.saeculum.core.backup

import app.saeculum.core.importer.BookIdentity
import app.saeculum.core.importer.DuplicateDetector
import app.saeculum.core.model.Book

enum class RestoreMode { MERGE, REPLACE }

data class RestorePlan(
    /** Books not in the library: restored in both modes. */
    val newBooks: List<BackupBook>,
    /** Same record (same internal id) already in the library: skipped when merging. */
    val alreadyPresent: List<BackupBook>,
    /** Different record that looks like a library book (title/author/ISBN): skipped when merging. */
    val likelyDuplicates: List<Pair<BackupBook, Book>>,
    val total: Int,
) {
    fun toRestore(mode: RestoreMode): List<BackupBook> = when (mode) {
        RestoreMode.MERGE -> newBooks
        RestoreMode.REPLACE -> newBooks + alreadyPresent + likelyDuplicates.map { it.first }
    }
}

object RestorePlanner {
    fun plan(backup: BackupData, existing: List<Book>): RestorePlan {
        val live = existing.filter { it.deletedAt == null }
        val byUuid = existing.associateBy { it.uuid }
        val newBooks = mutableListOf<BackupBook>()
        val present = mutableListOf<BackupBook>()
        val dups = mutableListOf<Pair<BackupBook, Book>>()
        backup.books.forEach { bb ->
            if (byUuid.containsKey(bb.book.uuid)) {
                present += bb
                return@forEach
            }
            val m = DuplicateDetector.find(BookIdentity.of(bb.book), live) { BookIdentity.of(it) }
            if (m != null) dups += bb to m.target else newBooks += bb
        }
        return RestorePlan(newBooks, present, dups, backup.books.size)
    }
}
