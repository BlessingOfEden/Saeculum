package app.saeculum.core.csv

/** One parsed CSV record. [lineNumber] is 1-based and refers to the record's first physical line. */
data class CsvRow(val fields: List<String>, val lineNumber: Int, val malformed: Boolean = false) {
    val isBlank: Boolean get() = fields.all { it.isBlank() }
}

/**
 * RFC 4180 CSV reader/writer.
 *
 * Reader: handles a UTF-8 BOM, CRLF/LF/CR line endings, quoted fields containing delimiters,
 * doubled quotes and embedded newlines. It is lenient: a record whose opening quote is never
 * closed is re-read as a plain line and flagged [CsvRow.malformed] so later rows still import.
 */
object Csv {

    fun detectDelimiter(text: String): Char {
        val firstLine = stripBom(text).lineSequence().firstOrNull { it.isNotBlank() } ?: return ','
        val candidates = listOf(',', ';', '\t')
        return candidates.maxByOrNull { d -> countOutsideQuotes(firstLine, d) }
            ?.takeIf { countOutsideQuotes(firstLine, it) > 0 } ?: ','
    }

    private fun countOutsideQuotes(line: String, d: Char): Int {
        var inQ = false
        var n = 0
        for (c in line) {
            if (c == '"') inQ = !inQ else if (c == d && !inQ) n++
        }
        return n
    }

    private fun stripBom(s: String) = if (s.startsWith('﻿')) s.substring(1) else s

    fun parse(input: String, delimiter: Char = detectDelimiter(input)): List<CsvRow> {
        val text = stripBom(input)
        val rows = mutableListOf<CsvRow>()
        var pos = 0
        var line = 1
        val n = text.length
        while (pos < n) {
            val startPos = pos
            val startLine = line
            val fields = mutableListOf<String>()
            val field = StringBuilder()
            var inQuotes = false
            var fieldStartedQuoted = false
            var atFieldStart = true
            var recordDone = false
            while (pos < n && !recordDone) {
                val c = text[pos]
                if (inQuotes) {
                    if (c == '"') {
                        if (pos + 1 < n && text[pos + 1] == '"') {
                            field.append('"'); pos += 2
                        } else {
                            inQuotes = false; pos++
                        }
                    } else {
                        if (c == '\n') line++
                        if (c == '\r') {
                            line++
                            if (pos + 1 < n && text[pos + 1] == '\n') { field.append('\n'); pos += 2; continue }
                            field.append('\n'); pos++; continue
                        }
                        field.append(c); pos++
                    }
                } else {
                    when {
                        c == '"' && atFieldStart -> {
                            inQuotes = true; fieldStartedQuoted = true; atFieldStart = false; pos++
                        }
                        c == delimiter -> {
                            fields.add(finish(field, fieldStartedQuoted))
                            field.setLength(0); fieldStartedQuoted = false; atFieldStart = true; pos++
                        }
                        c == '\r' || c == '\n' -> {
                            pos++
                            if (c == '\r' && pos < n && text[pos] == '\n') pos++
                            line++
                            recordDone = true
                        }
                        else -> {
                            // Whitespace before an opening quote is tolerated: ` "abc"`.
                            if (atFieldStart && (c == ' ' || c == '\t') && c != delimiter) {
                                val next = text.indexOfFirst(pos) { it != ' ' && it != '\t' }
                                if (next >= 0 && next < n && text[next] == '"') { pos = next; continue }
                            }
                            field.append(c); atFieldStart = false; pos++
                        }
                    }
                }
            }
            if (inQuotes) {
                // Unterminated quote: re-read the first physical line literally and continue after it.
                val lineEnd = text.indexOfAny(charArrayOf('\r', '\n'), startPos).let { if (it < 0) n else it }
                val raw = text.substring(startPos, lineEnd)
                rows.add(CsvRow(raw.split(delimiter).map { it.trim().trim('"') }, startLine, malformed = true))
                pos = lineEnd
                if (pos < n && text[pos] == '\r') pos++
                if (pos < n && text[pos] == '\n') pos++
                line = startLine + 1
                continue
            }
            fields.add(finish(field, fieldStartedQuoted))
            val row = CsvRow(fields, startLine)
            if (!(row.fields.size == 1 && row.fields[0].isEmpty())) rows.add(row)
        }
        return rows
    }

    private inline fun String.indexOfFirst(from: Int, predicate: (Char) -> Boolean): Int {
        for (i in from until length) if (predicate(this[i])) return i
        return -1
    }

    private fun finish(sb: StringBuilder, quoted: Boolean): String =
        if (quoted) sb.toString() else sb.toString().trim()

    // ---------------------------------------------------------------- writer

    fun escape(value: String?): String {
        val v = value ?: ""
        val needs = v.any { it == ',' || it == '"' || it == '\n' || it == '\r' } ||
            v.startsWith(' ') || v.endsWith(' ')
        return if (needs) "\"" + v.replace("\"", "\"\"") + "\"" else v
    }

    fun row(values: List<String?>): String = values.joinToString(",") { escape(it) }

    /** Writes a full document with CRLF record separators (RFC 4180) and a UTF-8 BOM for spreadsheet apps. */
    fun write(header: List<String>, rows: List<List<String?>>, bom: Boolean = true): String {
        val sb = StringBuilder()
        if (bom) sb.append('﻿')
        sb.append(row(header)).append("\r\n")
        rows.forEach { sb.append(row(it)).append("\r\n") }
        return sb.toString()
    }
}
