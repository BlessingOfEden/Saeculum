package app.saeculum.core.export

import app.saeculum.core.csv.Csv
import app.saeculum.core.model.Authors
import app.saeculum.core.model.Book
import app.saeculum.core.model.ReadingStatus
import java.time.Instant
import java.time.ZoneId

object CsvExporter {

    /** Column names match [app.saeculum.core.importer.CsvMapping] synonyms so an export re-imports cleanly. */
    val HEADER = listOf(
        "Book title", "Authors", "Author first name", "Author last name", "Additional authors",
        "ISBN", "ISBN-10", "Reading status", "Rating", "Notes", "Completion date", "Completion year",
        "Publication year", "Publisher", "Date added", "Date started", "Current page", "Total pages",
        "Progress %", "Genre", "Tags",
    )

    fun export(books: List<Book>, zone: ZoneId = ZoneId.systemDefault()): String {
        val rows = books.map { b ->
            val primary = b.authors.firstOrNull().orEmpty()
            listOf(
                b.title,
                b.authors.joinToString("; "),
                splitName(primary).first,
                splitName(primary).second,
                b.authors.drop(1).joinToString("; "),
                b.isbn13 ?: b.isbn10 ?: "",
                b.isbn10 ?: "",
                b.status.label,
                b.rating?.toString() ?: "",
                b.notes,
                b.completedDate?.toString() ?: "",
                b.effectiveCompletionYear?.toString() ?: "",
                b.publicationYear?.toString() ?: "",
                b.publisher ?: "",
                Instant.ofEpochMilli(b.dateAdded).atZone(zone).toLocalDate().toString(),
                b.startedDate?.toString() ?: "",
                b.currentPage?.toString() ?: "",
                b.totalPages?.toString() ?: "",
                b.progressPercent?.toString() ?: "",
                b.genre ?: "",
                b.tags.joinToString("; "),
            )
        }
        return Csv.write(HEADER, rows)
    }

    /** ("John", "Steinbeck"), ("", "Homer"), ("Norman L.", "Geisler") for "Geisler, Norman L.". */
    fun splitName(author: String): Pair<String, String> {
        val a = author.trim()
        if (a.isEmpty()) return "" to ""
        if (a.contains(',')) return a.substringAfter(',').trim() to a.substringBefore(',').trim()
        val i = a.lastIndexOf(' ')
        return if (i < 0) "" to a else a.substring(0, i).trim() to a.substring(i + 1).trim()
    }
}

/**
 * Readable plain-text list. Completed books grouped by completion year (newest first), then a
 * "year unknown" section, then one section per unfinished status. Counts come from the data.
 */
object TxtExporter {

    private val unfinishedOrder = listOf(
        ReadingStatus.READING, ReadingStatus.TO_READ, ReadingStatus.PAUSED,
        ReadingStatus.WANT_TO_BUY, ReadingStatus.ABANDONED,
    )

    fun line(b: Book): String {
        val authors = b.authorLine
        return if (authors.isEmpty()) b.title else "${b.title} by $authors"
    }

    private fun orderWithinYear(list: List<Book>) =
        list.sortedWith(compareBy<Book, java.time.LocalDate?>(nullsLast()) { it.completedDate }.thenBy { it.dateAdded })

    fun export(books: List<Book>, bullet: String = "•"): String {
        val live = books.filter { it.deletedAt == null }
        val sb = StringBuilder()
        val completed = live.filter { it.isCompleted }
        val byYear = completed.filter { it.effectiveCompletionYear != null }
            .groupBy { it.effectiveCompletionYear!! }.toSortedMap(compareByDescending { it })
        fun section(heading: String, list: List<Book>) {
            if (sb.isNotEmpty()) sb.append("\n")
            sb.append(heading).append("\n")
            list.forEach { sb.append(bullet).append(' ').append(line(it)).append("\n") }
            sb.append("Total: ").append(list.size).append("\n")
        }
        byYear.forEach { (year, list) -> section("Novels Read $year:", orderWithinYear(list)) }
        val unknown = completed.filter { it.effectiveCompletionYear == null }
        if (unknown.isNotEmpty()) section("Completed — Year Unknown:", unknown.sortedBy { it.dateAdded })
        unfinishedOrder.forEach { st ->
            val list = live.filter { it.status == st }.sortedBy { it.dateAdded }
            if (list.isNotEmpty()) section("${st.label}:", list)
        }
        if (sb.isEmpty()) sb.append("No books yet.\n")
        return sb.toString()
    }
}
