package app.saeculum.core.importer

/** Target fields a CSV column can be mapped to. */
enum class CsvField(val label: String) {
    IGNORE("Ignore"),
    TITLE("Book title"),
    AUTHOR_FIRST("Author first name"),
    AUTHOR_LAST("Author last name"),
    AUTHOR_FULL("Author full name(s)"),
    ADDITIONAL_AUTHORS("Additional authors"),
    ISBN("ISBN"),
    COMPLETION_YEAR("Completion year"),
    COMPLETION_DATE("Completion date"),
    STATUS("Reading status"),
    RATING("Rating"),
    PUBLICATION_YEAR("Publication year"),
    PUBLISHER("Publisher"),
    NOTES("Notes"),
    GENRE("Genre"),
    TAGS("Tags"),
    CURRENT_PAGE("Current page"),
    TOTAL_PAGES("Total pages"),
    PROGRESS_PERCENT("Progress %"),
    STARTED_DATE("Date started"),
    DATE_ADDED("Date added");
}

object CsvMapping {

    private fun key(h: String) = h.lowercase().filter { it.isLetterOrDigit() }

    private val synonyms: Map<String, CsvField> = buildMap {
        fun add(f: CsvField, vararg names: String) = names.forEach { put(key(it), f) }
        add(CsvField.TITLE, "Book title", "Title", "Book", "Book name")
        add(CsvField.AUTHOR_FIRST, "Author first name", "First name", "Author first", "Author given name", "Given name")
        add(CsvField.AUTHOR_LAST, "Author last name", "Last name", "Author last", "Surname", "Author surname", "Family name")
        add(CsvField.AUTHOR_FULL, "Author", "Authors", "Author name", "Author full name", "Author(s)", "Writer", "By")
        add(CsvField.ADDITIONAL_AUTHORS, "Additional authors", "Other authors", "Co-authors", "Coauthors", "Additional author")
        add(CsvField.ISBN, "ISBN", "ISBN13", "ISBN-13", "ISBN10", "ISBN-10", "ISBN 13", "ISBN 10")
        add(CsvField.COMPLETION_YEAR, "Completion year", "Year read", "Year completed", "Year finished", "Read year", "Finished year")
        add(CsvField.COMPLETION_DATE, "Completion date", "Date read", "Date completed", "Date finished", "Finished on", "Finish date", "Read date", "Finished date")
        add(CsvField.STATUS, "Reading status", "Status", "Exclusive shelf", "Shelf", "Read status")
        add(CsvField.RATING, "Rating", "My rating", "Stars", "Personal rating", "Your rating")
        add(CsvField.PUBLICATION_YEAR, "Publication year", "Year published", "Original publication year", "Pub year", "Published", "Year of publication")
        add(CsvField.PUBLISHER, "Publisher")
        add(CsvField.NOTES, "Notes", "Note", "Private notes", "My review", "Review", "Comments")
        add(CsvField.GENRE, "Genre", "Genres", "Category", "Categories")
        add(CsvField.TAGS, "Tags", "Bookshelves", "Labels")
        add(CsvField.CURRENT_PAGE, "Current page", "Page", "Pages read", "Current position")
        add(CsvField.TOTAL_PAGES, "Total pages", "Pages", "Number of pages", "Page count", "Length")
        add(CsvField.PROGRESS_PERCENT, "Progress", "Progress percent", "Progress %", "Percent", "Percent read")
        add(CsvField.STARTED_DATE, "Date started", "Start date", "Started", "Started on")
        add(CsvField.DATE_ADDED, "Date added", "Added", "Added on")
    }

    fun fieldForHeader(header: String): CsvField = synonyms[key(header)] ?: CsvField.IGNORE

    /** True when the first row looks like a header (at least one column names a title or author field). */
    fun looksLikeHeader(firstRow: List<String>): Boolean {
        val fields = firstRow.map { fieldForHeader(it) }
        return fields.any {
            it == CsvField.TITLE || it == CsvField.AUTHOR_FULL || it == CsvField.AUTHOR_FIRST || it == CsvField.AUTHOR_LAST
        }
    }

    /**
     * Auto-detects a column mapping. Without a header row, assumes the documented simple format:
     * title, author first name, author last name.
     */
    fun autoMap(firstRow: List<String>, columnCount: Int): Pair<Boolean, List<CsvField>> {
        if (looksLikeHeader(firstRow)) {
            val used = mutableSetOf<CsvField>()
            val mapping = (0 until columnCount).map { i ->
                val f = firstRow.getOrNull(i)?.let { fieldForHeader(it) } ?: CsvField.IGNORE
                // A second column with the same meaning is kept only for ISBN (ISBN + ISBN13 exports).
                if (f != CsvField.IGNORE && f != CsvField.ISBN && !used.add(f)) CsvField.IGNORE else f
            }
            return true to mapping
        }
        val defaults = listOf(CsvField.TITLE, CsvField.AUTHOR_FIRST, CsvField.AUTHOR_LAST)
        return false to (0 until columnCount).map { defaults.getOrElse(it) { CsvField.IGNORE } }
    }

    /** Validation messages for a mapping (empty = usable). */
    fun problems(mapping: List<CsvField>): List<String> {
        val out = mutableListOf<String>()
        if (CsvField.TITLE !in mapping) out += "Choose which column holds the book title."
        val hasAuthor = CsvField.AUTHOR_FULL in mapping || CsvField.AUTHOR_FIRST in mapping || CsvField.AUTHOR_LAST in mapping
        if (!hasAuthor) out += "Choose which column(s) hold the author."
        return out
    }
}
