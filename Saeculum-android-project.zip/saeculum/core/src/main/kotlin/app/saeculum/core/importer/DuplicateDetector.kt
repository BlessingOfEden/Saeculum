package app.saeculum.core.importer

import app.saeculum.core.isbn.Isbn
import app.saeculum.core.model.Book
import app.saeculum.core.text.TextNormalizer

enum class DuplicateReason(val description: String) {
    SAME_ISBN("Same ISBN"),
    SAME_TITLE_AND_AUTHOR("Same title and author"),
    SAME_TITLE_DIFFERENT_ISBN("Same title and author, different ISBN — possibly another edition"),
    SAME_TITLE_UNKNOWN_AUTHOR("Same title; author missing on one side"),
}

/** Minimal identity of a book for duplicate checks (works for stored books and unsaved candidates). */
data class BookIdentity(
    val title: String,
    val authors: List<String>,
    val isbn10: String? = null,
    val isbn13: String? = null,
) {
    val isbnKey: String? get() = Isbn.toIsbn13(isbn13) ?: Isbn.toIsbn13(isbn10)

    companion object {
        fun of(book: Book) = BookIdentity(book.title, book.authors, book.isbn10, book.isbn13)
    }
}

data class DuplicateMatch<T>(val target: T, val reason: DuplicateReason) {
    /** Different editions are allowed: these matches default to "import anyway" in the UI. */
    val likelyDifferentEdition: Boolean get() = reason == DuplicateReason.SAME_TITLE_DIFFERENT_ISBN
}

/**
 * Duplicate detection. ISBN is used when both sides have one; otherwise normalised title + author surname.
 * Detection only ever *suggests*; callers must let the user decide. Nothing is merged or deleted.
 */
object DuplicateDetector {

    fun reasonFor(a: BookIdentity, b: BookIdentity): DuplicateReason? {
        val ia = a.isbnKey
        val ib = b.isbnKey
        if (ia != null && ia == ib) return DuplicateReason.SAME_ISBN

        val ta = TextNormalizer.title(a.title)
        val tb = TextNormalizer.title(b.title)
        if (ta.isEmpty() || tb.isEmpty()) return null
        val titlesMatch = ta == tb ||
            (TextNormalizer.shortTitle(a.title).let { it.isNotEmpty() && it == TextNormalizer.shortTitle(b.title) } &&
                minOf(ta.length, tb.length) >= 4)
        if (!titlesMatch) return null

        val aHas = a.authors.any { it.isNotBlank() }
        val bHas = b.authors.any { it.isNotBlank() }
        if (aHas && bHas) {
            if (!TextNormalizer.authorsOverlap(a.authors, b.authors)) return null
            return if (ia != null && ib != null && ia != ib) DuplicateReason.SAME_TITLE_DIFFERENT_ISBN
            else DuplicateReason.SAME_TITLE_AND_AUTHOR
        }
        // Title-only match is reported only for exact normalised titles.
        return if (ta == tb) DuplicateReason.SAME_TITLE_UNKNOWN_AUTHOR else null
    }

    /** First likely duplicate of [candidate] in [pool], strongest reason first. */
    fun <T> find(candidate: BookIdentity, pool: List<T>, identity: (T) -> BookIdentity): DuplicateMatch<T>? {
        var best: DuplicateMatch<T>? = null
        for (item in pool) {
            val r = reasonFor(candidate, identity(item)) ?: continue
            if (best == null || r.ordinal < best.reason.ordinal) best = DuplicateMatch(item, r)
            if (r == DuplicateReason.SAME_ISBN) break
        }
        return best
    }

    /** Pairs of indices within one list that look like duplicates of each other. */
    fun pairsWithin(items: List<BookIdentity>): List<Triple<Int, Int, DuplicateReason>> {
        val out = mutableListOf<Triple<Int, Int, DuplicateReason>>()
        for (i in items.indices) for (j in i + 1 until items.size) {
            reasonFor(items[i], items[j])?.let { out += Triple(i, j, it) }
        }
        return out
    }
}
