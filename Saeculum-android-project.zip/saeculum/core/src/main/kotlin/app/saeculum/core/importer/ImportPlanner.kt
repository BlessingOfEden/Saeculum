package app.saeculum.core.importer

import app.saeculum.core.csv.CsvRow
import app.saeculum.core.isbn.Isbn
import app.saeculum.core.model.Book
import app.saeculum.core.model.BookDraft
import app.saeculum.core.model.ReadingStatus
import app.saeculum.core.text.Dates
import app.saeculum.core.text.ParsedDate

enum class IssueLevel { WARNING, ERROR }

data class ImportIssue(val level: IssueLevel, val message: String)

enum class DuplicateAction { SKIP, IMPORT_ANYWAY }

data class ImportCandidate(
    val index: Int,
    val lineNumber: Int,
    val raw: List<String>,
    val draft: BookDraft,
    val issues: List<ImportIssue>,
    /** Status came from a completion year/date rather than an explicit status column. */
    val statusInferred: Boolean = false,
    val duplicateOfExisting: DuplicateMatch<Book>? = null,
    /** Index of an earlier row in the same file that this row duplicates. */
    val duplicateOfRow: Int? = null,
    val duplicateOfRowReason: DuplicateReason? = null,
) {
    val hasError: Boolean get() = issues.any { it.level == IssueLevel.ERROR }
    val hasWarning: Boolean get() = issues.any { it.level == IssueLevel.WARNING }
    val isDuplicate: Boolean get() = duplicateOfExisting != null || duplicateOfRow != null
    val detectedOptionalFields: List<String>
        get() = buildList {
            if (draft.isbn13 != null || draft.isbn10 != null) add("ISBN")
            if (draft.status != null) add("Status")
            if (draft.completedDate != null) add("Completion date") else if (draft.completedYear != null) add("Completion year")
            if (draft.rating != null) add("Rating")
            if (draft.publicationYear != null) add("Published")
            if (draft.publisher != null) add("Publisher")
            if (draft.notes.isNotBlank()) add("Notes")
            if (draft.genre != null) add("Genre")
            if (draft.tags.isNotEmpty()) add("Tags")
            if (draft.currentPage != null || draft.totalPages != null || draft.progressPercent != null) add("Progress")
        }
}

data class ImportPlan(
    val hasHeader: Boolean,
    val header: List<String>,
    val mapping: List<CsvField>,
    val candidates: List<ImportCandidate>,
) {
    val detectedCount: Int get() = candidates.size
    val errorCount: Int get() = candidates.count { it.hasError }
    val duplicateCount: Int get() = candidates.count { it.isDuplicate && !it.hasError }
    val warningCount: Int get() = candidates.count { it.hasWarning && !it.hasError }
    val needsDefaultStatus: Boolean get() = candidates.any { !it.hasError && it.draft.status == null }
}

/** Per-row choices made in the preview. */
data class RowDecision(val include: Boolean = true, val duplicateAction: DuplicateAction = DuplicateAction.SKIP)

data class PlannedInsert(val candidate: ImportCandidate, val book: Book)

data class ImportSelection(
    val inserts: List<PlannedInsert>,
    val skippedDuplicates: List<ImportCandidate>,
    val excluded: List<ImportCandidate>,
    val rejected: List<ImportCandidate>,
)

object ImportPlanner {

    fun plan(
        rows: List<CsvRow>,
        hasHeader: Boolean,
        mapping: List<CsvField>,
        existing: List<Book>,
    ): ImportPlan {
        val header = if (hasHeader) rows.firstOrNull()?.fields ?: emptyList() else emptyList()
        val dataRows = (if (hasHeader) rows.drop(1) else rows).filterNot { it.isBlank }
        val built = dataRows.mapIndexed { i, row -> buildCandidate(i, row, mapping) }

        val result = mutableListOf<ImportCandidate>()
        for (c in built) {
            if (c.hasError) { result += c; continue }
            val id = BookIdentity(c.draft.title, c.draft.authors, c.draft.isbn10, c.draft.isbn13)
            val dupExisting = DuplicateDetector.find(id, existing) { BookIdentity.of(it) }
            val earlier = result.filter { !it.hasError }
            val dupRow = DuplicateDetector.find(id, earlier) {
                BookIdentity(it.draft.title, it.draft.authors, it.draft.isbn10, it.draft.isbn13)
            }
            result += c.copy(
                duplicateOfExisting = dupExisting,
                duplicateOfRow = dupRow?.target?.index,
                duplicateOfRowReason = dupRow?.reason,
            )
        }
        return ImportPlan(hasHeader, header, mapping, result)
    }

    /** Default decision: skip duplicates, except likely different editions; exclude rows with errors. */
    fun defaultDecision(c: ImportCandidate): RowDecision {
        if (c.hasError) return RowDecision(include = false)
        val edition = c.duplicateOfExisting?.likelyDifferentEdition == true
        return RowDecision(
            include = true,
            duplicateAction = if (c.isDuplicate && !edition) DuplicateAction.SKIP else DuplicateAction.IMPORT_ANYWAY,
        )
    }

    fun select(
        plan: ImportPlan,
        decisions: Map<Int, RowDecision>,
        defaultStatus: ReadingStatus,
        fileKey: String,
        now: Long,
        newUuid: () -> String,
    ): ImportSelection {
        val inserts = mutableListOf<PlannedInsert>()
        val skipped = mutableListOf<ImportCandidate>()
        val excluded = mutableListOf<ImportCandidate>()
        val rejected = mutableListOf<ImportCandidate>()
        for (c in plan.candidates) {
            val d = decisions[c.index] ?: defaultDecision(c)
            when {
                c.hasError -> rejected += c
                !d.include -> excluded += c
                c.isDuplicate && d.duplicateAction == DuplicateAction.SKIP -> skipped += c
                else -> {
                    val needsReview = c.hasWarning
                    val book = c.draft.toBook(
                        uuid = newUuid(),
                        now = now + c.index, // keeps file order stable for "date added" sorting
                        defaultStatus = defaultStatus,
                        source = "csv",
                        sourceText = c.raw.joinToString(", "),
                        importKey = "csv:$fileKey:${c.lineNumber}",
                        needsReview = needsReview,
                        reviewReason = if (needsReview) c.issues.joinToString("; ") { it.message } else null,
                    )
                    inserts += PlannedInsert(c, book)
                }
            }
        }
        return ImportSelection(inserts, skipped, excluded, rejected)
    }

    // ------------------------------------------------------------------ row parsing

    private fun splitList(s: String): List<String> {
        val parts = if (s.contains(';')) s.split(';') else s.split(',')
        return parts.map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun buildCandidate(index: Int, row: CsvRow, mapping: List<CsvField>): ImportCandidate {
        val issues = mutableListOf<ImportIssue>()
        fun warn(m: String) { issues += ImportIssue(IssueLevel.WARNING, m) }
        fun error(m: String) { issues += ImportIssue(IssueLevel.ERROR, m) }

        if (row.malformed) warn("Row has an unmatched quotation mark; values were read literally.")
        if (row.fields.size > mapping.size && row.fields.drop(mapping.size).any { it.isNotBlank() }) {
            warn("Row has more columns than the header; extra values were ignored.")
        }

        fun values(f: CsvField): List<String> =
            mapping.indices.filter { mapping[it] == f }.mapNotNull { row.fields.getOrNull(it)?.trim() }.filter { it.isNotEmpty() }
        fun value(f: CsvField): String? = values(f).firstOrNull()

        val title = value(CsvField.TITLE).orEmpty()

        // Authors: a full-name column wins; otherwise first + last. Additional authors are appended.
        val authors = mutableListOf<String>()
        val full = value(CsvField.AUTHOR_FULL)
        if (full != null) {
            authors += full.split(';').map { it.trim() }.filter { it.isNotEmpty() }
        } else {
            val first = value(CsvField.AUTHOR_FIRST).orEmpty()
            val last = value(CsvField.AUTHOR_LAST).orEmpty()
            val name = listOf(first, last).filter { it.isNotEmpty() }.joinToString(" ")
            if (name.isNotEmpty()) authors += name
        }
        value(CsvField.ADDITIONAL_AUTHORS)?.let { authors += splitList(it) }
        val distinctAuthors = authors.distinctBy { it.lowercase() }

        if (title.isEmpty()) error("Missing book title.")
        if (distinctAuthors.isEmpty()) error("Missing author.")

        // ISBN: first valid value among mapped ISBN columns.
        var isbn10: String? = null
        var isbn13: String? = null
        val isbnValues = values(CsvField.ISBN).map { Isbn.clean(it) }.filter { it.isNotEmpty() }
        val valid = isbnValues.firstOrNull { Isbn.isValid(it) }
        if (valid != null) {
            val pair = Isbn.normalizePair(valid)!!
            isbn10 = pair.first; isbn13 = pair.second
        } else if (isbnValues.isNotEmpty()) {
            warn("ISBN \"${isbnValues.first()}\" is not valid and was left out.")
        }

        // Status
        val statusRaw = value(CsvField.STATUS)
        var status = ReadingStatus.parse(statusRaw)
        if (statusRaw != null && status == null) warn("Unknown reading status \"$statusRaw\"; the default status will be used.")

        // Completion
        var completedDate: java.time.LocalDate? = null
        var completedYear: Int? = null
        value(CsvField.COMPLETION_DATE)?.let { raw ->
            when (val p = Dates.parse(raw)) {
                is ParsedDate.Full -> completedDate = p.date
                is ParsedDate.YearOnly -> {
                    completedYear = p.year
                    if (p.ambiguous) warn("Completion date \"$raw\" is ambiguous; only the year ${p.year} was kept.")
                }
                is ParsedDate.Invalid -> warn("Completion date \"$raw\" wasn't understood and was left out.")
                null -> Unit
            }
        }
        value(CsvField.COMPLETION_YEAR)?.let { raw ->
            val y = Dates.parseYear(raw)
            if (y == null) warn("Completion year \"$raw\" wasn't understood and was left out.")
            else if (completedDate != null && completedDate!!.year != y) {
                warn("Completion year $y differs from completion date $completedDate; the date was kept.")
            } else if (completedYear == null) completedYear = y
        }
        var statusInferred = false
        val hasCompletion = completedDate != null || completedYear != null
        if (status == null && hasCompletion) {
            status = ReadingStatus.COMPLETED
            statusInferred = true
        } else if (status != null && status != ReadingStatus.COMPLETED && hasCompletion) {
            warn("Completion date ignored because the status is \"${status.label}\".")
            completedDate = null; completedYear = null
        }

        // Rating (0 = unrated in common exports)
        var rating: Int? = null
        value(CsvField.RATING)?.let { raw ->
            val r = parseRating(raw)
            when {
                r == 0 -> Unit
                r != null && r in 1..5 -> rating = r
                else -> warn("Rating \"$raw\" isn't a whole number from 1 to 5 and was left out.")
            }
        }

        val pubYear = value(CsvField.PUBLICATION_YEAR)?.let { raw ->
            Dates.parseYear(raw) ?: (Dates.parse(raw) as? ParsedDate.Full)?.date?.year
                ?: run { warn("Publication year \"$raw\" wasn't understood."); null }
        }

        fun posInt(f: CsvField, label: String): Int? = value(f)?.let { raw ->
            raw.replace(",", "").trim().toDoubleOrNull()?.toInt()?.takeIf { it >= 0 }
                ?: run { warn("$label \"$raw\" isn't a number."); null }
        }
        val currentPage = posInt(CsvField.CURRENT_PAGE, "Current page")
        var totalPages = posInt(CsvField.TOTAL_PAGES, "Total pages")
        if (totalPages == 0) totalPages = null
        if (currentPage != null && totalPages != null && currentPage > totalPages) {
            warn("Current page $currentPage is past total pages $totalPages.")
        }
        val percent = value(CsvField.PROGRESS_PERCENT)?.let { raw ->
            raw.trim().removeSuffix("%").trim().toDoubleOrNull()?.toInt()?.takeIf { it in 0..100 }
                ?: run { warn("Progress \"$raw\" isn't a percentage from 0 to 100."); null }
        }

        val started = value(CsvField.STARTED_DATE)?.let { (Dates.parse(it) as? ParsedDate.Full)?.date }
        val added = value(CsvField.DATE_ADDED)?.let { (Dates.parse(it) as? ParsedDate.Full)?.date }

        val notes = values(CsvField.NOTES).joinToString("\n\n")
        val genre = value(CsvField.GENRE)
        val tags = values(CsvField.TAGS).flatMap { splitList(it) }

        val draft = BookDraft(
            title = title,
            authors = distinctAuthors,
            isbn10 = isbn10,
            isbn13 = isbn13,
            publicationYear = pubYear,
            publisher = value(CsvField.PUBLISHER),
            status = status,
            rating = rating,
            notes = notes,
            completedDate = completedDate,
            completedYear = completedDate?.year ?: completedYear,
            startedDate = started,
            currentPage = if (currentPage != null && totalPages != null && currentPage > totalPages) null else currentPage,
            totalPages = totalPages,
            progressPercent = percent,
            genre = genre,
            tags = tags,
            dateAdded = added,
        )
        return ImportCandidate(index, row.lineNumber, row.fields, draft, issues, statusInferred)
    }

    /** "4", "4.0", "4/5", "★★★★☆" -> 4; "0" -> 0; anything else -> null. */
    fun parseRating(raw: String): Int? {
        val s = raw.trim()
        if (s.isEmpty()) return null
        if (s.all { it == '★' || it == '☆' || it == '*' }) return s.count { it == '★' || it == '*' }
        val main = s.substringBefore('/').trim()
        val d = main.toDoubleOrNull() ?: return null
        if (d != Math.floor(d)) return null
        val denom = s.substringAfter('/', "").trim().toDoubleOrNull()
        if (denom != null && denom != 5.0) return null
        return d.toInt()
    }
}
