package app.saeculum.core.isbn

/** ISBN-10 / ISBN-13 validation and conversion. */
object Isbn {

    /** Strips spaces, hyphens and spreadsheet artefacts like ="0441013597". Keeps digits and X. */
    fun clean(raw: String?): String {
        if (raw == null) return ""
        var s = raw.trim()
        if (s.startsWith("=")) s = s.drop(1)
        s = s.trim('"', '\'', ' ')
        return s.filter { it.isDigit() || it == 'X' || it == 'x' }.uppercase()
    }

    fun isValidIsbn10(raw: String?): Boolean {
        val s = clean(raw)
        if (s.length != 10) return false
        if (!s.substring(0, 9).all { it.isDigit() }) return false
        val last = s[9]
        if (!(last.isDigit() || last == 'X')) return false
        var sum = 0
        for (i in 0 until 9) sum += (s[i] - '0') * (10 - i)
        sum += if (last == 'X') 10 else (last - '0')
        return sum % 11 == 0
    }

    fun isValidIsbn13(raw: String?): Boolean {
        val s = clean(raw)
        if (s.length != 13 || !s.all { it.isDigit() }) return false
        if (!(s.startsWith("978") || s.startsWith("979"))) return false
        return checkDigit13(s.substring(0, 12)) == s[12] - '0'
    }

    fun isValid(raw: String?): Boolean = isValidIsbn10(raw) || isValidIsbn13(raw)

    private fun checkDigit13(first12: String): Int {
        var sum = 0
        for (i in 0 until 12) sum += (first12[i] - '0') * if (i % 2 == 0) 1 else 3
        return (10 - sum % 10) % 10
    }

    fun toIsbn13(raw: String?): String? {
        val s = clean(raw)
        if (isValidIsbn13(s)) return s
        if (!isValidIsbn10(s)) return null
        val base = "978" + s.substring(0, 9)
        return base + checkDigit13(base)
    }

    fun toIsbn10(raw: String?): String? {
        val s = clean(raw)
        if (isValidIsbn10(s)) return s
        if (!isValidIsbn13(s) || !s.startsWith("978")) return null
        val core = s.substring(3, 12)
        var sum = 0
        for (i in 0 until 9) sum += (core[i] - '0') * (10 - i)
        val check = (11 - sum % 11) % 11
        return core + if (check == 10) "X" else check.toString()
    }

    /** Splits a valid ISBN into the (isbn10, isbn13) pair the data model stores. */
    fun normalizePair(raw: String?): Pair<String?, String?>? {
        val s = clean(raw)
        if (!isValid(s)) return null
        return toIsbn10(s) to toIsbn13(s)
    }

    /**
     * Interprets a scanned barcode payload. Book barcodes are EAN-13 starting 978/979;
     * a 10-character payload may be an ISBN-10. Returns the ISBN-13 or null.
     */
    fun fromBarcode(payload: String?): String? {
        val s = clean(payload)
        return when {
            s.length == 13 && isValidIsbn13(s) -> s
            s.length == 10 && isValidIsbn10(s) -> toIsbn13(s)
            else -> null
        }
    }

    /** Hyphen-free display with the conventional 978-x grouping kept simple. */
    fun display(raw: String?): String = clean(raw)
}
