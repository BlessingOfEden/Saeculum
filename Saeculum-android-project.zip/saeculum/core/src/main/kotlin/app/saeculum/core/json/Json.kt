package app.saeculum.core.json

/**
 * Small, dependency-free JSON reader/writer (RFC 8259). Objects decode to [LinkedHashMap],
 * arrays to [List], numbers to [Long] when integral else [Double].
 */
object Json {

    class ParseException(message: String, val position: Int) : Exception("$message at position $position")

    fun parse(text: String): Any? {
        val p = Parser(text)
        p.skipWs()
        val v = p.value()
        p.skipWs()
        if (!p.atEnd()) throw ParseException("Unexpected trailing content", p.pos)
        return v
    }

    private class Parser(val s: String) {
        var pos = 0
        fun atEnd() = pos >= s.length
        fun skipWs() { while (pos < s.length && s[pos] in " \t\r\n﻿") pos++ }
        fun peek(): Char = if (pos < s.length) s[pos] else throw ParseException("Unexpected end", pos)

        fun value(): Any? {
            skipWs()
            return when (val c = peek()) {
                '{' -> obj()
                '[' -> arr()
                '"' -> str()
                't' -> literal("true", true)
                'f' -> literal("false", false)
                'n' -> literal("null", null)
                else -> if (c == '-' || c.isDigit()) num() else throw ParseException("Unexpected '$c'", pos)
            }
        }

        fun literal(word: String, v: Any?): Any? {
            if (!s.startsWith(word, pos)) throw ParseException("Expected $word", pos)
            pos += word.length
            return v
        }

        fun obj(): Map<String, Any?> {
            val m = LinkedHashMap<String, Any?>()
            pos++ // {
            skipWs()
            if (peek() == '}') { pos++; return m }
            while (true) {
                skipWs()
                if (peek() != '"') throw ParseException("Expected key", pos)
                val k = str()
                skipWs()
                if (peek() != ':') throw ParseException("Expected ':'", pos)
                pos++
                m[k] = value()
                skipWs()
                when (peek()) {
                    ',' -> pos++
                    '}' -> { pos++; return m }
                    else -> throw ParseException("Expected ',' or '}'", pos)
                }
            }
        }

        fun arr(): List<Any?> {
            val l = ArrayList<Any?>()
            pos++
            skipWs()
            if (peek() == ']') { pos++; return l }
            while (true) {
                l += value()
                skipWs()
                when (peek()) {
                    ',' -> pos++
                    ']' -> { pos++; return l }
                    else -> throw ParseException("Expected ',' or ']'", pos)
                }
            }
        }

        fun str(): String {
            pos++ // opening quote
            val sb = StringBuilder()
            while (true) {
                if (pos >= s.length) throw ParseException("Unterminated string", pos)
                val c = s[pos++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> {
                        if (pos >= s.length) throw ParseException("Bad escape", pos)
                        when (val e = s[pos++]) {
                            '"' -> sb.append('"'); '\\' -> sb.append('\\'); '/' -> sb.append('/')
                            'b' -> sb.append('\b'); 'f' -> sb.append('\u000C'); 'n' -> sb.append('\n')
                            'r' -> sb.append('\r'); 't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 4 > s.length) throw ParseException("Bad unicode escape", pos)
                                sb.append(s.substring(pos, pos + 4).toInt(16).toChar()); pos += 4
                            }
                            else -> throw ParseException("Bad escape '\\$e'", pos)
                        }
                    }
                    else -> sb.append(c)
                }
            }
        }

        fun num(): Number {
            val start = pos
            if (peek() == '-') pos++
            while (pos < s.length && (s[pos].isDigit() || s[pos] in ".eE+-")) pos++
            val t = s.substring(start, pos)
            return if (t.any { it == '.' || it == 'e' || it == 'E' }) {
                t.toDoubleOrNull() ?: throw ParseException("Bad number", start)
            } else {
                t.toLongOrNull() ?: t.toDoubleOrNull() ?: throw ParseException("Bad number", start)
            }
        }
    }

    // ------------------------------------------------------------------ writer

    fun write(value: Any?, indent: String = "  "): String = StringBuilder().also { writeTo(it, value, indent, "") }.toString()

    private fun writeTo(sb: StringBuilder, v: Any?, indent: String, cur: String) {
        when (v) {
            null -> sb.append("null")
            is Boolean -> sb.append(v)
            is Int, is Long, is Short, is Byte -> sb.append(v.toString())
            is Double -> if (v.isFinite()) sb.append(v.toString()) else sb.append("null")
            is Float -> if (v.isFinite()) sb.append(v.toString()) else sb.append("null")
            is String -> quote(sb, v)
            is Map<*, *> -> {
                if (v.isEmpty()) { sb.append("{}"); return }
                val next = cur + indent
                sb.append("{\n")
                var first = true
                for ((k, value) in v) {
                    if (!first) sb.append(",\n")
                    first = false
                    sb.append(next); quote(sb, k.toString()); sb.append(": ")
                    writeTo(sb, value, indent, next)
                }
                sb.append('\n').append(cur).append('}')
            }
            is Iterable<*> -> {
                val list = v.toList()
                if (list.isEmpty()) { sb.append("[]"); return }
                val next = cur + indent
                sb.append("[\n")
                list.forEachIndexed { i, item ->
                    if (i > 0) sb.append(",\n")
                    sb.append(next); writeTo(sb, item, indent, next)
                }
                sb.append('\n').append(cur).append(']')
            }
            else -> quote(sb, v.toString())
        }
    }

    private fun quote(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c < ' ' -> sb.append(String.format("\\u%04x", c.code))
                else -> sb.append(c)
            }
        }
        sb.append('"')
    }
}

/** Typed accessors for decoded JSON maps. */
fun Map<String, Any?>.str(key: String): String? = this[key] as? String
fun Map<String, Any?>.int(key: String): Int? = when (val v = this[key]) {
    is Number -> v.toInt()
    is String -> v.trim().toIntOrNull()
    else -> null
}
fun Map<String, Any?>.long(key: String): Long? = when (val v = this[key]) {
    is Number -> v.toLong()
    is String -> v.trim().toLongOrNull()
    else -> null
}
fun Map<String, Any?>.bool(key: String): Boolean? = this[key] as? Boolean
@Suppress("UNCHECKED_CAST")
fun Map<String, Any?>.obj(key: String): Map<String, Any?>? = this[key] as? Map<String, Any?>
fun Map<String, Any?>.list(key: String): List<Any?>? = this[key] as? List<Any?>
fun Map<String, Any?>.strings(key: String): List<String> = list(key)?.mapNotNull { it as? String } ?: emptyList()
@Suppress("UNCHECKED_CAST")
fun Map<String, Any?>.objects(key: String): List<Map<String, Any?>> = list(key)?.mapNotNull { it as? Map<String, Any?> } ?: emptyList()
