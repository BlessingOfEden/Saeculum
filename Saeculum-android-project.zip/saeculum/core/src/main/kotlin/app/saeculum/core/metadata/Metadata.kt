package app.saeculum.core.metadata

import app.saeculum.core.isbn.Isbn
import app.saeculum.core.json.Json
import app.saeculum.core.json.int
import app.saeculum.core.json.list
import app.saeculum.core.json.obj
import app.saeculum.core.json.objects
import app.saeculum.core.json.str
import app.saeculum.core.json.strings
import app.saeculum.core.model.BookDraft
import app.saeculum.core.text.TextNormalizer

/** A book found in a public metadata source. Fields the source doesn't provide stay null. */
data class MetadataResult(
    val source: String,
    val sourceId: String?,
    val title: String,
    val subtitle: String? = null,
    val authors: List<String> = emptyList(),
    val publisher: String? = null,
    val publicationYear: Int? = null,
    /** True when the year is the work's first publication rather than this edition's. */
    val yearIsFirstPublished: Boolean = false,
    val isbn10: String? = null,
    val isbn13: String? = null,
    val pageCount: Int? = null,
    val coverUrl: String? = null,
    val categories: List<String> = emptyList(),
) {
    val displayTitle: String get() = if (subtitle.isNullOrBlank()) title else "$title: $subtitle"

    fun toDraft(): BookDraft = BookDraft(
        title = title,
        authors = authors,
        isbn10 = isbn10,
        isbn13 = isbn13,
        coverUrl = coverUrl,
        publicationYear = publicationYear,
        publisher = publisher,
        totalPages = pageCount,
        genre = categories.firstOrNull(),
    )
}

object MetadataUrls {
    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8")

    private const val OL_FIELDS = "key,title,subtitle,author_name,first_publish_year,publisher,isbn,cover_i,number_of_pages_median,cover_edition_key"

    fun openLibrarySearch(title: String, author: String?, limit: Int = 20): String {
        val sb = StringBuilder("https://openlibrary.org/search.json?")
        sb.append("title=").append(enc(title.trim()))
        if (!author.isNullOrBlank()) sb.append("&author=").append(enc(author.trim()))
        sb.append("&fields=").append(OL_FIELDS).append("&limit=").append(limit)
        return sb.toString()
    }

    fun openLibraryQuery(q: String, limit: Int = 20) =
        "https://openlibrary.org/search.json?q=${enc(q.trim())}&fields=$OL_FIELDS&limit=$limit"

    fun openLibraryIsbn(isbn: String) =
        "https://openlibrary.org/api/books?bibkeys=ISBN:${Isbn.clean(isbn)}&format=json&jscmd=data"

    fun openLibraryCover(coverId: Long, size: Char = 'L') = "https://covers.openlibrary.org/b/id/$coverId-$size.jpg?default=false"

    fun googleBooksSearch(title: String, author: String?, apiKey: String?, limit: Int = 20): String {
        val q = buildString {
            append("intitle:").append(title.trim())
            if (!author.isNullOrBlank()) append("+inauthor:").append(author.trim())
        }
        return "https://www.googleapis.com/books/v1/volumes?q=${enc(q)}&maxResults=$limit&printType=books" + key(apiKey)
    }

    fun googleBooksIsbn(isbn: String, apiKey: String?) =
        "https://www.googleapis.com/books/v1/volumes?q=isbn:${Isbn.clean(isbn)}" + key(apiKey)

    private fun key(apiKey: String?) = if (apiKey.isNullOrBlank()) "" else "&key=${enc(apiKey)}"
}

object OpenLibraryParser {

    @Suppress("UNCHECKED_CAST")
    fun parseSearch(json: String): List<MetadataResult> {
        val root = Json.parse(json) as? Map<String, Any?> ?: return emptyList()
        return root.objects("docs").mapNotNull { d ->
            val title = d.str("title")?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val isbns = d.strings("isbn").map { Isbn.clean(it) }
            val i13 = isbns.firstOrNull { Isbn.isValidIsbn13(it) }
            val i10 = isbns.firstOrNull { Isbn.isValidIsbn10(it) }
            val coverId = (d["cover_i"] as? Number)?.toLong()
            MetadataResult(
                source = "Open Library",
                sourceId = d.str("key"),
                title = title,
                subtitle = d.str("subtitle"),
                authors = d.strings("author_name"),
                publisher = d.strings("publisher").firstOrNull(),
                publicationYear = d.int("first_publish_year"),
                yearIsFirstPublished = d.int("first_publish_year") != null,
                isbn13 = i13 ?: Isbn.toIsbn13(i10),
                isbn10 = i10 ?: i13?.let { Isbn.toIsbn10(it) },
                pageCount = d.int("number_of_pages_median"),
                coverUrl = coverId?.takeIf { it > 0 }?.let { MetadataUrls.openLibraryCover(it) },
            )
        }
    }

    /** Parses the `api/books?jscmd=data` response for an ISBN lookup. */
    @Suppress("UNCHECKED_CAST")
    fun parseIsbn(json: String, isbn: String): MetadataResult? {
        val root = Json.parse(json) as? Map<String, Any?> ?: return null
        val d = (root["ISBN:${Isbn.clean(isbn)}"] ?: root.values.firstOrNull()) as? Map<String, Any?> ?: return null
        val title = d.str("title")?.takeIf { it.isNotBlank() } ?: return null
        val ids = d.obj("identifiers")
        val i13 = ids?.strings("isbn_13")?.firstOrNull { Isbn.isValidIsbn13(it) } ?: Isbn.toIsbn13(isbn)
        val i10 = ids?.strings("isbn_10")?.firstOrNull { Isbn.isValidIsbn10(it) } ?: Isbn.toIsbn10(isbn)
        val cover = d.obj("cover")
        val year = d.str("publish_date")?.let { Regex("(\\d{4})").find(it)?.groupValues?.get(1)?.toInt() }
        return MetadataResult(
            source = "Open Library",
            sourceId = d.str("key"),
            title = title,
            subtitle = d.str("subtitle"),
            authors = d.objects("authors").mapNotNull { it.str("name") },
            publisher = d.objects("publishers").firstNotNullOfOrNull { it.str("name") },
            publicationYear = year,
            isbn13 = i13,
            isbn10 = i10,
            pageCount = d.int("number_of_pages"),
            coverUrl = cover?.str("large") ?: cover?.str("medium"),
            categories = d.objects("subjects").mapNotNull { it.str("name") }.take(3),
        )
    }
}

object GoogleBooksParser {
    @Suppress("UNCHECKED_CAST")
    fun parse(json: String): List<MetadataResult> {
        val root = Json.parse(json) as? Map<String, Any?> ?: return emptyList()
        return root.objects("items").mapNotNull { item ->
            val v = item.obj("volumeInfo") ?: return@mapNotNull null
            val title = v.str("title")?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val ids = v.objects("industryIdentifiers")
            val i13 = ids.firstOrNull { it.str("type") == "ISBN_13" }?.str("identifier")?.takeIf { Isbn.isValidIsbn13(it) }
            val i10 = ids.firstOrNull { it.str("type") == "ISBN_10" }?.str("identifier")?.takeIf { Isbn.isValidIsbn10(it) }
            val images = v.obj("imageLinks")
            val img = (images?.str("thumbnail") ?: images?.str("smallThumbnail"))
                ?.replace("http://", "https://")?.replace("&edge=curl", "")
            MetadataResult(
                source = "Google Books",
                sourceId = item.str("id"),
                title = title,
                subtitle = v.str("subtitle"),
                authors = v.strings("authors"),
                publisher = v.str("publisher"),
                publicationYear = v.str("publishedDate")?.let { Regex("^(\\d{4})").find(it)?.groupValues?.get(1)?.toInt() },
                isbn13 = i13 ?: Isbn.toIsbn13(i10),
                isbn10 = i10 ?: i13?.let { Isbn.toIsbn10(it) },
                pageCount = v.int("pageCount")?.takeIf { it > 0 },
                coverUrl = img,
                categories = v.strings("categories"),
            )
        }
    }

    @Suppress("UNCHECKED_CAST")
    fun errorMessage(json: String): String? = try {
        ((Json.parse(json) as? Map<String, Any?>)?.obj("error"))?.str("message")
    } catch (e: Exception) {
        null
    }

    @Suppress("unused")
    private fun Map<String, Any?>.hasItems() = list("items")?.isNotEmpty() == true
}

enum class MatchOutcome { MATCHED, MULTIPLE, NOT_FOUND }

data class MatchDecision(val outcome: MatchOutcome, val best: MetadataResult?, val plausible: List<MetadataResult>)

/**
 * Scores search results against a known title + author. A result is "plausible" only when both
 * the title and an author surname agree; a title alone never identifies the book.
 */
object MatchScorer {
    fun titleScore(query: String, candidate: MetadataResult): Double {
        val q = TextNormalizer.title(query)
        val full = TextNormalizer.title(candidate.displayTitle)
        val main = TextNormalizer.title(candidate.title)
        if (q.isEmpty()) return 0.0
        if (q == main || q == full) return 1.0
        if (TextNormalizer.shortTitle(query) == main || TextNormalizer.shortTitle(query) == TextNormalizer.shortTitle(candidate.title)) return 0.9
        return maxOf(TextNormalizer.jaccard(query, candidate.title), TextNormalizer.jaccard(query, candidate.displayTitle))
    }

    fun isPlausible(title: String, authors: List<String>, c: MetadataResult): Boolean =
        authors.isNotEmpty() && titleScore(title, c) >= 0.85 && TextNormalizer.authorsOverlap(authors, c.authors)

    fun decide(title: String, authors: List<String>, results: List<MetadataResult>): MatchDecision {
        val plausible = results.filter { isPlausible(title, authors, it) }
            .sortedByDescending { titleScore(title, it) + (if (it.coverUrl != null) 0.05 else 0.0) }
        return when {
            plausible.isEmpty() -> MatchDecision(MatchOutcome.NOT_FOUND, null, emptyList())
            plausible.size == 1 -> MatchDecision(MatchOutcome.MATCHED, plausible[0], plausible)
            else -> MatchDecision(MatchOutcome.MULTIPLE, plausible[0], plausible)
        }
    }
}

/**
 * Applies looked-up metadata to an existing book. Only empty bibliographic fields are filled;
 * personal data (status, rating, notes, dates, progress, tags) and custom covers are never touched.
 */
object MetadataMerge {
    data class Outcome(val book: app.saeculum.core.model.Book, val changedFields: List<String>)

    fun fillMissing(book: app.saeculum.core.model.Book, r: MetadataResult, now: Long): Outcome {
        val changed = mutableListOf<String>()
        var b = book
        if (b.isbn13.isNullOrBlank() && b.isbn10.isNullOrBlank() && (r.isbn13 != null || r.isbn10 != null)) {
            b = b.copy(isbn13 = r.isbn13, isbn10 = r.isbn10); changed += "ISBN"
        }
        if (b.publicationYear == null && r.publicationYear != null) {
            b = b.copy(publicationYear = r.publicationYear); changed += "Publication year"
        }
        if (b.publisher.isNullOrBlank() && !r.publisher.isNullOrBlank()) {
            b = b.copy(publisher = r.publisher); changed += "Publisher"
        }
        if (b.totalPages == null && r.pageCount != null) {
            b = b.copy(totalPages = r.pageCount); changed += "Pages"
        }
        if (b.genre.isNullOrBlank() && r.categories.isNotEmpty()) {
            b = b.copy(genre = r.categories.first()); changed += "Genre"
        }
        if (b.authors.isEmpty() && r.authors.isNotEmpty()) {
            b = b.copy(authors = r.authors); changed += "Authors"
        }
        if (!b.coverIsCustom && b.coverPath.isNullOrBlank() && b.coverUrl.isNullOrBlank() && r.coverUrl != null) {
            b = b.copy(coverUrl = r.coverUrl); changed += "Cover"
        }
        if (changed.isNotEmpty()) b = b.copy(lastModified = now)
        return Outcome(b, changed)
    }
}
