package app.saeculum.core.migration

import app.saeculum.core.importer.BookIdentity
import app.saeculum.core.importer.DuplicateDetector
import app.saeculum.core.importer.DuplicateReason
import app.saeculum.core.model.Book
import app.saeculum.core.model.ReadingStatus

/**
 * Parses a plain-text historical reading list of the form:
 *
 * ```
 * Novels Read 2025:
 * Dune by Frank Herbert
 * 1984 - George Orwell
 * Banana Fish-100%
 * No: 30
 * ```
 *
 * Rules: original spellings are preserved; only whitespace is normalised. Nothing is invented
 * (no ratings, ISBNs, covers, exact dates). Anything uncertain is flagged for review, not "fixed".
 */
object ReadingListParser {

    data class Entry(
        val lineNumber: Int,
        val raw: String,
        val title: String,
        val authors: List<String>,
        val year: Int?,
        val progressPercent: Int?,
        val reviewReasons: List<String>,
    ) {
        val needsReview: Boolean get() = reviewReasons.isNotEmpty()
        val isIncomplete: Boolean get() = authors.isEmpty() || title.isBlank()
    }

    data class YearSection(val year: Int, val headerLine: Int, val statedTotal: Int?, val entryCount: Int) {
        val discrepancy: Boolean get() = statedTotal != null && statedTotal != entryCount
    }

    data class InternalDuplicate(val first: Entry, val second: Entry, val reason: DuplicateReason)

    data class Result(
        val entries: List<Entry>,
        val sections: List<YearSection>,
        val unparsedLines: List<Pair<Int, String>>,
        val duplicates: List<InternalDuplicate>,
    ) {
        val incompleteCount: Int get() = entries.count { it.isIncomplete }
        val uncertainYearCount: Int get() = entries.count { it.year == null }
        val reviewCount: Int get() = entries.count { it.needsReview }
        val discrepancies: List<YearSection> get() = sections.filter { it.discrepancy }
    }

    private val headerRx = Regex("^\\s*(?:novels|books)\\s+read\\s+(?:in\\s+)?(\\d{4})\\s*:?\\s*$", RegexOption.IGNORE_CASE)
    private val totalRx = Regex("^\\s*(?:no|total|count)\\s*[:.]?\\s*(\\d*)\\s*$", RegexOption.IGNORE_CASE)
    private val separatorRx = Regex("^[\\s\\-–—_=*·.]{3,}$")
    /** Some PDF extractions glue a heading onto the separator line: "-----–-----Novels Read 2026:". */
    private val leadingSeparatorRx = Regex("^[\\-–—_=]{5,}\\s*")
    private val progressRx = Regex("\\s*-\\s*(\\d{1,3})\\s*%\\s*$")
    private val spacedHyphenRx = Regex("^(.*\\S)(?:\\s+-\\s*|\\s*-\\s+)(\\S.*)$")
    private val bareHyphenInitialRx = Regex("^(.*[A-Za-z])-((?:[A-Z]\\.)\\S*\\s+[A-Z][\\w'.-]+)$")
    private val sectionRx = Regex("\\[\\s*(\\d+)\\s*-\\s*(\\d*)\\s*]")

    fun parse(text: String): Result {
        val entries = mutableListOf<Entry>()
        val unparsed = mutableListOf<Pair<Int, String>>()
        data class Sec(val year: Int, val line: Int, var stated: Int?, var count: Int)
        val sections = mutableListOf<Sec>()
        var currentYear: Int? = null

        text.lines().forEachIndexed { idx, rawLine ->
            val lineNo = idx + 1
            val line = rawLine.replace(' ', ' ').replace('\u000C', ' ').trim()
                .replace(leadingSeparatorRx, "")
            if (line.isEmpty() || separatorRx.matches(line)) return@forEachIndexed

            headerRx.find(line)?.let { m ->
                currentYear = m.groupValues[1].toInt()
                sections += Sec(currentYear!!, lineNo, null, 0)
                return@forEachIndexed
            }
            totalRx.find(line)?.let { m ->
                val n = m.groupValues[1].toIntOrNull()
                sections.lastOrNull()?.stated = n
                return@forEachIndexed
            }
            val entry = parseEntry(lineNo, rawLine, currentYear)
            if (entry == null) {
                unparsed += lineNo to rawLine
            } else {
                entries += entry
                sections.lastOrNull()?.let { it.count++ }
            }
        }

        val ids = entries.map { BookIdentity(it.title, it.authors) }
        val dups = DuplicateDetector.pairsWithin(ids).map { (i, j, r) -> InternalDuplicate(entries[i], entries[j], r) }

        return Result(
            entries = entries,
            sections = sections.map { YearSection(it.year, it.line, it.stated, it.count) },
            unparsedLines = unparsed,
            duplicates = dups,
        )
    }

    fun parseEntry(lineNumber: Int, rawLine: String, year: Int?): Entry? {
        var s = rawLine.replace(' ', ' ').trim().replace(Regex("\\s+"), " ")
        if (s.isEmpty()) return null
        if (!s.any { it.isLetterOrDigit() }) return null
        val reasons = mutableListOf<String>()

        // Trailing progress marker: "Banana Fish-100%"
        var percent: Int? = null
        progressRx.find(s)?.let { m ->
            val p = m.groupValues[1].toInt()
            if (p in 0..100) {
                percent = p
                s = s.substring(0, m.range.first).trim()
            }
        }

        var title: String
        var authorPart: String? = null
        val byIdx = s.lastIndexOf(" by ")
        if (byIdx > 0 && byIdx + 4 < s.length) {
            title = s.substring(0, byIdx).trim()
            authorPart = s.substring(byIdx + 4).trim()
        } else {
            val spaced = spacedHyphenRx.find(s)
            val bare = bareHyphenInitialRx.find(s)
            when {
                spaced != null && looksLikeName(spaced.groupValues[2]) -> {
                    title = spaced.groupValues[1].trim()
                    authorPart = spaced.groupValues[2].trim()
                }
                bare != null -> {
                    title = bare.groupValues[1].trim()
                    authorPart = bare.groupValues[2].trim()
                    reasons += "Author was separated at a hyphen; please confirm."
                }
                else -> {
                    title = s
                    reasons += "No author found in the source line."
                }
            }
        }

        // Formatting-only normalisation of section ranges: "[035-0 ]" -> "[035-0]"
        title = title.replace(sectionRx) { m ->
            val a = m.groupValues[1]; val b = m.groupValues[2]
            val end = b.toIntOrNull()
            val start = a.toIntOrNull()
            if (b.isEmpty() || (end != null && start != null && end < start)) {
                if (reasons.none { it.startsWith("Section range") }) reasons += "Section range appears incomplete in the source list."
            }
            "[$a-$b]"
        }
        if (title.length <= 2) reasons += "Very short title; it may be incomplete."
        if (year == null) reasons += "No year heading above this entry; completion year unknown."

        val authors = authorPart?.let { splitAuthors(it) } ?: emptyList()
        if (title.isBlank()) return null
        return Entry(lineNumber, rawLine.trim(), title, authors, year, percent, reasons)
    }

    /**
     * Splits co-author credits on "&" / " and " only when every part is a full name (2+ words),
     * so shared-surname credits like "Keith & Sheila Gregoire" stay intact.
     */
    fun splitAuthors(credit: String): List<String> {
        val c = credit.trim().trimEnd(',', ';')
        if (c.isEmpty()) return emptyList()
        val parts = c.split(Regex("\\s*&\\s*|\\s+and\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size > 1 && parts.all { it.split(' ').filter { w -> w.isNotEmpty() }.size >= 2 }) return parts
        return listOf(c)
    }

    private fun looksLikeName(s: String): Boolean {
        val t = s.trim()
        if (t.isEmpty() || !t[0].isUpperCase()) return false
        val words = t.split(' ').filter { it.isNotEmpty() }
        return words.size in 1..5 && t.none { it.isDigit() }
    }

    /** Converts parsed entries into books, preserving list order via ascending [Book.dateAdded]. */
    fun toBooks(
        result: Result,
        sourceName: String,
        now: Long,
        newUuid: () -> String,
    ): List<Book> = result.entries.mapIndexed { i, e ->
        val notes = buildString {
            if (e.progressPercent != null) append("Imported progress: ${e.progressPercent}%")
        }
        Book(
            uuid = newUuid(),
            title = e.title,
            authors = e.authors,
            status = ReadingStatus.COMPLETED,
            completedYear = e.year,
            progressPercent = e.progressPercent,
            notes = notes,
            dateAdded = now + i,
            source = sourceName,
            sourceText = e.raw,
            needsReview = e.needsReview,
            reviewReason = e.reviewReasons.joinToString(" ").ifEmpty { null },
            importKey = "seed:$sourceName:${e.lineNumber}",
            lastModified = now + i,
        )
    }
}
