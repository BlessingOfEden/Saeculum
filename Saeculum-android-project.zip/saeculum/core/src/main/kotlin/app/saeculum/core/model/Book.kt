package app.saeculum.core.model

import java.time.LocalDate

/**
 * Reading status. A book's presence in the library never implies it was read:
 * only [COMPLETED] counts toward completion statistics.
 */
enum class ReadingStatus(val label: String, val shortLabel: String) {
    WANT_TO_BUY("Want to Buy", "To Buy"),
    TO_READ("To Read", "To Read"),
    READING("Currently Reading", "Reading"),
    COMPLETED("Completed", "Completed"),
    PAUSED("Paused / On Hold", "Paused"),
    ABANDONED("Abandoned", "Abandoned");

    companion object {
        private val synonyms: Map<String, ReadingStatus> = buildMap {
            listOf("wanttobuy", "tobuy", "wishlist", "buy", "topurchase", "wanttopurchase")
                .forEach { put(it, WANT_TO_BUY) }
            listOf("toread", "tbr", "wanttoread", "planned", "plantoread", "unread", "notstarted")
                .forEach { put(it, TO_READ) }
            listOf("reading", "currentlyreading", "inprogress", "current", "started")
                .forEach { put(it, READING) }
            listOf("completed", "complete", "read", "finished", "done", "readit")
                .forEach { put(it, COMPLETED) }
            listOf("paused", "onhold", "hold", "pausedonhold", "suspended")
                .forEach { put(it, PAUSED) }
            listOf("abandoned", "dnf", "didnotfinish", "dropped", "gaveup")
                .forEach { put(it, ABANDONED) }
        }

        /** Parses free-form status text (CSV values, backup values). Returns null if unrecognised. */
        fun parse(text: String?): ReadingStatus? {
            if (text.isNullOrBlank()) return null
            val trimmed = text.trim()
            entries.firstOrNull { it.name.equals(trimmed, ignoreCase = true) }?.let { return it }
            val key = trimmed.lowercase().filter { it.isLetterOrDigit() }
            return synonyms[key]
        }
    }
}

/**
 * The core book record. Unknown data stays null/empty; nothing is invented.
 *
 * Completion is stored as an optional exact [completedDate] and an optional [completedYear].
 * When a date is known its year always equals [completedYear]; a year may be known without a date.
 */
data class Book(
    val id: Long = 0,
    val uuid: String,
    val title: String,
    val authors: List<String> = emptyList(),
    val isbn10: String? = null,
    val isbn13: String? = null,
    val coverUrl: String? = null,
    val coverPath: String? = null,
    val coverIsCustom: Boolean = false,
    val publicationYear: Int? = null,
    val publisher: String? = null,
    val status: ReadingStatus = ReadingStatus.TO_READ,
    val rating: Int? = null,
    val notes: String = "",
    val dateAdded: Long,
    val completedDate: LocalDate? = null,
    val completedYear: Int? = null,
    val startedDate: LocalDate? = null,
    val currentPage: Int? = null,
    val totalPages: Int? = null,
    val progressPercent: Int? = null,
    val genre: String? = null,
    val tags: List<String> = emptyList(),
    val source: String? = null,
    val sourceText: String? = null,
    val needsReview: Boolean = false,
    val reviewReason: String? = null,
    val importKey: String? = null,
    val lastModified: Long,
    val deletedAt: Long? = null,
) {
    /** The completion year used for statistics/sorting; null when unknown or not completed. */
    val effectiveCompletionYear: Int?
        get() = if (status == ReadingStatus.COMPLETED) completedYear ?: completedDate?.year else null

    val isCompleted: Boolean get() = status == ReadingStatus.COMPLETED

    val authorLine: String get() = Authors.join(authors)

    val primaryIsbn: String? get() = isbn13 ?: isbn10

    /** Reading progress in 0..1 when it can be determined from recorded data, else null. */
    val progressFraction: Float?
        get() {
            val cp = currentPage
            val tp = totalPages
            if (cp != null && tp != null && tp > 0) return (cp.toFloat() / tp).coerceIn(0f, 1f)
            val pct = progressPercent ?: return null
            return (pct / 100f).coerceIn(0f, 1f)
        }

    val progressPercentDisplay: Int? get() = progressFraction?.let { Math.round(it * 100) }

    companion object {
        const val MIN_RATING = 1
        const val MAX_RATING = 5
        fun isValidRating(r: Int?): Boolean = r == null || r in MIN_RATING..MAX_RATING
    }
}

object Authors {
    /** "A", "A & B", "A, B & C". */
    fun join(authors: List<String>): String {
        val clean = authors.map { it.trim() }.filter { it.isNotEmpty() }
        return when (clean.size) {
            0 -> ""
            1 -> clean[0]
            2 -> "${clean[0]} & ${clean[1]}"
            else -> clean.dropLast(1).joinToString(", ") + " & " + clean.last()
        }
    }

    /**
     * Best-effort surname for sorting and matching. Handles "Last, First" and "First Last".
     * Single names (e.g. "Homer") are their own surname.
     */
    fun surname(author: String): String {
        val a = author.trim()
        if (a.isEmpty()) return ""
        if (a.contains(',')) return a.substringBefore(',').trim()
        val tokens = a.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val filtered = tokens.filterNot { it.lowercase().trimEnd('.') in SUFFIXES }
        val last = (filtered.ifEmpty { tokens }).last()
        // "C.s Lewis" -> "Lewis"; "P.Masonheimer" -> "Masonheimer"
        return last.substringAfterLast('.').ifEmpty { last }
    }

    /** First name portion for CSV export ("John Steinbeck" -> "John"; "Geisler, Norman L." -> "Norman L."). */
    fun givenNames(author: String): String {
        val a = author.trim()
        if (a.contains(',')) return a.substringAfter(',').trim()
        val tokens = a.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.size <= 1) return ""
        return tokens.dropLast(1).joinToString(" ")
    }

    private val SUFFIXES = setOf("jr", "sr", "ii", "iii", "iv", "et", "al", "phd")
}
