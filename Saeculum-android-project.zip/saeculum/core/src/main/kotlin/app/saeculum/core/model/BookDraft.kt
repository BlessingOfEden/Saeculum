package app.saeculum.core.model

import app.saeculum.core.isbn.Isbn
import app.saeculum.core.text.Dates
import java.time.LocalDate
import java.time.ZoneOffset

/**
 * An unsaved book (from manual entry, search, scan, CSV or migration). [status] may be null when the
 * source did not specify one; the caller supplies a default the user chose.
 */
data class BookDraft(
    val title: String = "",
    val authors: List<String> = emptyList(),
    val isbn10: String? = null,
    val isbn13: String? = null,
    val coverUrl: String? = null,
    val publicationYear: Int? = null,
    val publisher: String? = null,
    val status: ReadingStatus? = null,
    val rating: Int? = null,
    val notes: String = "",
    val completedDate: LocalDate? = null,
    val completedYear: Int? = null,
    val startedDate: LocalDate? = null,
    val currentPage: Int? = null,
    val totalPages: Int? = null,
    val progressPercent: Int? = null,
    val genre: String? = null,
    val tags: List<String> = emptyList(),
    val dateAdded: LocalDate? = null,
) {
    fun toBook(
        uuid: String,
        now: Long,
        defaultStatus: ReadingStatus,
        source: String? = null,
        sourceText: String? = null,
        importKey: String? = null,
        needsReview: Boolean = false,
        reviewReason: String? = null,
    ): Book {
        val st = status ?: defaultStatus
        val completed = st == ReadingStatus.COMPLETED
        return Book(
            uuid = uuid,
            title = title.trim(),
            authors = authors.map { it.trim() }.filter { it.isNotEmpty() },
            isbn10 = isbn10?.takeIf { it.isNotBlank() },
            isbn13 = isbn13?.takeIf { it.isNotBlank() },
            coverUrl = coverUrl?.takeIf { it.isNotBlank() },
            publicationYear = publicationYear,
            publisher = publisher?.trim()?.takeIf { it.isNotEmpty() },
            status = st,
            rating = rating?.takeIf { Book.isValidRating(it) },
            notes = notes,
            dateAdded = dateAdded?.atStartOfDay()?.toInstant(ZoneOffset.UTC)?.toEpochMilli() ?: now,
            completedDate = if (completed) completedDate else null,
            completedYear = if (completed) (completedDate?.year ?: completedYear) else null,
            startedDate = startedDate,
            currentPage = currentPage,
            totalPages = totalPages,
            progressPercent = progressPercent,
            genre = genre?.trim()?.takeIf { it.isNotEmpty() },
            tags = tags.map { it.trim() }.filter { it.isNotEmpty() }.distinct(),
            source = source,
            sourceText = sourceText,
            needsReview = needsReview,
            reviewReason = reviewReason,
            importKey = importKey,
            lastModified = now,
        )
    }

    companion object {
        fun from(book: Book) = BookDraft(
            title = book.title, authors = book.authors, isbn10 = book.isbn10, isbn13 = book.isbn13,
            coverUrl = book.coverUrl, publicationYear = book.publicationYear, publisher = book.publisher,
            status = book.status, rating = book.rating, notes = book.notes,
            completedDate = book.completedDate, completedYear = book.completedYear,
            startedDate = book.startedDate, currentPage = book.currentPage, totalPages = book.totalPages,
            progressPercent = book.progressPercent, genre = book.genre, tags = book.tags,
        )
    }
}

/** Field-level validation shared by the editor and importers. */
object BookValidator {
    data class Problems(val errors: Map<String, String>, val warnings: List<String> = emptyList()) {
        val ok: Boolean get() = errors.isEmpty()
    }

    const val TITLE = "title"
    const val AUTHOR = "author"
    const val ISBN = "isbn"
    const val RATING = "rating"
    const val PAGES = "pages"
    const val YEAR = "year"
    const val PERCENT = "percent"
    const val COMPLETED = "completed"

    fun validate(d: BookDraft, requireAuthor: Boolean = true): Problems {
        val e = linkedMapOf<String, String>()
        val w = mutableListOf<String>()
        if (d.title.isBlank()) e[TITLE] = "Title is required."
        if (requireAuthor && d.authors.none { it.isNotBlank() }) e[AUTHOR] = "Add at least one author."
        val isbn = d.isbn13 ?: d.isbn10
        if (!isbn.isNullOrBlank() && !Isbn.isValid(isbn)) e[ISBN] = "This isn't a valid ISBN-10 or ISBN-13."
        if (!Book.isValidRating(d.rating)) e[RATING] = "Rating must be 1–5 stars."
        d.totalPages?.let { if (it <= 0) e[PAGES] = "Total pages must be positive." }
        d.currentPage?.let { cp ->
            if (cp < 0) e[PAGES] = "Current page can't be negative."
            else d.totalPages?.let { tp -> if (cp > tp) e[PAGES] = "Current page is past the last page." }
        }
        d.progressPercent?.let { if (it !in 0..100) e[PERCENT] = "Percentage must be 0–100." }
        d.publicationYear?.let { if (it !in 0..Dates.maxYear()) e[YEAR] = "Publication year looks wrong." }
        if (d.status == ReadingStatus.COMPLETED) {
            d.completedYear?.let { if (it !in Dates.MIN_YEAR..Dates.maxYear()) e[COMPLETED] = "Completion year looks wrong." }
            d.completedDate?.let { if (it.isAfter(LocalDate.now().plusDays(1))) e[COMPLETED] = "Completion date is in the future." }
            if (d.completedDate != null && d.completedYear != null && d.completedDate.year != d.completedYear) {
                w += "Completion year ${d.completedYear} differs from date ${d.completedDate}; the date's year will be used."
            }
        }
        return Problems(e, w)
    }
}
