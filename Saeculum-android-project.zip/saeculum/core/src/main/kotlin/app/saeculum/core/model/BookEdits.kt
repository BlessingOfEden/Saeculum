package app.saeculum.core.model

/**
 * Field-wise three-way merge used when saving the full editor.
 *
 * [original] is the record as it was when the editor opened, [edited] is what the user submitted and
 * [current] is what is in the database now. A field takes the edited value only if the user actually
 * changed it; otherwise the current value wins. This means editing, say, the publisher never
 * overwrites notes or a rating that were changed in the detail sheet meanwhile.
 */
object BookEdits {
    private fun <T> pick(current: T, original: T, edited: T): T = if (edited != original) edited else current

    fun threeWayMerge(current: Book, original: Book, edited: Book, now: Long): Book {
        val statusChanged = edited.status != original.status ||
            edited.completedDate != original.completedDate || edited.completedYear != original.completedYear
        return current.copy(
            title = pick(current.title, original.title, edited.title),
            authors = pick(current.authors, original.authors, edited.authors),
            isbn10 = pick(current.isbn10, original.isbn10, edited.isbn10),
            isbn13 = pick(current.isbn13, original.isbn13, edited.isbn13),
            coverUrl = pick(current.coverUrl, original.coverUrl, edited.coverUrl),
            coverPath = pick(current.coverPath, original.coverPath, edited.coverPath),
            coverIsCustom = pick(current.coverIsCustom, original.coverIsCustom, edited.coverIsCustom),
            publicationYear = pick(current.publicationYear, original.publicationYear, edited.publicationYear),
            publisher = pick(current.publisher, original.publisher, edited.publisher),
            // Status and completion move together so they can't end up inconsistent.
            status = if (statusChanged) edited.status else current.status,
            completedDate = if (statusChanged) edited.completedDate else current.completedDate,
            completedYear = if (statusChanged) edited.completedYear else current.completedYear,
            rating = pick(current.rating, original.rating, edited.rating),
            notes = pick(current.notes, original.notes, edited.notes),
            startedDate = pick(current.startedDate, original.startedDate, edited.startedDate),
            currentPage = pick(current.currentPage, original.currentPage, edited.currentPage),
            totalPages = pick(current.totalPages, original.totalPages, edited.totalPages),
            progressPercent = pick(current.progressPercent, original.progressPercent, edited.progressPercent),
            genre = pick(current.genre, original.genre, edited.genre),
            tags = pick(current.tags, original.tags, edited.tags),
            lastModified = now,
        )
    }

    /** Applies editor fields from a draft onto an existing book (no merge; used to build [edited]). */
    fun applyDraft(base: Book, d: BookDraft): Book {
        val status = d.status ?: base.status
        val completed = status == ReadingStatus.COMPLETED
        return base.copy(
            title = d.title.trim(),
            authors = d.authors.map { it.trim() }.filter { it.isNotEmpty() },
            isbn10 = d.isbn10?.takeIf { it.isNotBlank() },
            isbn13 = d.isbn13?.takeIf { it.isNotBlank() },
            coverUrl = d.coverUrl?.takeIf { it.isNotBlank() },
            publicationYear = d.publicationYear,
            publisher = d.publisher?.trim()?.takeIf { it.isNotEmpty() },
            status = status,
            rating = d.rating?.takeIf { Book.isValidRating(it) },
            notes = d.notes,
            completedDate = if (completed) d.completedDate else null,
            completedYear = if (completed) (d.completedDate?.year ?: d.completedYear) else null,
            startedDate = d.startedDate,
            currentPage = d.currentPage,
            totalPages = d.totalPages,
            progressPercent = d.progressPercent,
            genre = d.genre?.trim()?.takeIf { it.isNotEmpty() },
            tags = d.tags.map { it.trim() }.filter { it.isNotEmpty() }.distinct(),
        )
    }
}
