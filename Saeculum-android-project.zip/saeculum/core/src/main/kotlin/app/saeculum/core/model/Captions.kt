package app.saeculum.core.model

/** A caption shown under the Library title. Quotations carry a verifiable source. */
data class Caption(val id: String, val text: String, val attribution: String? = null, val source: String? = null) {
    val isQuotation: Boolean get() = attribution != null
}

enum class CaptionMode { HIDDEN, MOTIVATIONAL, QUOTATION, CUSTOM }

/**
 * Built-in captions, shipped with the app (no network). Quotations are limited to well-documented
 * public-domain or widely-cited texts with exact wording and source.
 */
object Captions {
    val motivational = listOf(
        Caption("m1", "Your reading life, carefully kept."),
        Caption("m2", "One book at a time, an age of reading."),
        Caption("m3", "Read slowly. Remember well."),
        Caption("m4", "Another chapter is waiting."),
        Caption("m5", "Every finished book is part of your story."),
    )

    val quotations = listOf(
        Caption("q1", "Take up and read.", "Augustine of Hippo", "Confessions, Book VIII"),
        Caption(
            "q2", "Some books are to be tasted, others to be swallowed, and some few to be chewed and digested.",
            "Francis Bacon", "“Of Studies,” Essays (1625)",
        ),
        Caption("q3", "Reading maketh a full man; conference a ready man; and writing an exact man.", "Francis Bacon", "“Of Studies,” Essays (1625)"),
        Caption("q4", "There is no Frigate like a Book / To take us Lands away.", "Emily Dickinson", "“There is no Frigate like a Book”"),
        Caption("q5", "Of making many books there is no end; and much study is a weariness of the flesh.", "Ecclesiastes 12:12", "King James Version"),
        Caption(
            "q6", "It is a good rule after reading a new book, never to allow yourself another new one till you have read an old one in between.",
            "C. S. Lewis", "“On the Reading of Old Books” (1944)",
        ),
    )

    val all: List<Caption> get() = motivational + quotations

    fun byId(id: String?): Caption? = all.firstOrNull { it.id == id }

    fun resolve(mode: CaptionMode, selectedId: String?, custom: String?): Caption? = when (mode) {
        CaptionMode.HIDDEN -> null
        CaptionMode.MOTIVATIONAL -> motivational.firstOrNull { it.id == selectedId } ?: motivational.first()
        CaptionMode.QUOTATION -> quotations.firstOrNull { it.id == selectedId } ?: quotations.first()
        CaptionMode.CUSTOM -> custom?.trim()?.takeIf { it.isNotEmpty() }?.let { Caption("custom", it) }
    }
}
