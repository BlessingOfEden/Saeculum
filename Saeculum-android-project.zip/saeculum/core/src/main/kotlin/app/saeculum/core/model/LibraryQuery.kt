package app.saeculum.core.model

import app.saeculum.core.text.TextNormalizer
import java.time.LocalDate

enum class BookSort(val label: String) {
    TITLE_ASC("Title, A–Z"),
    TITLE_DESC("Title, Z–A"),
    AUTHOR_ASC("Author, A–Z"),
    AUTHOR_DESC("Author, Z–A"),
    COMPLETED_NEWEST("Completed, newest first"),
    COMPLETED_OLDEST("Completed, oldest first"),
    ADDED_NEWEST("Date added, newest first"),
    ADDED_OLDEST("Date added, oldest first"),
    RATING_HIGHEST("Rating, highest first"),
    RATING_LOWEST("Rating, lowest first"),
    PUBLISHED_NEWEST("Publication year, newest first");

    companion object {
        fun fromName(name: String?) = entries.firstOrNull { it.name == name } ?: ADDED_NEWEST
    }
}

/** Library filter. Empty sets mean "no restriction". [UNKNOWN_YEAR] selects completed books without a year. */
data class BookFilter(
    val statuses: Set<ReadingStatus> = emptySet(),
    val completionYears: Set<Int> = emptySet(),
    val genres: Set<String> = emptySet(),
    val authors: Set<String> = emptySet(),
    val query: String = "",
    val needsReviewOnly: Boolean = false,
) {
    val isActive: Boolean
        get() = statuses.isNotEmpty() || completionYears.isNotEmpty() || genres.isNotEmpty() ||
            authors.isNotEmpty() || query.isNotBlank() || needsReviewOnly

    val activeCount: Int
        get() = listOf(statuses.isNotEmpty(), completionYears.isNotEmpty(), genres.isNotEmpty(), authors.isNotEmpty(), needsReviewOnly)
            .count { it }

    fun matches(b: Book): Boolean {
        if (b.deletedAt != null) return false
        if (statuses.isNotEmpty() && b.status !in statuses) return false
        if (completionYears.isNotEmpty()) {
            val y = b.effectiveCompletionYear
            val ok = if (y == null) (b.isCompleted && UNKNOWN_YEAR in completionYears) else y in completionYears
            if (!ok) return false
        }
        if (genres.isNotEmpty()) {
            val g = (listOfNotNull(b.genre) + b.tags).map { it.lowercase() }
            if (genres.none { it.lowercase() in g }) return false
        }
        if (authors.isNotEmpty()) {
            val keys = b.authors.map { TextNormalizer.authorKey(it) }
            if (authors.none { TextNormalizer.authorKey(it) in keys }) return false
        }
        if (needsReviewOnly && !b.needsReview) return false
        if (query.isNotBlank()) {
            val q = TextNormalizer.foldAccents(query.trim()).lowercase()
            val hay = TextNormalizer.foldAccents(
                listOf(b.title, b.authorLine, b.isbn13.orEmpty(), b.isbn10.orEmpty(), b.publisher.orEmpty(), b.genre.orEmpty())
                    .joinToString(" ") + " " + b.tags.joinToString(" "),
            ).lowercase()
            if (q.split(Regex("\\s+")).any { it !in hay }) return false
        }
        return true
    }

    companion object {
        const val UNKNOWN_YEAR = -1
    }
}

object BookSorting {
    private fun titleKey(b: Book) = TextNormalizer.title(b.title).ifEmpty { b.title.lowercase() }
    private fun authorKey(b: Book): String =
        b.authors.firstOrNull()?.let { TextNormalizer.foldAccents(Authors.surname(it) + " " + it).lowercase() } ?: ""

    /** Completion sort key: exact date, else 1 Jan of the year (year-only sorts before dated books of that year). */
    private fun completionKey(b: Book): LocalDate? =
        if (!b.isCompleted) null else b.completedDate ?: b.completedYear?.let { LocalDate.of(it, 1, 1) }

    /** 0 = completed with a known year/date, 1 = completed but year unknown, 2 = not completed. */
    private fun completionRank(b: Book): Int = when {
        completionKey(b) != null -> 0
        b.isCompleted -> 1
        else -> 2
    }

    fun sort(books: List<Book>, sort: BookSort): List<Book> {
        val byTitle = compareBy<Book> { titleKey(it) }
        val c: Comparator<Book> = when (sort) {
            BookSort.TITLE_ASC -> byTitle
            BookSort.TITLE_DESC -> byTitle.reversed()
            BookSort.AUTHOR_ASC -> compareBy<Book> { authorKey(it).isEmpty() }.thenBy { authorKey(it) }.then(byTitle)
            BookSort.AUTHOR_DESC -> compareBy<Book> { authorKey(it).isEmpty() }.thenByDescending { authorKey(it) }.then(byTitle)
            BookSort.COMPLETED_NEWEST -> compareBy<Book> { completionRank(it) }
                .thenByDescending { completionKey(it) }.thenByDescending { it.dateAdded }
            BookSort.COMPLETED_OLDEST -> compareBy<Book> { completionRank(it) }
                .thenBy { completionKey(it) }.thenBy { it.dateAdded }
            BookSort.ADDED_NEWEST -> compareByDescending<Book> { it.dateAdded }
            BookSort.ADDED_OLDEST -> compareBy { it.dateAdded }
            BookSort.RATING_HIGHEST -> compareBy<Book> { it.rating == null }.thenByDescending { it.rating }.then(byTitle)
            BookSort.RATING_LOWEST -> compareBy<Book> { it.rating == null }.thenBy { it.rating }.then(byTitle)
            BookSort.PUBLISHED_NEWEST -> compareBy<Book> { it.publicationYear == null }
                .thenByDescending { it.publicationYear }.then(byTitle)
        }
        return books.sortedWith(c)
    }
}

/** How a book's completion should be recorded when it is marked Completed. */
sealed class Completion {
    data class OnDate(val date: LocalDate) : Completion()
    data class InYear(val year: Int) : Completion()
    data object Unknown : Completion()
}

object StatusTransitions {

    /** Moving a completed book to another status discards its completion record, so the UI must confirm. */
    fun requiresConfirmation(book: Book, newStatus: ReadingStatus): Boolean =
        book.status == ReadingStatus.COMPLETED && newStatus != ReadingStatus.COMPLETED &&
            (book.completedDate != null || book.completedYear != null)

    /** Moving to Completed needs a [Completion] choice (date, year only, or unknown). */
    fun needsCompletionInput(book: Book, newStatus: ReadingStatus): Boolean =
        newStatus == ReadingStatus.COMPLETED && book.status != ReadingStatus.COMPLETED

    fun apply(book: Book, newStatus: ReadingStatus, completion: Completion?, today: LocalDate, now: Long): Book {
        if (newStatus == book.status && completion == null) return book
        var b = book.copy(status = newStatus, lastModified = now)
        b = when (newStatus) {
            ReadingStatus.COMPLETED -> {
                val c = completion ?: Completion.OnDate(today)
                val withDate = when (c) {
                    is Completion.OnDate -> b.copy(completedDate = c.date, completedYear = c.date.year)
                    is Completion.InYear -> b.copy(completedDate = null, completedYear = c.year)
                    Completion.Unknown -> b.copy(completedDate = null, completedYear = null)
                }
                // Finishing a book fills its progress, without inventing a page count.
                if (withDate.totalPages != null) withDate.copy(currentPage = withDate.totalPages)
                else withDate.copy(progressPercent = 100)
            }
            else -> b.copy(completedDate = null, completedYear = null)
        }
        if (newStatus == ReadingStatus.READING && b.startedDate == null) b = b.copy(startedDate = today)
        return b
    }
}
