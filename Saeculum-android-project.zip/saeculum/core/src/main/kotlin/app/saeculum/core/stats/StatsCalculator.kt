package app.saeculum.core.stats

import app.saeculum.core.model.Book
import app.saeculum.core.model.ReadingStatus
import app.saeculum.core.text.TextNormalizer

data class AuthorCount(val name: String, val count: Int)

data class YearChange(val year: Int, val count: Int, val previousYear: Int, val previousCount: Int) {
    val delta: Int get() = count - previousCount
}

data class GoalProgress(val goal: Int, val done: Int) {
    val fraction: Float get() = if (goal <= 0) 0f else (done.toFloat() / goal).coerceIn(0f, 1f)
    val remaining: Int get() = (goal - done).coerceAtLeast(0)
}

/**
 * Every metric counts book records, never pages: a 60-page graphic novel and an 800-page novel each
 * count as one completed book. A book has at most one completion, so edits and status changes can't
 * double-count it.
 */
data class ReadingStats(
    val totalInLibrary: Int,
    val totalCompleted: Int,
    val completedThisYear: Int,
    val currentYear: Int,
    /** Completed books per year, newest year first. Only years with at least one book. */
    val completedByYear: List<Pair<Int, Int>>,
    val completedUnknownYear: Int,
    val reading: Int,
    val toRead: Int,
    val wantToBuy: Int,
    val paused: Int,
    val abandoned: Int,
    val rated: Int,
    val unrated: Int,
    val averageRating: Double?,
    /** Index 0 = one star ... index 4 = five stars. */
    val ratingDistribution: List<Int>,
    val mostProductiveYear: Pair<Int, Int>?,
    val yearChange: YearChange?,
    val favorites: List<Book>,
    val topAuthors: List<AuthorCount>,
    val goal: GoalProgress?,
    val inProgress: List<Book>,
) {
    val hasCompletedData: Boolean get() = totalCompleted > 0
}

object StatsCalculator {

    fun compute(allBooks: List<Book>, currentYear: Int, annualGoal: Int?): ReadingStats {
        val books = allBooks.filter { it.deletedAt == null }
        val completed = books.filter { it.status == ReadingStatus.COMPLETED }
        val withYear = completed.filter { it.effectiveCompletionYear != null }
        val byYear = withYear.groupingBy { it.effectiveCompletionYear!! }.eachCount()
        val byYearSorted = byYear.entries.sortedByDescending { it.key }.map { it.key to it.value }

        val rated = books.filter { it.rating != null }
        val dist = (1..5).map { star -> rated.count { it.rating == star } }
        val avg = if (rated.isEmpty()) null else rated.map { it.rating!! }.average()

        val mostProductive = byYear.entries
            .maxWithOrNull(compareBy<Map.Entry<Int, Int>> { it.value }.thenBy { it.key })
            ?.let { it.key to it.value }

        // Compare the latest year with data against the year before it (only when both have data).
        val change = byYearSorted.firstOrNull()?.let { (y, n) ->
            val prev = byYear[y - 1]
            if (prev != null) YearChange(y, n, y - 1, prev) else null
        }

        val favorites = books.filter { it.rating == 5 }
            .sortedWith(compareByDescending<Book> { it.effectiveCompletionYear ?: 0 }.thenByDescending { it.dateAdded })
            .take(12)

        val authorCounts = LinkedHashMap<String, MutableList<String>>()
        completed.forEach { b ->
            b.authors.distinctBy { TextNormalizer.authorKey(it) }.forEach { a ->
                val key = TextNormalizer.authorKey(a)
                if (key.isNotEmpty()) authorCounts.getOrPut(key) { mutableListOf() }.add(a.trim())
            }
        }
        val topAuthors = authorCounts.values
            .filter { it.size >= 2 }
            .map { spellings ->
                val display = spellings.groupingBy { it }.eachCount().maxByOrNull { it.value }!!.key
                AuthorCount(display, spellings.size)
            }
            .sortedWith(compareByDescending<AuthorCount> { it.count }.thenBy { it.name.lowercase() })
            .take(8)

        val thisYear = byYear[currentYear] ?: 0
        return ReadingStats(
            totalInLibrary = books.size,
            totalCompleted = completed.size,
            completedThisYear = thisYear,
            currentYear = currentYear,
            completedByYear = byYearSorted,
            completedUnknownYear = completed.size - withYear.size,
            reading = books.count { it.status == ReadingStatus.READING },
            toRead = books.count { it.status == ReadingStatus.TO_READ },
            wantToBuy = books.count { it.status == ReadingStatus.WANT_TO_BUY },
            paused = books.count { it.status == ReadingStatus.PAUSED },
            abandoned = books.count { it.status == ReadingStatus.ABANDONED },
            rated = rated.size,
            unrated = books.size - rated.size,
            averageRating = avg,
            ratingDistribution = dist,
            mostProductiveYear = mostProductive,
            yearChange = change,
            favorites = favorites,
            topAuthors = topAuthors,
            goal = annualGoal?.takeIf { it > 0 }?.let { GoalProgress(it, thisYear) },
            inProgress = books.filter { it.status == ReadingStatus.READING }.sortedByDescending { it.lastModified },
        )
    }

    /** Completed books for one year (or unknown year when [year] is null), in reading order. */
    fun booksForYear(allBooks: List<Book>, year: Int?): List<Book> =
        allBooks.filter { it.deletedAt == null && it.isCompleted && it.effectiveCompletionYear == year }
            .sortedWith(compareBy<Book, java.time.LocalDate?>(nullsLast()) { it.completedDate }.thenBy { it.dateAdded })
}
