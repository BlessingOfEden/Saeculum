package app.saeculum.core.text

import java.time.DateTimeException
import java.time.LocalDate
import java.time.Year

/** Result of reading a date that may be only partially known. */
sealed class ParsedDate {
    data class Full(val date: LocalDate) : ParsedDate()
    /** Only the year is certain (e.g. "2019", or an ambiguous "03/04/2019"). */
    data class YearOnly(val year: Int, val ambiguous: Boolean = false) : ParsedDate()
    data class Invalid(val raw: String) : ParsedDate()
}

object Dates {
    const val MIN_YEAR = 1000

    fun maxYear(): Int = Year.now().value + 1

    fun parseYear(raw: String?): Int? {
        val s = raw?.trim() ?: return null
        if (s.isEmpty()) return null
        val m = Regex("^(\\d{4})(?:\\.0+)?$").find(s) ?: return null
        val y = m.groupValues[1].toInt()
        return if (y in MIN_YEAR..maxYear()) y else null
    }

    /**
     * Parses ISO (2024-03-09), slash/dot year-first (2024/03/09) and day/month forms.
     * For "aa/bb/yyyy" where both parts could be a month, the year is kept and the date marked ambiguous
     * rather than guessing a month.
     */
    fun parse(raw: String?): ParsedDate? {
        val s = raw?.trim() ?: return null
        if (s.isEmpty()) return null
        parseYear(s)?.let { return ParsedDate.YearOnly(it) }
        // Strip a trailing time part: "2024-03-09 10:22" / "2024-03-09T10:22:00Z"
        val datePart = s.split('T', ' ').first()
        Regex("^(\\d{4})[-/.](\\d{1,2})[-/.](\\d{1,2})$").find(datePart)?.let { m ->
            val (y, mo, d) = m.destructured
            return make(y.toInt(), mo.toInt(), d.toInt(), s)
        }
        Regex("^(\\d{1,2})[-/.](\\d{1,2})[-/.](\\d{4})$").find(datePart)?.let { m ->
            val (a, b, y) = m.destructured
            val ai = a.toInt(); val bi = b.toInt(); val yi = y.toInt()
            return when {
                ai > 12 && bi <= 12 -> make(yi, bi, ai, s)          // dd/MM/yyyy
                bi > 12 && ai <= 12 -> make(yi, ai, bi, s)          // MM/dd/yyyy
                ai == bi -> make(yi, ai, bi, s)                     // same either way
                yi in MIN_YEAR..maxYear() -> ParsedDate.YearOnly(yi, ambiguous = true)
                else -> ParsedDate.Invalid(s)
            }
        }
        // "March 2019", "Mar 9, 2019" etc.: keep the 4-digit year if exactly one is present.
        val years = Regex("\\b(\\d{4})\\b").findAll(s).map { it.groupValues[1].toInt() }.toList()
        if (years.size == 1 && years[0] in MIN_YEAR..maxYear()) return ParsedDate.YearOnly(years[0], ambiguous = true)
        return ParsedDate.Invalid(s)
    }

    private fun make(y: Int, m: Int, d: Int, raw: String): ParsedDate = try {
        if (y !in MIN_YEAR..maxYear()) ParsedDate.Invalid(raw) else ParsedDate.Full(LocalDate.of(y, m, d))
    } catch (e: DateTimeException) {
        ParsedDate.Invalid(raw)
    }

    fun parseIsoOrNull(s: String?): LocalDate? = try {
        if (s.isNullOrBlank()) null else LocalDate.parse(s.trim())
    } catch (e: Exception) {
        null
    }
}
