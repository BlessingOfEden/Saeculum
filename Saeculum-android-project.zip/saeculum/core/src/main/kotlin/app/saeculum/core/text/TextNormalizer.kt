package app.saeculum.core.text

import app.saeculum.core.model.Authors
import java.text.Normalizer

/** Normalisation used for matching only. Stored data is never rewritten with these forms. */
object TextNormalizer {

    private val diacritics = Regex("\\p{InCombiningDiacriticalMarks}+")
    private val bracketed = Regex("[\\[(][^\\])]*[\\])]")
    private val leadingArticle = Regex("^(the|a|an)\\s+")

    fun foldAccents(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(diacritics, "")

    /** "The Hobbit: or There and Back Again" -> "hobbit or there and back again". */
    fun title(raw: String): String {
        var s = foldAccents(raw).lowercase()
        s = s.replace(bracketed, " ")
        s = s.replace("&", " and ")
        s = s.replace('’', '\'').replace("'", "")
        s = s.replace(Regex("[^a-z0-9]+"), " ").trim()
        s = s.replace(leadingArticle, "")
        return s.replace(Regex("\\s+"), " ")
    }

    /** Title before any subtitle separator (":" or " - "). */
    fun shortTitle(raw: String): String {
        val cut = raw.split(':', '—').first().split(" - ").first()
        return title(cut)
    }

    /** Lower-case letters/digits only: "C.S Lewis", "Cs Lewis", "C. S. Lewis" -> "cslewis". */
    fun authorKey(raw: String): String =
        foldAccents(raw).lowercase().filter { it.isLetterOrDigit() }

    /** Lower-cased surname used for overlap checks. */
    fun surnameKey(raw: String): String =
        foldAccents(Authors.surname(raw)).lowercase().filter { it.isLetterOrDigit() }

    fun authorsOverlap(a: List<String>, b: List<String>): Boolean {
        if (a.isEmpty() || b.isEmpty()) return false
        val sa = a.map { surnameKey(it) }.filter { it.isNotEmpty() }.toSet()
        val sb = b.map { surnameKey(it) }.filter { it.isNotEmpty() }.toSet()
        if (sa.intersect(sb).isNotEmpty()) return true
        // Fall back to whole-credit containment ("Keith & Sheila Gregoire" vs "Sheila Wray Gregoire").
        val ka = a.map { authorKey(it) }
        val kb = b.map { authorKey(it) }
        return ka.any { x -> kb.any { y -> x.isNotEmpty() && y.isNotEmpty() && (x.contains(y) || y.contains(x)) } }
    }

    fun tokens(s: String): Set<String> = title(s).split(' ').filter { it.isNotEmpty() }.toSet()

    fun jaccard(a: String, b: String): Double {
        val ta = tokens(a)
        val tb = tokens(b)
        if (ta.isEmpty() || tb.isEmpty()) return 0.0
        return ta.intersect(tb).size.toDouble() / ta.union(tb).size
    }
}
