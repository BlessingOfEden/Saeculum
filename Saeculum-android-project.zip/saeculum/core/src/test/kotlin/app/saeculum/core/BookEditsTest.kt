package app.saeculum.core

import app.saeculum.core.model.BookDraft
import app.saeculum.core.model.BookEdits
import app.saeculum.core.model.BookValidator
import app.saeculum.core.model.ReadingStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BookEditsTest {
    @Test fun editingDetailsNeverOverwritesConcurrentNotesOrRating() {
        val original = book("Tortilla Flat", "John Steinbeck", year = 2026, rating = 3, notes = "old")
        // Meanwhile the detail sheet saved new notes and a rating.
        val current = original.copy(notes = "new notes from the sheet", rating = 4)
        // The editor (opened earlier) only fixed the publisher.
        val edited = BookEdits.applyDraft(original, BookDraft.from(original).copy(publisher = "Penguin Books"))
        val merged = BookEdits.threeWayMerge(current, original, edited, 99L)
        assertEquals("Penguin Books", merged.publisher)
        assertEquals("new notes from the sheet", merged.notes)
        assertEquals(4, merged.rating)
        assertEquals(2026, merged.completedYear)
    }

    @Test fun userChangesWin() {
        val original = book("Dune", "Frank Herbert", year = 2025, rating = 3, notes = "a")
        val edited = BookEdits.applyDraft(original, BookDraft.from(original).copy(notes = "b", rating = null))
        val merged = BookEdits.threeWayMerge(original, original, edited, 1L)
        assertEquals("b", merged.notes)
        assertNull(merged.rating)
    }

    @Test fun movingOutOfCompletedInEditorClearsCompletionTogether() {
        val original = book("Dune", "Frank Herbert", year = 2025)
        val edited = BookEdits.applyDraft(original, BookDraft.from(original).copy(status = ReadingStatus.READING))
        val merged = BookEdits.threeWayMerge(original, original, edited, 1L)
        assertEquals(ReadingStatus.READING, merged.status)
        assertNull(merged.completedYear)
    }

    @Test fun manualEntryNeedsOnlyTitleAndAuthor() {
        assertTrue(BookValidator.validate(BookDraft(title = "Odyssey", authors = listOf("Homer"))).ok)
        val p = BookValidator.validate(BookDraft(title = " ", authors = emptyList(), isbn13 = "123", rating = 7))
        assertFalse(p.ok)
        assertEquals(setOf(BookValidator.TITLE, BookValidator.AUTHOR, BookValidator.ISBN, BookValidator.RATING), p.errors.keys)
    }
}
