package app.saeculum.core

import app.saeculum.core.csv.Csv
import app.saeculum.core.export.CsvExporter
import app.saeculum.core.importer.CsvField
import app.saeculum.core.importer.CsvMapping
import app.saeculum.core.importer.DuplicateAction
import app.saeculum.core.importer.DuplicateReason
import app.saeculum.core.importer.ImportPlan
import app.saeculum.core.importer.ImportPlanner
import app.saeculum.core.importer.RowDecision
import app.saeculum.core.model.ReadingStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class ImportTest {

    private fun plan(text: String, existing: List<app.saeculum.core.model.Book> = emptyList()): ImportPlan {
        val rows = Csv.parse(text)
        val (hasHeader, mapping) = CsvMapping.autoMap(rows.first().fields, rows.maxOf { it.fields.size })
        return ImportPlanner.plan(rows, hasHeader, mapping, existing)
    }

    private val spec = """
        "Book title","Author first name","Author last name"
        "The Hobbit","J. R. R.","Tolkien"
        "East of Eden","John","Steinbeck"
        "Fahrenheit 451","Ray","Bradbury"
        "The Pearl","John","Steinbeck"
        "Frankenstein","Mary","Shelley"
    """.trimIndent()

    @Test fun specExampleImportsFiveBooksWithoutInventingData() {
        val p = plan(spec)
        assertTrue(p.hasHeader)
        assertEquals(5, p.detectedCount)
        assertEquals(0, p.errorCount)
        val hobbit = p.candidates[0].draft
        assertEquals("The Hobbit", hobbit.title)
        assertEquals(listOf("J. R. R. Tolkien"), hobbit.authors)
        assertNull(hobbit.status)                // no status in file -> user picks default
        assertNull(hobbit.completedYear)         // never assigned the current year
        assertNull(hobbit.rating)
        assertTrue(p.needsDefaultStatus)

        val sel = ImportPlanner.select(p, emptyMap(), ReadingStatus.TO_READ, "f1", 1000L, ::uuid)
        assertEquals(5, sel.inserts.size)
        assertTrue(sel.inserts.all { it.book.status == ReadingStatus.TO_READ && it.book.completedYear == null })
        assertEquals("csv:f1:2", sel.inserts[0].book.importKey)
    }

    @Test fun columnOrderDoesNotMatterWithHeaders() {
        val p = plan("Author last name,Rating,Book title,Author first name,Completion year\nHerbert,5,Dune,Frank,2025\n")
        val d = p.candidates.single().draft
        assertEquals("Dune", d.title)
        assertEquals(listOf("Frank Herbert"), d.authors)
        assertEquals(5, d.rating)
        assertEquals(2025, d.completedYear)
        assertEquals(ReadingStatus.COMPLETED, d.status)
        assertTrue(p.candidates.single().statusInferred)
    }

    @Test fun noHeaderUsesDocumentedOrder() {
        val p = plan("Dune,Frank,Herbert\nOdyssey,,Homer\n")
        assertFalse(p.hasHeader)
        assertEquals(listOf("Frank Herbert"), p.candidates[0].draft.authors)
        assertEquals(listOf("Homer"), p.candidates[1].draft.authors)   // single-name author kept
    }

    @Test fun optionalColumnsAndMultipleAuthors() {
        val text = "Book title,Author first name,Author last name,Additional authors,ISBN,Completion date,Reading status,Rating,Publication year,Notes,Genre,Current page,Total pages\n" +
            "\"The Soul of Science\",Nancy,Pearcey,Charles Thaxton,,2026-02-01,Read,4,1994,\"Great, dense\nchapter 3\",Science,,\n" +
            "\"Crucial Conversations\",Joseph,Grenny,\"Kerry Patterson; Ron McMillan; Al Switzler\",,,currently reading,,,,,120,280\n"
        val p = plan(text)
        val a = p.candidates[0].draft
        assertEquals(listOf("Nancy Pearcey", "Charles Thaxton"), a.authors)
        assertEquals(LocalDate.of(2026, 2, 1), a.completedDate)
        assertEquals(2026, a.completedYear)
        assertEquals(ReadingStatus.COMPLETED, a.status)
        assertEquals("Great, dense\nchapter 3", a.notes)
        assertEquals(1994, a.publicationYear)
        val b = p.candidates[1].draft
        assertEquals(4, b.authors.size)
        assertEquals(ReadingStatus.READING, b.status)
        assertEquals(120, b.currentPage)
        assertEquals(280, b.totalPages)
    }

    @Test fun missingAndInvalidValuesAreReportedNotInvented() {
        val text = "Book title,Author,ISBN,Rating,Completion date\n" +
            ",Nobody,,,\n" +
            "Orphan Title,,,,\n" +
            "Bad Data,Some One,12345,9,03/04/2019\n"
        val p = plan(text)
        assertTrue(p.candidates[0].hasError)
        assertTrue(p.candidates[1].hasError)
        val c = p.candidates[2]
        assertFalse(c.hasError)
        assertTrue(c.hasWarning)
        assertNull(c.draft.isbn13)
        assertNull(c.draft.rating)
        assertNull(c.draft.completedDate)            // ambiguous day/month not guessed
        assertEquals(2019, c.draft.completedYear)    // but the year is preserved
        assertEquals(2, p.errorCount)
    }

    @Test fun goodreadsStyleExportMapsSafely() {
        val text = "Book Id,Title,Author,Author l-f,Additional Authors,ISBN,ISBN13,My Rating,Average Rating,Publisher,Number of Pages,Year Published,Date Read,Date Added,Exclusive Shelf\n" +
            "1,Dune,Frank Herbert,\"Herbert, Frank\",,=\"0441013597\",=\"9780441013593\",0,4.27,Ace,604,1990,,2024/01/05,to-read\n"
        val p = plan(text)
        val d = p.candidates.single().draft
        assertEquals("Dune", d.title)
        assertEquals(listOf("Frank Herbert"), d.authors)
        assertEquals("9780441013593", d.isbn13)
        assertNull(d.rating)                         // 0 = unrated; average rating ignored
        assertEquals(604, d.totalPages)
        assertEquals(ReadingStatus.TO_READ, d.status)
        assertEquals(LocalDate.of(2024, 1, 5), d.dateAdded)
        assertEquals(CsvField.IGNORE, CsvMapping.fieldForHeader("Average Rating"))
    }

    @Test fun duplicatesDetectedAgainstLibraryAndWithinFile() {
        val existing = listOf(book("The Hobbit", "J.R.R. Tolkien", year = 2026))
        val text = spec + "\n\"East of Eden\",\"John\",\"Steinbeck\"\n"
        val p = plan(text, existing)
        val hobbit = p.candidates[0]
        assertNotNull(hobbit.duplicateOfExisting)
        assertEquals(DuplicateReason.SAME_TITLE_AND_AUTHOR, hobbit.duplicateOfExisting!!.reason)
        val eden2 = p.candidates[5]
        assertEquals(1, eden2.duplicateOfRow)
        assertEquals(2, p.duplicateCount)

        val sel = ImportPlanner.select(p, emptyMap(), ReadingStatus.TO_READ, "f", 0L, ::uuid)
        assertEquals(4, sel.inserts.size)
        assertEquals(2, sel.skippedDuplicates.size)

        val forced = ImportPlanner.select(
            p, mapOf(0 to RowDecision(true, DuplicateAction.IMPORT_ANYWAY), 2 to RowDecision(include = false)),
            ReadingStatus.TO_READ, "f", 0L, ::uuid,
        )
        assertEquals(4, forced.inserts.size)
        assertEquals(1, forced.excluded.size)
    }

    @Test fun differentEditionsDefaultToImport() {
        val existing = listOf(book("Dune", "Frank Herbert", isbn13 = "9780441013593"))
        val p = plan("Title,Author,ISBN\nDune,Frank Herbert,9780593099322\n", existing)
        val c = p.candidates.single()
        assertEquals(DuplicateReason.SAME_TITLE_DIFFERENT_ISBN, c.duplicateOfExisting!!.reason)
        assertEquals(DuplicateAction.IMPORT_ANYWAY, ImportPlanner.defaultDecision(c).duplicateAction)
    }

    @Test fun exportReimportRoundTrip() {
        val original = listOf(
            book("Tortilla Flat", "John Steinbeck", year = 2026, rating = 3, notes = "Line one, with comma\n\"Quoted\" line two"),
            book("I Don't Have Enough Faith", "Geisler, Norman L.", "Frank Turek", status = ReadingStatus.TO_READ),
            book("Odyssey", "Homer", date = LocalDate.of(2025, 7, 14), rating = 5),
        )
        val csv = CsvExporter.export(original)
        val p = plan(csv)
        assertEquals(0, p.errorCount)
        val drafts = p.candidates.map { it.draft }
        assertEquals("Line one, with comma\n\"Quoted\" line two", drafts[0].notes)
        assertEquals(2026, drafts[0].completedYear)
        assertEquals(3, drafts[0].rating)
        assertEquals(listOf("Geisler, Norman L.", "Frank Turek"), drafts[1].authors)
        assertEquals(ReadingStatus.TO_READ, drafts[1].status)
        assertEquals(LocalDate.of(2025, 7, 14), drafts[2].completedDate)
        assertEquals(listOf("Homer"), drafts[2].authors)
        // Re-importing the export into a library that already has the books flags every row.
        val again = plan(csv, original)
        assertEquals(3, again.duplicateCount)
    }

    @Test fun ratingParsing() {
        assertEquals(4, ImportPlanner.parseRating("4"))
        assertEquals(4, ImportPlanner.parseRating("4.0"))
        assertEquals(4, ImportPlanner.parseRating("4/5"))
        assertEquals(3, ImportPlanner.parseRating("★★★☆☆"))
        assertNull(ImportPlanner.parseRating("4.5"))
        assertNull(ImportPlanner.parseRating("8/10"))
    }
}
