package app.saeculum.core

import app.saeculum.core.csv.Csv
import app.saeculum.core.isbn.Isbn
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class IsbnTest {
    @Test fun validatesIsbn13() {
        assertTrue(Isbn.isValidIsbn13("9780140187519"))
        assertTrue(Isbn.isValidIsbn13("978-0-14-018751-9"))
        assertFalse(Isbn.isValidIsbn13("9780140187510"))
        assertFalse(Isbn.isValidIsbn13("1234567890123"))      // wrong prefix
    }

    @Test fun validatesIsbn10IncludingX() {
        assertTrue(Isbn.isValidIsbn10("0441013597"))          // Dune
        assertTrue(Isbn.isValidIsbn10("080442957X"))
        assertFalse(Isbn.isValidIsbn10("0441013598"))
    }

    @Test fun convertsBetweenForms() {
        assertEquals("9780441013593", Isbn.toIsbn13("0441013597"))
        assertEquals("0441013597", Isbn.toIsbn10("9780441013593"))
        assertNull(Isbn.toIsbn10("9791034731213"))           // 979 has no ISBN-10
    }

    @Test fun cleansSpreadsheetArtefacts() {
        assertEquals("0441013597", Isbn.clean("=\"0441013597\""))
    }

    @Test fun barcodePayloads() {
        assertEquals("9780441013593", Isbn.fromBarcode("9780441013593"))
        assertEquals("9780441013593", Isbn.fromBarcode("0441013597"))
        assertNull(Isbn.fromBarcode("5012345678900"))         // a grocery EAN, not a book
        assertNull(Isbn.fromBarcode("9780441013594"))         // bad check digit
    }
}

class CsvTest {
    @Test fun parsesSpecExample() {
        val text = """
            "Book title","Author first name","Author last name"
            "The Hobbit","J. R. R.","Tolkien"
            "East of Eden","John","Steinbeck"
        """.trimIndent()
        val rows = Csv.parse(text)
        assertEquals(3, rows.size)
        assertEquals(listOf("The Hobbit", "J. R. R.", "Tolkien"), rows[1].fields)
    }

    @Test fun handlesCommasQuotesNewlinesBomAndCrlf() {
        val text = "﻿title,notes\r\n\"Hello, World\",\"She said \"\"hi\"\"\nsecond line\"\r\nPlain,x\r\n"
        val rows = Csv.parse(text)
        assertEquals(3, rows.size)
        assertEquals("Hello, World", rows[1].fields[0])
        assertEquals("She said \"hi\"\nsecond line", rows[1].fields[1])
        assertEquals(listOf("Plain", "x"), rows[2].fields)
        assertEquals(4, rows[2].lineNumber)
    }

    @Test fun specialCharactersSurvive() {
        val rows = Csv.parse("t,a\n\"Ð¾Ñ — Ωμέγα ✓ 漢字\",Ünïcödé\n")
        assertEquals("Ð¾Ñ — Ωμέγα ✓ 漢字", rows[1].fields[0])
        assertEquals("Ünïcödé", rows[1].fields[1])
    }

    @Test fun malformedRowDoesNotSwallowTheRest() {
        val text = "title,author\n\"Broken,Someone\nGood Book,Good Author\nAnother,Person\n"
        val rows = Csv.parse(text)
        assertEquals(4, rows.size)
        assertTrue(rows[1].malformed)
        assertEquals(listOf("Good Book", "Good Author"), rows[2].fields)
        assertEquals(listOf("Another", "Person"), rows[3].fields)
    }

    @Test fun detectsSemicolonAndTab() {
        assertEquals(';', Csv.detectDelimiter("title;author\nA;B"))
        assertEquals('\t', Csv.detectDelimiter("title\tauthor\nA\tB"))
        assertEquals(',', Csv.detectDelimiter("\"a;b\",c"))
    }

    @Test fun writerRoundTripsEverything() {
        val values = listOf("plain", "comma, inside", "quote \" inside", "multi\nline\r\nnotes", " padded ", "")
        val doc = Csv.write(listOf("a", "b", "c", "d", "e", "f"), listOf(values))
        val parsed = Csv.parse(doc)
        assertEquals(values.map { it.replace("\r\n", "\n") }, parsed[1].fields)
    }
}
