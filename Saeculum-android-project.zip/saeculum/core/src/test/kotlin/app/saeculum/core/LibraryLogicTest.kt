package app.saeculum.core

import app.saeculum.core.backup.BackupCodec
import app.saeculum.core.backup.RestoreMode
import app.saeculum.core.backup.RestorePlanner
import app.saeculum.core.export.TxtExporter
import app.saeculum.core.json.Json
import app.saeculum.core.metadata.GoogleBooksParser
import app.saeculum.core.metadata.MatchOutcome
import app.saeculum.core.metadata.MatchScorer
import app.saeculum.core.metadata.MetadataMerge
import app.saeculum.core.metadata.MetadataResult
import app.saeculum.core.metadata.OpenLibraryParser
import app.saeculum.core.model.BookFilter
import app.saeculum.core.model.BookSort
import app.saeculum.core.model.BookSorting
import app.saeculum.core.model.Captions
import app.saeculum.core.model.CaptionMode
import app.saeculum.core.model.Completion
import app.saeculum.core.model.ReadingStatus
import app.saeculum.core.model.StatusTransitions
import app.saeculum.core.stats.StatsCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class StatsTest {
    @Test fun countsOnlyCompletedBooksOncePerRecord() {
        val books = listOf(
            book("A", "X", year = 2026, rating = 5),
            book("B", "X", year = 2026, rating = 4),
            book("C", "Y", year = 2025),
            book("D", "Z", status = ReadingStatus.COMPLETED),             // unknown year
            book("E", "Z", status = ReadingStatus.READING, rating = 2),
            book("F", "Z", status = ReadingStatus.TO_READ),
            book("G", "Z", status = ReadingStatus.WANT_TO_BUY),
            book("H", "Z", year = 2026).copy(deletedAt = 5L),              // in trash
        )
        val s = StatsCalculator.compute(books, 2026, annualGoal = 10)
        assertEquals(7, s.totalInLibrary)
        assertEquals(4, s.totalCompleted)
        assertEquals(2, s.completedThisYear)
        assertEquals(listOf(2026 to 2, 2025 to 1), s.completedByYear)
        assertEquals(1, s.completedUnknownYear)
        assertEquals(1, s.reading)
        assertEquals(1, s.toRead)
        assertEquals(1, s.wantToBuy)
        assertEquals(3, s.rated)
        assertEquals(4, s.unrated)
        assertEquals(11.0 / 3, s.averageRating!!, 1e-9)
        assertEquals(listOf(0, 1, 0, 1, 1), s.ratingDistribution)
        assertEquals(2, s.goal!!.done)
        assertEquals(0.2f, s.goal!!.fraction, 1e-6f)
        assertEquals(2026, s.yearChange!!.year)
        assertEquals(1, s.yearChange!!.delta)
        assertEquals(listOf("A"), s.favorites.map { it.title })
    }

    @Test fun emptyLibraryHasNoMisleadingInsights() {
        val s = StatsCalculator.compute(emptyList(), 2026, null)
        assertNull(s.mostProductiveYear)
        assertNull(s.averageRating)
        assertNull(s.yearChange)
        assertNull(s.goal)
        assertTrue(s.topAuthors.isEmpty())
        assertFalse(s.hasCompletedData)
    }
}

class SortFilterTransitionTest {
    private val books = listOf(
        book("The Hobbit", "J.R.R. Tolkien", year = 2026, rating = 5, added = 30),
        book("Dune", "Frank Herbert", date = LocalDate.of(2025, 3, 1), rating = 3, added = 20),
        book("Animal Farm", "George Orwell", year = 2021, added = 10),
        book("Atomic Habits", "James Clear", status = ReadingStatus.TO_READ, added = 40),
        book("Mystery Year", "Anon Ymous", status = ReadingStatus.COMPLETED, added = 5),
    )

    @Test fun sortsIgnoreLeadingArticlesAndPutUnknownsLast() {
        assertEquals(listOf("Animal Farm", "Atomic Habits", "Dune", "The Hobbit", "Mystery Year"),
            BookSorting.sort(books, BookSort.TITLE_ASC).map { it.title })
        assertEquals(listOf("The Hobbit", "Dune", "Animal Farm", "Mystery Year", "Atomic Habits"),
            BookSorting.sort(books, BookSort.COMPLETED_NEWEST).map { it.title })
        assertEquals("Atomic Habits", BookSorting.sort(books, BookSort.ADDED_NEWEST).first().title)
        assertEquals(listOf("The Hobbit", "Dune"), BookSorting.sort(books, BookSort.RATING_HIGHEST).take(2).map { it.title })
        assertEquals("Atomic Habits", BookSorting.sort(books, BookSort.AUTHOR_ASC).first().title) // Clear
    }

    @Test fun filtersByStatusYearAndQuery() {
        assertEquals(1, books.count { BookFilter(statuses = setOf(ReadingStatus.TO_READ)).matches(it) })
        assertEquals(listOf("Dune"), books.filter { BookFilter(completionYears = setOf(2025)).matches(it) }.map { it.title })
        assertEquals(listOf("Mystery Year"), books.filter { BookFilter(completionYears = setOf(BookFilter.UNKNOWN_YEAR)).matches(it) }.map { it.title })
        assertEquals(listOf("Dune"), books.filter { BookFilter(query = "herbert") .matches(it) }.map { it.title })
        assertEquals(0, books.count { BookFilter(statuses = setOf(ReadingStatus.TO_READ), completionYears = setOf(2026)).matches(it) })
    }

    @Test fun statusTransitionsHandleCompletionConsistently() {
        val today = LocalDate.of(2026, 10, 19)
        val toRead = book("Atomic Habits", "James Clear", status = ReadingStatus.TO_READ)
        val reading = StatusTransitions.apply(toRead, ReadingStatus.READING, null, today, 1L)
        assertEquals(today, reading.startedDate)
        assertTrue(StatusTransitions.needsCompletionInput(reading, ReadingStatus.COMPLETED))
        val done = StatusTransitions.apply(reading, ReadingStatus.COMPLETED, Completion.InYear(2025), today, 2L)
        assertNull(done.completedDate)
        assertEquals(2025, done.effectiveCompletionYear)
        assertTrue(StatusTransitions.requiresConfirmation(done, ReadingStatus.TO_READ))
        val back = StatusTransitions.apply(done, ReadingStatus.TO_READ, null, today, 3L)
        assertNull(back.completedYear)
        assertNull(back.effectiveCompletionYear)
        val unknown = StatusTransitions.apply(back, ReadingStatus.COMPLETED, Completion.Unknown, today, 4L)
        assertNull(unknown.completedYear)
        assertFalse(StatusTransitions.requiresConfirmation(unknown, ReadingStatus.READING))
    }

    @Test fun captionsResolveWithoutNetworkAndCarryAttribution() {
        assertNull(Captions.resolve(CaptionMode.HIDDEN, null, null))
        assertTrue(Captions.quotations.all { it.attribution != null && it.source != null })
        assertEquals("Take up and read.", Captions.resolve(CaptionMode.QUOTATION, "q1", null)!!.text)
        assertEquals("Mine", Captions.resolve(CaptionMode.CUSTOM, null, "  Mine ")!!.text)
        assertNull(Captions.resolve(CaptionMode.CUSTOM, null, "  "))
    }

    @Test fun txtExportGroupsUnknownYearAndUnfinished() {
        val txt = TxtExporter.export(books)
        assertTrue(txt.contains("Completed — Year Unknown:\n• Mystery Year by Anon Ymous\nTotal: 1"))
        assertTrue(txt.contains("To Read:\n• Atomic Habits by James Clear\nTotal: 1"))
        assertTrue(txt.indexOf("Novels Read 2026") < txt.indexOf("Novels Read 2025"))
    }
}

class BackupAndJsonTest {
    @Test fun jsonRoundTripsTrickyStrings() {
        val m = linkedMapOf("s" to "quote \" back \\ nl \n tab \t é 漢 \u0001", "n" to 42L, "d" to 1.5, "b" to true, "z" to null, "l" to listOf(1L, "x"))
        assertEquals(m, Json.parse(Json.write(m)))
    }

    @Test fun backupPreservesEveryField() {
        val b = book("Tortilla Flat", "John Steinbeck", "Thomas C. Fensch", date = LocalDate.of(2026, 9, 24), rating = 3,
            isbn13 = "9780140187519", notes = "multi\nline, \"quoted\"", genre = "Fiction")
            .copy(tags = listOf("Classics", "Literature"), totalPages = 174, currentPage = 174, coverIsCustom = true,
                publisher = "Penguin Books", needsReview = true, reviewReason = "check", sourceText = "raw")
        val json = BackupCodec.encode(listOf(b to "covers/${b.uuid}.jpg"), mapOf("theme" to "SAECULUM"), 99L)
        val decoded = BackupCodec.decode(json)
        assertEquals(1, decoded.books.size)
        assertEquals(b.copy(id = 0), decoded.books[0].book)
        assertEquals("covers/${b.uuid}.jpg", decoded.books[0].coverFile)
        assertEquals("SAECULUM", decoded.settings["theme"])
        assertTrue(decoded.skipped.isEmpty())
    }

    @Test fun damagedBackupEntriesAreSkippedNotFatal() {
        val json = """{"format":"saeculum-backup","version":1,"books":[{"uuid":"a","title":"Ok","status":"TO_READ"},{"title":"No id","status":"TO_READ"}]}"""
        val d = BackupCodec.decode(json)
        assertEquals(1, d.books.size)
        assertEquals(1, d.skipped.size)
    }

    @Test(expected = BackupCodec.InvalidBackupException::class)
    fun rejectsNonBackups() { BackupCodec.decode("""{"hello":1}""") }

    @Test fun restorePlanSeparatesNewExistingAndDuplicates() {
        val lib = listOf(book("Dune", "Frank Herbert"), book("Odyssey", "Homer"))
        val backupBooks = listOf(lib[0], book("Odyssey", "Homer"), book("Utopia", "Thomas More"))
        val data = BackupCodec.decode(BackupCodec.encode(backupBooks.map { it to null }, emptyMap(), 0L))
        val plan = RestorePlanner.plan(data, lib)
        assertEquals(listOf("Utopia"), plan.newBooks.map { it.book.title })
        assertEquals(listOf("Dune"), plan.alreadyPresent.map { it.book.title })
        assertEquals(listOf("Odyssey"), plan.likelyDuplicates.map { it.first.book.title })
        assertEquals(1, plan.toRestore(RestoreMode.MERGE).size)
        assertEquals(3, plan.toRestore(RestoreMode.REPLACE).size)
    }
}

class MetadataTest {
    private val olSearch = """
      {"numFound":2,"docs":[
        {"key":"/works/OL27482W","title":"The Hobbit","author_name":["J.R.R. Tolkien"],"first_publish_year":1937,
         "publisher":["Allen & Unwin"],"isbn":["9780547928227","054792822X","bad"],"cover_i":14627509,"number_of_pages_median":310},
        {"key":"/works/OL1W","title":"The Hobbit Companion","author_name":["David Day"],"first_publish_year":1997}
      ]}
    """.trimIndent()

    @Test fun parsesOpenLibrarySearch() {
        val r = OpenLibraryParser.parseSearch(olSearch)
        assertEquals(2, r.size)
        assertEquals("9780547928227", r[0].isbn13)
        assertEquals("054792822X", r[0].isbn10)
        assertEquals("https://covers.openlibrary.org/b/id/14627509-L.jpg?default=false", r[0].coverUrl)
        assertTrue(r[0].yearIsFirstPublished)
        assertNull(r[1].coverUrl)
    }

    @Test fun parsesOpenLibraryIsbnAndGoogleBooks() {
        val ol = """{"ISBN:9780441013593":{"title":"Dune","authors":[{"name":"Frank Herbert"}],"publishers":[{"name":"Ace Books"}],
            "publish_date":"2005","number_of_pages":528,"cover":{"large":"https://covers.openlibrary.org/b/id/1-L.jpg"},
            "identifiers":{"isbn_13":["9780441013593"],"isbn_10":["0441013597"]}}}"""
        val d = OpenLibraryParser.parseIsbn(ol, "978-0441013593")!!
        assertEquals("Dune", d.title)
        assertEquals(2005, d.publicationYear)
        assertEquals("Ace Books", d.publisher)
        assertNull(OpenLibraryParser.parseIsbn("{}", "9780441013593"))

        val g = """{"items":[{"id":"x1","volumeInfo":{"title":"Dune","subtitle":"Deluxe Edition","authors":["Frank Herbert"],
            "publishedDate":"2019-10-01","industryIdentifiers":[{"type":"ISBN_13","identifier":"9780593099322"}],
            "pageCount":896,"imageLinks":{"thumbnail":"http://books.google.com/books/content?id=x1&printsec=frontcover&img=1&zoom=1&edge=curl"}}}]}"""
        val gr = GoogleBooksParser.parse(g).single()
        assertEquals("Dune: Deluxe Edition", gr.displayTitle)
        assertEquals(2019, gr.publicationYear)
        assertTrue(gr.coverUrl!!.startsWith("https://"))
        assertFalse(gr.coverUrl!!.contains("edge=curl"))
    }

    @Test fun titleAloneNeverIdentifiesABook() {
        val r = OpenLibraryParser.parseSearch(olSearch)
        assertEquals(MatchOutcome.MATCHED, MatchScorer.decide("The Hobbit", listOf("J.R.R. Tolkien"), r).outcome)
        assertEquals(MatchOutcome.NOT_FOUND, MatchScorer.decide("The Hobbit", emptyList(), r).outcome)
        assertEquals(MatchOutcome.NOT_FOUND, MatchScorer.decide("The Hobbit", listOf("Someone Else"), r).outcome)
        val two = r + r[0].copy(sourceId = "other edition", isbn13 = "9780261103344")
        assertEquals(MatchOutcome.MULTIPLE, MatchScorer.decide("The Hobbit", listOf("Tolkien"), two).outcome)
    }

    @Test fun mergeNeverTouchesPersonalData() {
        val mine = book("Dune", "Frank Herbert", year = 2025, rating = 4, notes = "mine").copy(publisher = "My Publisher")
        val r = MetadataResult("Open Library", "k", "Dune", authors = listOf("Someone"), publisher = "Ace",
            publicationYear = 1965, isbn13 = "9780441013593", pageCount = 604, coverUrl = "https://x/c.jpg")
        val out = MetadataMerge.fillMissing(mine, r, 9L)
        assertEquals("My Publisher", out.book.publisher)
        assertEquals(listOf("Frank Herbert"), out.book.authors)
        assertEquals(4, out.book.rating)
        assertEquals("mine", out.book.notes)
        assertEquals(2025, out.book.completedYear)
        assertEquals(ReadingStatus.COMPLETED, out.book.status)
        assertEquals("9780441013593", out.book.isbn13)
        assertEquals("https://x/c.jpg", out.book.coverUrl)
        assertEquals(setOf("ISBN", "Publication year", "Pages", "Cover"), out.changedFields.toSet())
        val custom = mine.copy(coverIsCustom = true, coverPath = "/files/covers/a.jpg")
        assertNull(MetadataMerge.fillMissing(custom, r, 9L).book.coverUrl)
    }
}
