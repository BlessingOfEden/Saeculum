package app.saeculum.core

import app.saeculum.core.export.TxtExporter
import app.saeculum.core.migration.ReadingListParser
import app.saeculum.core.model.ReadingStatus
import app.saeculum.core.stats.StatsCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Runs the parser over the user's actual supplied reading list (bundled as the app's seed asset). */
class ReadingListMigrationTest {

    private val result by lazy { ReadingListParser.parse(resource("novels_read_list.txt")) }
    private fun entry(title: String) = result.entries.first { it.title == title }

    @Test fun everyEntryIsPreservedUnderItsYear() {
        val perYear = result.entries.groupingBy { it.year }.eachCount()
        assertEquals(6, perYear[2026])
        assertEquals(30, perYear[2025])
        assertEquals(8, perYear[2024])
        assertEquals(2, perYear[2023])
        assertEquals(9, perYear[2022])
        assertEquals(15, perYear[2021])
        assertEquals(11, perYear[2020])
        assertEquals(81, result.entries.size)
        assertEquals(0, result.uncertainYearCount)
        assertTrue(result.unparsedLines.isEmpty())
    }

    @Test fun statedTotalsAreComparedNotTrusted() {
        val s2025 = result.sections.first { it.year == 2025 }
        assertEquals(30, s2025.statedTotal)
        assertTrue(!s2025.discrepancy)
        val s2024 = result.sections.first { it.year == 2024 }
        assertEquals(9, s2024.statedTotal)
        assertEquals(8, s2024.entryCount)
        assertEquals(listOf(2024), result.discrepancies.map { it.year })
        assertNull(result.sections.first { it.year == 2026 }.statedTotal)   // "No:" with no number
    }

    @Test fun authorsAndTitlesKeepOriginalSpelling() {
        assertEquals(listOf("Charles Thaxton", "Nancy Pearcey"), entry("The Soul of Science").authors)
        assertEquals(listOf("J.R.R. Tolkien"), entry("The Hobbit").authors)
        assertEquals(listOf("Keith & Sheila Gregoire"), entry("The Good Guy's Guide to Great Sex").authors)
        assertEquals(listOf("L. Jacobson & P.Masonheimer"), entry("The Flirtation Experiment").authors)
        assertEquals(listOf("Francis Chan", "Lisa Cha"), entry("You and Me Forever").authors)
        assertEquals(listOf("Joseph Grenny et al."), entry("Crucial Conversations").authors)
        assertEquals(listOf("Alisa childers", "Tim Barnett"), entry("The deconstruction of Christianity").authors)
        assertEquals(listOf("Geisler, Norman L.", "Frank Turek"), entry("I Don't Have Enough Faith to Be an Atheist").authors)
        assertEquals("The Purpose drivien life", entry("The Purpose drivien life").title)  // typo preserved
        assertEquals(listOf("George Orwell"), entry("1984").authors)
        assertEquals(listOf("Tetsuo Hara"), entry("Fist of the North Star").authors)
        assertEquals(listOf("Gregory Koukl"), entry("Tactics: 10th Anniversary Edition").authors)
        assertEquals(listOf("George Orwell"), entry("Animal Farm").authors)
        assertEquals(listOf("C.s Lewis"), entry("The Abolition of Man").authors)
        assertTrue(entry("The Abolition of Man").needsReview)
    }

    @Test fun progressMarkersBecomeProgressNotTitleText() {
        val bf = entry("Banana Fish")
        assertEquals(100, bf.progressPercent)
        assertEquals(listOf("C.S Lewis"), entry("Mere Christianity").authors)
        assertEquals(100, entry("Mere Christianity").progressPercent)
        val fable = entry("The Fable [038-045]")
        assertEquals(100, fable.progressPercent)
        assertEquals(2020, fable.year)
    }

    @Test fun uncertainLinesAreFlaggedNotGuessed() {
        val pain = entry("The Problem of Pain C.s Lewis")
        assertTrue(pain.authors.isEmpty())
        assertTrue(pain.needsReview)
        val sasori = result.entries.first { it.title.startsWith("Sasori [") }
        assertEquals("Sasori [035-0]", sasori.title)
        assertTrue(sasori.reviewReasons.any { it.startsWith("Section range") })
        assertTrue(entry("F").needsReview)
        assertTrue(entry("Mark-Revelation, Ezra, Nehemiah").authors.isEmpty())
    }

    @Test fun possibleDuplicatesAreReportedNotRemoved() {
        val pairs = result.duplicates.map { it.first.title to it.second.title }
        assertTrue(pairs.contains("The Four Loves" to "The Four Loves"))
        assertTrue(pairs.any { it.first == "The Fable" && it.second == "The Fable [038-045]" })
        assertEquals(81, result.entries.size)
    }

    @Test fun booksAreCompletedWithYearOnlyAndNothingInvented() {
        val books = ReadingListParser.toBooks(result, "seed", 1_000L, ::uuid)
        assertEquals(81, books.size)
        assertTrue(books.all { it.status == ReadingStatus.COMPLETED })
        assertTrue(books.all { it.completedDate == null && it.rating == null && it.isbn13 == null && it.coverUrl == null })
        assertEquals(books.map { it.importKey }.distinct().size, books.size)
        val stats = StatsCalculator.compute(books, 2026, null)
        assertEquals(81, stats.totalCompleted)
        assertEquals(6, stats.completedThisYear)
        assertEquals(2025 to 30, stats.mostProductiveYear)
        // "C.S Lewis", "C.s Lewis" and "Cs Lewis" are grouped for insights.
        val lewis = stats.topAuthors.first { it.name.contains("Lewis") }
        assertEquals(4, lewis.count)
    }

    @Test fun txtExportMatchesRequestedFormat() {
        val books = ReadingListParser.toBooks(result, "seed", 1_000L, ::uuid)
        val txt = TxtExporter.export(books)
        val expected2026 = """
            Novels Read 2026:
            • The Soul of Science by Charles Thaxton & Nancy Pearcey
            • No God But One by Nabeel Qureshi
            • Tortilla Flat by John Steinbeck
            • Ready Player Two by Ernest Cline
            • The Hobbit by J.R.R. Tolkien
            • The Pearl by John Steinbeck
            Total: 6
        """.trimIndent()
        assertTrue(txt, txt.startsWith(expected2026))
        assertTrue(txt.contains("Novels Read 2024:"))
        assertTrue(txt.contains("Total: 8"))            // real count, not the stated 9
        assertTrue(txt.indexOf("Novels Read 2025:") < txt.indexOf("Novels Read 2024:"))
    }
}
