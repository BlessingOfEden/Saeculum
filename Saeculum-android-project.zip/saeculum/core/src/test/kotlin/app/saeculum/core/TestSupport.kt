package app.saeculum.core

import app.saeculum.core.model.Book
import app.saeculum.core.model.ReadingStatus
import java.time.LocalDate
import java.util.concurrent.atomic.AtomicInteger

private val counter = AtomicInteger()

fun uuid(): String = "u-" + counter.incrementAndGet()

fun book(
    title: String,
    vararg authors: String,
    status: ReadingStatus = ReadingStatus.COMPLETED,
    year: Int? = null,
    date: LocalDate? = null,
    rating: Int? = null,
    isbn13: String? = null,
    added: Long = counter.incrementAndGet().toLong(),
    notes: String = "",
    genre: String? = null,
) = Book(
    id = counter.incrementAndGet().toLong(),
    uuid = uuid(),
    title = title,
    authors = authors.toList(),
    status = status,
    completedYear = if (status == ReadingStatus.COMPLETED) (date?.year ?: year) else null,
    completedDate = if (status == ReadingStatus.COMPLETED) date else null,
    rating = rating,
    isbn13 = isbn13,
    dateAdded = added,
    lastModified = added,
    notes = notes,
    genre = genre,
)

fun resource(name: String): String =
    Thread.currentThread().contextClassLoader.getResource(name)?.readText()
        ?: java.io.File("core/src/test/resources/$name").let { if (it.exists()) it.readText() else java.io.File("src/test/resources/$name").readText() }
