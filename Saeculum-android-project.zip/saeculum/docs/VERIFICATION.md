# Verification report

Generated 2026-10-19. This lists what was **actually executed**, and what was not.

## 1. Core unit tests: executed

Command (equivalent to `./gradlew :core:test`): `core/` main and test sources compiled with Kotlin 2.0.21 (`K2JVMCompiler`, JVM target 17) and run with JUnit 4.13.2.

```
Time: 0.637

OK (49 tests)
```

49 test methods:

**BookEditsTest**
- editing details never overwrites concurrent notes or rating
- user changes win
- moving out of completed in editor clears completion together
- manual entry needs only title and author

**ImportTest**
- spec example imports five books without inventing data
- column order does not matter with headers
- no header uses documented order
- optional columns and multiple authors
- missing and invalid values are reported not invented
- goodreads style export maps safely
- duplicates detected against library and within file
- different editions default to import
- export reimport round trip
- rating parsing

**IsbnTest**
- validates isbn13
- validates isbn10 including x
- converts between forms
- cleans spreadsheet artefacts
- barcode payloads

**CsvTest**
- parses spec example
- handles commas quotes newlines bom and crlf
- special characters survive
- malformed row does not swallow the rest
- detects semicolon and tab
- writer round trips everything

**StatsTest**
- counts only completed books once per record
- empty library has no misleading insights

**SortFilterTransitionTest**
- sorts ignore leading articles and put unknowns last
- filters by status year and query
- status transitions handle completion consistently
- captions resolve without network and carry attribution
- txt export groups unknown year and unfinished

**BackupAndJsonTest**
- json round trips tricky strings
- backup preserves every field
- damaged backup entries are skipped not fatal
- restore plan separates new existing and duplicates
- rejects non backups

**MetadataTest**
- parses open library search
- parses open library isbn and google books
- title alone never identifies a book
- merge never touches personal data

**ReadingListMigrationTest**
- every entry is preserved under its year
- stated totals are compared not trusted
- authors and titles keep original spelling
- progress markers become progress not title text
- uncertain lines are flagged not guessed
- possible duplicates are reported not removed
- books are completed with year only and nothing invented
- txt export matches requested format

The migration tests run against your actual supplied list (`core/src/test/resources/novels_read_list.txt`, identical to the app's seed asset).

## 2. Full Android build: executed

`./gradlew :core:test :app:testDebugUnitTest :app:assembleRelease :app:assembleDebug :app:assembleDebugAndroidTest` with Gradle 8.14.3, AGP 8.7.3, Kotlin 2.0.21 and Android SDK platform 35. It succeeds. The first real compile found one error (an icon name, `ChevronRight`, isn't in the auto-mirrored set), which is fixed.

## 3. App smoke test: executed (Robolectric)

`app/src/test/java/app/saeculum/AppSmokeTest.kt` launches the real `MainActivity` with the real Room database, DataStore preferences and Compose UI on a JVM Android runtime (Robolectric 4.14.1, API 34, native graphics). It checks:

- First launch imports exactly 81 books from the bundled list, all Completed with no ratings, 6 of them in 2026
- The first-launch report dialog appears and can be dismissed
- The library renders in 3, 1 and 6 columns; the density choice is saved
- Tapping a cover opens the detail sheet (status, completion year, rating, notes, details)
- Statistics, Currently Reading (empty state), Settings, the Add menu and manual entry render
- Dark mode renders

Screenshots of each step are written to `app/build/screenshots/` (copies are in `docs/screenshots/`).

## 4. Not yet verified (needs a physical phone)

- `BookDaoTest` (on-device database tests): compiled, not run
- Camera barcode scanning (CameraX + ML Kit)
- Live Open Library / Google Books searches and cover downloads
- The system file pickers for CSV import, exports, backup and restore
